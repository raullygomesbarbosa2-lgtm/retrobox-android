package com.raully.nebula16.chip8

import kotlin.random.Random

/** Original classic CHIP-8 interpreter, independent of any bundled third-party emulator. */
class Chip8(private val randomByte: () -> Int = { Random.nextInt(256) }) {
    private val memory = IntArray(4096)
    private val v = IntArray(16)
    private val stack = IntArray(16)
    private val pixels = BooleanArray(64 * 32)
    private val keys = BooleanArray(16)
    private var sp = 0
    private var i = 0
    var pc = 0x200; private set
    var delayTimer = 0; private set
    var soundTimer = 0; private set
    var drawChanged = true; private set

    fun screen(): BooleanArray = pixels
    fun register(index: Int): Int = v[index and 15]
    fun setKey(key: Int, down: Boolean) { if (key in 0..15) keys[key] = down }

    fun load(bytes: ByteArray) {
        require(bytes.isNotEmpty() && bytes.size <= 3584) { "ROM CHIP-8 deve ter de 1 a 3584 bytes." }
        memory.fill(0); v.fill(0); stack.fill(0); pixels.fill(false); keys.fill(false)
        font.forEachIndexed { n, value -> memory[0x50 + n] = value }
        bytes.forEachIndexed { n, b -> memory[0x200 + n] = b.toInt() and 0xff }
        sp = 0; i = 0; pc = 0x200; delayTimer = 0; soundTimer = 0; drawChanged = true
    }

    fun tickTimers() { if (delayTimer > 0) delayTimer--; if (soundTimer > 0) soundTimer-- }

    fun cycle() {
        require(pc in 0..4094) { "Contador de programa CHIP-8 fora da memória: $pc" }
        val op = (memory[pc] shl 8) or memory[pc + 1]
        val x = op ushr 8 and 15; val y = op ushr 4 and 15; val n = op and 15
        val nn = op and 255; val nnn = op and 4095
        pc = (pc + 2) and 4095
        when (op and 0xf000) {
            0x0000 -> when (op) {
                0x00e0 -> { pixels.fill(false); drawChanged = true }
                0x00ee -> { check(sp > 0) { "Pilha CHIP-8 vazia." }; pc = stack[--sp] }
                else -> if (nnn != 0) throw IllegalArgumentException("Opcode CHIP-8 não suportado: %04X".format(op))
            }
            0x1000 -> pc = nnn
            0x2000 -> { check(sp < stack.size) { "Pilha CHIP-8 cheia." }; stack[sp++] = pc; pc = nnn }
            0x3000 -> if (v[x] == nn) pc = (pc + 2) and 4095
            0x4000 -> if (v[x] != nn) pc = (pc + 2) and 4095
            0x5000 -> if (n == 0 && v[x] == v[y]) pc = (pc + 2) and 4095
            0x6000 -> v[x] = nn
            0x7000 -> v[x] = (v[x] + nn) and 255
            0x8000 -> when (n) {
                0 -> v[x] = v[y]
                1 -> v[x] = v[x] or v[y]
                2 -> v[x] = v[x] and v[y]
                3 -> v[x] = v[x] xor v[y]
                4 -> { val sum = v[x] + v[y]; v[15] = if (sum > 255) 1 else 0; v[x] = sum and 255 }
                5 -> { val old = v[x]; v[15] = if (old >= v[y]) 1 else 0; v[x] = (old - v[y]) and 255 }
                6 -> { v[15] = v[x] and 1; v[x] = v[x] ushr 1 }
                7 -> { val old = v[x]; v[15] = if (v[y] >= old) 1 else 0; v[x] = (v[y] - old) and 255 }
                0xe -> { v[15] = v[x] ushr 7; v[x] = (v[x] shl 1) and 255 }
                else -> throw IllegalArgumentException("Opcode CHIP-8 não suportado: %04X".format(op))
            }
            0x9000 -> if (n == 0 && v[x] != v[y]) pc = (pc + 2) and 4095
            0xa000 -> i = nnn
            0xb000 -> pc = (nnn + v[0]) and 4095
            0xc000 -> v[x] = randomByte() and nn
            0xd000 -> {
                val px = v[x] and 63; val py = v[y] and 31; v[15] = 0
                for (row in 0 until n) for (bit in 0 until 8) {
                    if ((memory[(i + row) and 4095] and (0x80 ushr bit)) != 0) {
                        val pos = ((py + row) and 31) * 64 + ((px + bit) and 63)
                        if (pixels[pos]) v[15] = 1
                        pixels[pos] = !pixels[pos]
                    }
                }
                drawChanged = true
            }
            0xe000 -> when (nn) {
                0x9e -> if (keys[v[x] and 15]) pc = (pc + 2) and 4095
                0xa1 -> if (!keys[v[x] and 15]) pc = (pc + 2) and 4095
                else -> throw IllegalArgumentException("Opcode CHIP-8 não suportado: %04X".format(op))
            }
            0xf000 -> when (nn) {
                0x07 -> v[x] = delayTimer
                0x0a -> { val key = keys.indexOfFirst { it }; if (key < 0) pc = (pc - 2) and 4095 else v[x] = key }
                0x15 -> delayTimer = v[x]
                0x18 -> soundTimer = v[x]
                0x1e -> i = (i + v[x]) and 4095
                0x29 -> i = 0x50 + (v[x] and 15) * 5
                0x33 -> { memory[i and 4095] = v[x] / 100; memory[(i + 1) and 4095] = (v[x] / 10) % 10; memory[(i + 2) and 4095] = v[x] % 10 }
                0x55 -> for (r in 0..x) memory[(i + r) and 4095] = v[r]
                0x65 -> for (r in 0..x) v[r] = memory[(i + r) and 4095]
                else -> throw IllegalArgumentException("Opcode CHIP-8 não suportado: %04X".format(op))
            }
        }
    }

    companion object {
        private val font = intArrayOf(0xF0,0x90,0x90,0x90,0xF0,0x20,0x60,0x20,0x20,0x70,0xF0,0x10,0xF0,0x80,0xF0,0xF0,0x10,0xF0,0x10,0xF0,0x90,0x90,0xF0,0x10,0x10,0xF0,0x80,0xF0,0x10,0xF0,0xF0,0x80,0xF0,0x90,0xF0,0xF0,0x10,0x20,0x40,0x40,0xF0,0x90,0xF0,0x90,0xF0,0xF0,0x90,0xF0,0x10,0xF0,0xF0,0x90,0xF0,0x90,0x90,0xE0,0x90,0xE0,0x90,0xE0,0xF0,0x80,0x80,0x80,0xF0,0xE0,0x90,0x90,0x90,0xE0,0xF0,0x80,0xF0,0x80,0xF0,0xF0,0x80,0xF0,0x80,0x80)
        /** Small original self-test illustration; not a commercial game or copied ROM. */
        val demo = byteArrayOf(0x00,0xE0.toByte(),0x60,0x0A,0x61,0x08,0xA2.toByte(),0x10,0xD0.toByte(),0x15,0x12,0x00,0x3C,0x42,0xA5.toByte(),0x81.toByte(),0x42,0x24,0x18)
    }
}
