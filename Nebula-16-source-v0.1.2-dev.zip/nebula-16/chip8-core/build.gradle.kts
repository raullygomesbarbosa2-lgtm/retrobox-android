plugins { kotlin("jvm") }
kotlin { jvmToolchain(17) }
dependencies {
    testImplementation(kotlin("test-junit5"))
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:5.10.2")
}
tasks.test { useJUnitPlatform() }
