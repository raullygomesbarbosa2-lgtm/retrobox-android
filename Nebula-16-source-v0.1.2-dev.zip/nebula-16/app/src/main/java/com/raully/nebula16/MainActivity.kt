package com.raully.nebula16

import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.raully.nebula16.chip8.Chip8
import com.raully.nebula16.snes.SnesPrototype
import kotlin.math.min

/** Nébula 16 development build: original CHIP-8 play mode plus honest SNES core prototype. */
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val vm = Chip8()
    private var gameView: PixelView? = null
    private var running = false
    private var lastTick = 0L
    private var timerCredit = 0L
    private lateinit var body: LinearLayout
    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            repeat(10) { try { vm.cycle() } catch (e: Exception) { stopGame(); Toast.makeText(this@MainActivity, e.message ?: "Erro na ROM", Toast.LENGTH_LONG).show(); return } }
            val now = System.nanoTime()
            if (lastTick == 0L) lastTick = now
            timerCredit += now - lastTick
            lastTick = now
            while (timerCredit >= 16_666_667L) { vm.tickTimers(); timerCredit -= 16_666_667L }
            gameView?.invalidate()
            handler.postDelayed(this, 16)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); showHome() }

    private fun showHome(note: String? = null) {
        running = false; handler.removeCallbacks(frame); gameView = null
        window.statusBarColor = Color.rgb(9, 13, 25); window.navigationBarColor = Color.rgb(9, 13, 25)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(9, 13, 25)) }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(32), dp(22), dp(28)); gravity = Gravity.CENTER_HORIZONTAL }
        scroll.addView(body); setContentView(scroll)
        body.addView(label("NÉBULA 16", 30f, Color.WHITE, true))
        body.addView(label("Projeto autoral • SNES em desenvolvimento + CHIP-8 jogável", 15f, 0xFFBAC6DF.toInt()).apply { setPadding(0, dp(8), 0, dp(20)) })
        button("JOGAR DEMO CHIP-8", 0xFF71E2B6.toInt()) { startChip8(Chip8.demo) }
        button("ABRIR ROM CHIP-8", 0xFF233451.toInt()) { pick(1) }
        button("ANALISAR ROM SUPER NINTENDO", 0xFF233451.toInt()) { pick(2) }
        val status = label(note ?: "O CHIP-8 já roda. O SNES é uma prévia técnica: ainda não executa jogos completos.", 14f, 0xFFE2C98A.toInt())
        status.setPadding(dp(13), dp(18), dp(13), dp(6)); body.addView(status)
        body.addView(label("Feito sem núcleos de emulação de terceiros. Não acompanha jogos, ROMs comerciais, BIOS ou firmware.", 12f, 0xFF9BA9C1.toInt()).apply { setPadding(dp(12), dp(12), dp(12), 0) })
    }

    private fun pick(kind: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivityForResult(intent, kind) } catch (_: Exception) { Toast.makeText(this, "Não consegui abrir o seletor de arquivos.", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Legacy result API supports the project's no-dependency Android UI")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        try {
            val bytes = contentResolver.openInputStream(data.data!!)?.use { it.readBytes() } ?: error("Arquivo vazio.")
            if (requestCode == 1) startChip8(bytes) else inspectSnes(bytes)
        } catch (e: Exception) { Toast.makeText(this, e.message ?: "Arquivo inválido.", Toast.LENGTH_LONG).show() }
    }

    private fun inspectSnes(bytes: ByteArray) {
        val report = try {
            val proto = SnesPrototype(bytes)
            val ops = proto.testInstructions(12)
            "Cartucho: ${proto.cartridge.title}\nTamanho: ${proto.cartridge.rom.size} bytes${if (proto.cartridge.hasCopierHeader) " (cabeçalho de 512 bytes removido)" else ""}\nVetor de reset: \$%04X\nCPU: %d instruções examinadas\n%s".format(proto.cartridge.resetVector(), proto.cpu.instructionsExecuted, ops.joinToString(" → "))
        } catch (e: Exception) { "Não consegui analisar esse arquivo: ${e.message ?: "formato inesperado"}" }
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(9, 13, 25)) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(32), dp(22), dp(28)) }
        scroll.addView(col); setContentView(scroll)
        col.addView(label("PRÉVIA SNES", 27f, Color.WHITE, true))
        col.addView(label("A ROM foi analisada pelo código próprio do projeto.", 14f, 0xFFBAC6DF.toInt()).apply { setPadding(0, dp(8), 0, dp(14)) })
        col.addView(label(report, 15f, 0xFFDAE3F5.toInt()).apply { setPadding(dp(14), dp(14), dp(14), dp(14)); setBackgroundColor(0xFF182237.toInt()) })
        col.addView(label("Importante: esta versão ainda não tem PPU de vídeo, áudio, DMA, interrupções nem o conjunto completo da CPU 65C816. Portanto, não roda jogos SNES; esta tela só valida leitura do cartucho e algumas instruções iniciais.", 14f, 0xFFE2C98A.toInt()).apply { setPadding(0, dp(18), 0, dp(18)) })
        button("VOLTAR", 0xFF233451.toInt()) { showHome() }
    }

    private fun startChip8(rom: ByteArray) {
        try { vm.load(rom) } catch (e: Exception) { Toast.makeText(this, e.message ?: "ROM CHIP-8 inválida.", Toast.LENGTH_LONG).show(); return }
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK) }
        val top = LinearLayout(this).apply { gravity = Gravity.END; setPadding(dp(8), dp(4), dp(8), dp(4)) }
        top.addView(Button(this).apply { text = "VOLTAR"; setOnClickListener { showHome() } })
        root.addView(top, LinearLayout.LayoutParams(-1, dp(52)))
        gameView = PixelView().also { root.addView(it, LinearLayout.LayoutParams(-1, 0, 1f)) }
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(6), dp(4), dp(6), dp(8)) }
        controls.addView(directionPad(), LinearLayout.LayoutParams(0, dp(130), 1.3f))
        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(keyButton("A", 5)); row.addView(keyButton("B", 13))
        actions.addView(row)
        controls.addView(actions, LinearLayout.LayoutParams(0, dp(130), 1f))
        root.addView(controls, LinearLayout.LayoutParams(-1, dp(145)))
        setContentView(root); running = true; lastTick = 0; timerCredit = 0; handler.post(frame)
    }

    private fun directionPad(): View {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        grid.addView(keyButton("▲", 2))
        val middle = LinearLayout(this).apply { gravity = Gravity.CENTER }
        middle.addView(keyButton("◀", 4)); middle.addView(keyButton("▼", 8)); middle.addView(keyButton("▶", 6))
        grid.addView(middle); return grid
    }

    private fun keyButton(text: String, key: Int): Button = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); setBackgroundColor(0xFF263550.toInt()); isAllCaps = false
        setOnTouchListener { _, event -> when (event.actionMasked) { MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> vm.setKey(key, true); MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_UP -> vm.setKey(key, false) }; true }
    }

    private fun stopGame() { running = false; handler.removeCallbacks(frame) }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean { val k = keyFor(keyCode); if (k != null) { vm.setKey(k, true); return true }; return super.onKeyDown(keyCode, event) }
    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean { val k = keyFor(keyCode); if (k != null) { vm.setKey(k, false); return true }; return super.onKeyUp(keyCode, event) }
    private fun keyFor(code: Int): Int? = when (code) { KeyEvent.KEYCODE_DPAD_UP -> 2; KeyEvent.KEYCODE_DPAD_DOWN -> 8; KeyEvent.KEYCODE_DPAD_LEFT -> 4; KeyEvent.KEYCODE_DPAD_RIGHT -> 6; KeyEvent.KEYCODE_BUTTON_A -> 5; KeyEvent.KEYCODE_BUTTON_B -> 13; KeyEvent.KEYCODE_BUTTON_X -> 7; KeyEvent.KEYCODE_BUTTON_Y -> 8; else -> null }

    private inner class PixelView : View(this@MainActivity) {
        private val paint = Paint().apply { color = 0xFF8CFFBB.toInt(); style = Paint.Style.FILL }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); canvas.drawColor(Color.BLACK)
            val scale = min(width.toFloat() / 64, height.toFloat() / 32); val left = (width - 64 * scale) / 2; val top = (height - 32 * scale) / 2
            val px = vm.screen()
            for (y in 0 until 32) for (x in 0 until 64) if (px[y * 64 + x]) canvas.drawRect(left + x * scale, top + y * scale, left + (x + 1) * scale + .5f, top + (y + 1) * scale + .5f, paint)
        }
    }

    private fun button(text: String, color: Int, action: () -> Unit) { body.addView(Button(this).apply { this.text = text; setTextColor(if (color == 0xFF71E2B6.toInt()) Color.BLACK else Color.WHITE); setBackgroundColor(color); setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(9) }) }
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER; if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
