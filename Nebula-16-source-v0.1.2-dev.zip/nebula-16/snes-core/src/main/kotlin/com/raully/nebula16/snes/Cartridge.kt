package com.raully.nebula16.snes

/** Minimal original LoROM cartridge reader. It does not contain game data. */
class Cartridge private constructor(val rom: ByteArray, val title: String, val hasCopierHeader: Boolean) {
    companion object {
        fun parse(input: ByteArray): Cartridge {
            require(input.size >= 0x8000) { "Arquivo curto demais para um cartucho SNES." }
            val headered = input.size % 0x8000 == 512
            val data = if (headered) input.copyOfRange(512, input.size) else input.copyOf()
            require(data.size >= 0x8000) { "ROM SNES inválida." }
            val titleStart = if (data.size > 0x7FC0) 0x7FC0 else 0
            val raw = data.copyOfRange(titleStart, minOf(titleStart + 21, data.size))
            val title = raw.map { (it.toInt() and 0xff).toChar() }.joinToString("").trim().trim('\u0000')
            return Cartridge(data, title.ifBlank { "Cartucho sem título" }, headered)
        }
    }

    /** Maps a LoROM CPU address to a ROM byte; returns null for unmapped addresses. */
    fun readRom(address: Int): Int? {
        val bank = (address ushr 16) and 0xff
        val offset = address and 0xffff
        if (offset < 0x8000 || (bank in 0x7e..0x7f)) return null
        val index = ((bank and 0x7f) * 0x8000) + (offset and 0x7fff)
        return if (index < rom.size) rom[index].toInt() and 0xff else null
    }

    fun resetVector(): Int {
        val lo = readRom(0x00fffc) ?: 0
        val hi = readRom(0x00fffd) ?: 0
        return lo or (hi shl 8)
    }
}
