package com.raully.nebula16.snes

/** Early SNES address bus: LoROM + WRAM mirrors and a partial PPU register window. */
internal class SnesBus(private val cartridge: Cartridge, private val ppu: SnesPpu? = null) {
    private val wram = ByteArray(128 * 1024)

    fun read8(address: Int): Int {
        val bank = address ushr 16 and 0xff
        val offset = address and 0xffff
        if (bank == 0x7e || bank == 0x7f) {
            val index = (bank - 0x7e) * 0x10000 + offset
            return wram[index].toInt() and 0xff
        }
        if (bank <= 0x3f || bank in 0x80..0xbf) {
            if (offset < 0x2000) return wram[offset].toInt() and 0xff
            if (offset in 0x2100..0x213f) return ppu?.readRegister(offset) ?: 0
            if (offset < 0x8000) return 0 // I/O and open bus not implemented
        }
        return cartridge.readRom(address) ?: 0
    }

    fun write8(address: Int, value: Int) {
        val bank = address ushr 16 and 0xff
        val offset = address and 0xffff
        when {
            bank == 0x7e || bank == 0x7f -> {
                val index = (bank - 0x7e) * 0x10000 + offset
                wram[index] = value.toByte()
            }
            (bank <= 0x3f || bank in 0x80..0xbf) && offset < 0x2000 -> wram[offset] = value.toByte()
            (bank <= 0x3f || bank in 0x80..0xbf) && offset in 0x2100..0x213f -> ppu?.writeRegister(offset, value)
            // Cartridge ROM is read-only; other hardware I/O is not implemented.
        }
    }

    fun readWram(address: Int): Int = wram[address and 0x1ffff].toInt() and 0xff
}
