package com.raully.nebula16.snes

/**
 * Original PPU milestone: 256x224, BG1 in SNES Mode 0, 2bpp tiles, 32x32 map,
 * basic 8x8 4bpp objects, CGRAM colors, BG1 scroll, forced blank and brightness.
 * Other backgrounds, object sizes/limits, modes 1-7, interlace, mosaic, windows,
 * color math and scanline timing are not yet implemented.
 */
class SnesPpu {
    val framebuffer = IntArray(WIDTH * HEIGHT)
    private val vram = IntArray(0x8000)
    private val cgram = IntArray(256)
    private val oam = IntArray(544)

    private var inidisp = 0x80
    private var objSelect = 0
    private var oamAddress = 0
    private var bgMode = 0
    private var bg1MapBaseWord = 0
    private var bg1CharBaseWord = 0
    private var bg1HScroll = 0
    private var bg1VScroll = 0
    private var vramAddress = 0
    private var vramIncrement = 1
    private var incrementAfterHigh = false
    private var cgramAddress = 0
    private var cgramLowLatch = 0
    private var cgramHighNext = false

    fun writeVramWord(wordAddress: Int, value: Int) {
        vram[wordAddress and 0x7fff] = value and 0xffff
    }

    fun readVramWord(wordAddress: Int): Int = vram[wordAddress and 0x7fff]

    /** Colors use the SNES 15-bit BGR format (bits 0-4 red, 5-9 green, 10-14 blue). */
    fun writeCgramColor(index: Int, bgr555: Int) {
        cgram[index and 0xff] = bgr555 and 0x7fff
    }

    fun writeOamByte(address: Int, value: Int) {
        oam[address % oam.size] = value and 0xff
    }

    fun readOamByte(address: Int): Int = oam[address % oam.size]

    fun writeRegister(address: Int, value: Int) {
        val v = value and 0xff
        when (address and 0xffff) {
            0x2100 -> inidisp = v
            0x2101 -> objSelect = v
            0x2102 -> oamAddress = (oamAddress and 0x100) or v
            0x2103 -> oamAddress = (oamAddress and 0xff) or ((v and 1) shl 8)
            0x2104 -> { oam[oamAddress % oam.size] = v; oamAddress = (oamAddress + 1) % oam.size }
            0x2105 -> bgMode = v and 7
            0x2107 -> bg1MapBaseWord = ((v and 0xfc) shl 8) and 0x7fff
            0x210b -> bg1CharBaseWord = (v and 0x0f) shl 11
            0x210d -> bg1HScroll = v
            0x210e -> bg1VScroll = v
            0x2115 -> {
                vramIncrement = when (v and 3) { 0 -> 1; 1 -> 32; 2 -> 128; else -> 1 }
                incrementAfterHigh = (v and 0x80) != 0
            }
            0x2116 -> vramAddress = (vramAddress and 0x7f00) or v
            0x2117 -> vramAddress = (vramAddress and 0x00ff) or ((v and 0x7f) shl 8)
            0x2118 -> {
                val old = vram[vramAddress and 0x7fff]
                vram[vramAddress and 0x7fff] = (old and 0xff00) or v
                if (!incrementAfterHigh) incrementVramAddress()
            }
            0x2119 -> {
                val old = vram[vramAddress and 0x7fff]
                vram[vramAddress and 0x7fff] = (old and 0x00ff) or (v shl 8)
                if (incrementAfterHigh) incrementVramAddress()
            }
            0x2121 -> { cgramAddress = v; cgramHighNext = false }
            0x2122 -> {
                if (!cgramHighNext) { cgramLowLatch = v; cgramHighNext = true }
                else {
                    cgram[cgramAddress and 0xff] = cgramLowLatch or ((v and 0x7f) shl 8)
                    cgramAddress = (cgramAddress + 1) and 0xff
                    cgramHighNext = false
                }
            }
        }
    }

    fun readRegister(address: Int): Int = when (address and 0xffff) {
        0x2139 -> vram[vramAddress and 0x7fff] and 0xff
        0x213a -> (vram[vramAddress and 0x7fff] ushr 8) and 0xff
        0x213b -> cgram[cgramAddress and 0xff] and 0xff
        0x213c -> 0
        else -> 0
    }

    private fun incrementVramAddress() { vramAddress = (vramAddress + vramIncrement) and 0x7fff }

    /** Render one visible frame to ARGB8888 pixels. */
    fun renderFrame(): IntArray {
        if ((inidisp and 0x80) != 0) {
            framebuffer.fill(OPAQUE_BLACK)
            return framebuffer
        }
        val brightness = inidisp and 0x0f
        for (screenY in 0 until HEIGHT) {
            for (screenX in 0 until WIDTH) {
                val bg = if (bgMode == 0) sampleMode0Bg1(screenX, screenY) else BgPixel(0, false)
                val sprite = sampleSprite(screenX, screenY)
                val colorIndex = when {
                    bg.colorIndex != 0 && bg.highPriority -> bg.colorIndex
                    sprite != null -> sprite.colorIndex
                    else -> bg.colorIndex
                }
                framebuffer[screenY * WIDTH + screenX] = toArgb(cgram[colorIndex], brightness)
            }
        }
        return framebuffer
    }

    private data class BgPixel(val colorIndex: Int, val highPriority: Boolean)
    private data class ObjPixel(val colorIndex: Int, val priority: Int)

    private fun sampleSprite(screenX: Int, screenY: Int): ObjPixel? {
        val objBaseWord = (objSelect and 7) shl 12
        for (sprite in 0 until 128) {
            val entry = sprite * 4
            val packed = (oam[512 + sprite / 4] ushr ((sprite % 4) * 2)) and 3
            val rawX = oam[entry] or ((packed and 1) shl 8)
            val objX = if ((rawX and 0x100) != 0) rawX - 512 else rawX
            val objY = oam[entry + 1]
            val dx = screenX - objX
            val dy = (screenY - objY) and 0xff
            if (dx !in 0..7 || dy !in 0..7) continue

            val attributes = oam[entry + 3]
            val tile = oam[entry + 2] or ((attributes and 1) shl 8)
            val flipH = (attributes and 0x40) != 0
            val flipV = (attributes and 0x80) != 0
            val px = if (flipH) 7 - dx else dx
            val py = if (flipV) 7 - dy else dy
            val rowWord = (objBaseWord + tile * 16 + py * 2) and 0x7fff
            val planes01 = vram[rowWord]
            val planes23 = vram[(rowWord + 8) and 0x7fff]
            val bit = 0x80 ushr px
            val color = (if ((planes01 and bit) != 0) 1 else 0) or
                (if (((planes01 ushr 8) and bit) != 0) 2 else 0) or
                (if ((planes23 and bit) != 0) 4 else 0) or
                (if (((planes23 ushr 8) and bit) != 0) 8 else 0)
            if (color == 0) continue
            val palette = (attributes ushr 1) and 7
            val priority = (attributes ushr 4) and 3
            return ObjPixel(128 + palette * 16 + color, priority)
        }
        return null
    }

    private fun sampleMode0Bg1(screenX: Int, screenY: Int): BgPixel {
        val worldX = (screenX + bg1HScroll) and 0xff
        val worldY = (screenY + bg1VScroll) and 0xff
        val tileX = worldX ushr 3
        val tileY = worldY ushr 3
        val mapIndex = (bg1MapBaseWord + tileY * 32 + tileX) and 0x7fff
        val entry = vram[mapIndex]
        val tile = entry and 0x03ff
        val palette = (entry ushr 10) and 7
        val flipH = (entry and 0x4000) != 0
        val flipV = (entry and 0x8000) != 0
        val pixelX = if (flipH) 7 - (worldX and 7) else worldX and 7
        val pixelY = if (flipV) 7 - (worldY and 7) else worldY and 7
        val tileRowWord = (bg1CharBaseWord + tile * 8 + pixelY) and 0x7fff
        val planes = vram[tileRowWord]
        val bit = 0x80 ushr pixelX
        val color = (if ((planes and bit) != 0) 1 else 0) or
            (if (((planes ushr 8) and bit) != 0) 2 else 0)
        val colorIndex = if (color == 0) 0 else palette * 4 + color
        return BgPixel(colorIndex, (entry and 0x2000) != 0)
    }

    private fun toArgb(bgr555: Int, brightness: Int): Int {
        if (brightness == 0) return OPAQUE_BLACK
        val red5 = bgr555 and 0x1f
        val green5 = (bgr555 ushr 5) and 0x1f
        val blue5 = (bgr555 ushr 10) and 0x1f
        val red = ((red5 * 255 / 31) * brightness / 15) and 0xff
        val green = ((green5 * 255 / 31) * brightness / 15) and 0xff
        val blue = ((blue5 * 255 / 31) * brightness / 15) and 0xff
        return (0xff shl 24) or (red shl 16) or (green shl 8) or blue
    }

    companion object {
        const val WIDTH = 256
        const val HEIGHT = 224
        private const val OPAQUE_BLACK = 0xff000000.toInt()
    }
}
