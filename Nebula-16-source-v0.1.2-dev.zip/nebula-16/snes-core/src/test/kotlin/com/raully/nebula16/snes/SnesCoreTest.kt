package com.raully.nebula16.snes

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SnesCoreTest {
    @Test fun parsesLoRomResetVectorAndRunsOriginalSubset() {
        val rom = ByteArray(0x8000)
        rom[0x7ffc] = 0x00; rom[0x7ffd] = 0x80.toByte()
        rom[0] = 0xA9.toByte(); rom[1] = 0x2A
        rom[2] = 0x8D.toByte(); rom[3] = 0x00; rom[4] = 0x10
        rom[5] = 0xDB.toByte()
        val machine = SnesPrototype(rom)
        assertEquals(0x8000, machine.cpu.pc)
        machine.testInstructions(3)
        assertEquals(0x2a, machine.cpu.readWram(0x1000))
        assertTrue(machine.cpu.stopped)
    }

    @Test fun runs16BitAccumulatorAndRepSep() {
        val rom = ByteArray(0x8000)
        rom[0x7ffc] = 0x00; rom[0x7ffd] = 0x80.toByte()
        val program = byteArrayOf(
            0x18,                             // CLC
            0xFB.toByte(),                    // XCE — enter native mode
            0xC2.toByte(), 0x30,              // REP #$30 — 16-bit A and indexes
            0xA9.toByte(), 0x34, 0x12,        // LDA #$1234
            0x8D.toByte(), 0x00, 0x10,        // STA $1000
            0xE2.toByte(), 0x20,              // SEP #$20 — 8-bit A
            0xDB.toByte()                     // STP
        )
        program.forEachIndexed { index, value -> rom[index] = value }
        val machine = SnesPrototype(rom)
        machine.testInstructions(7)
        assertEquals(0x34, machine.cpu.readWram(0x1000))
        assertEquals(0x12, machine.cpu.readWram(0x1001))
        assertEquals(0x1234, machine.cpu.a)
        assertTrue(machine.cpu.stopped)
    }

    @Test fun cpuWritesMemoryMappedPpuPortsAndRendersFirstPixel() {
        val rom = ByteArray(0x8000)
        rom[0x7ffc] = 0x00; rom[0x7ffd] = 0x80.toByte()
        val program = mutableListOf<Int>()
        fun lda(value: Int) { program.add(0xA9); program.add(value and 0xff) }
        fun sta(address: Int) { program.add(0x8D); program.add(address and 0xff); program.add((address ushr 8) and 0xff) }
        fun setReg(address: Int, value: Int) { lda(value); sta(address) }
        setReg(0x2100, 0x0f) // show the display
        setReg(0x212c, 0x01) // enable BG1 on the main screen
        setReg(0x2107, 0x02) // BG1 map begins at VRAM word 0x0200
        setReg(0x2115, 0x80) // increment VRAM address after high-byte writes
        setReg(0x2116, 0x00); setReg(0x2117, 0x00)
        setReg(0x2118, 0x80); setReg(0x2119, 0x00) // tile 0, first pixel
        setReg(0x2116, 0x00); setReg(0x2117, 0x02)
        setReg(0x2118, 0x00); setReg(0x2119, 0x00) // map entry points at tile 0
        setReg(0x2121, 0x01); setReg(0x2122, 0x1f); setReg(0x2122, 0x00) // red CGRAM color
        program += 0xDB
        program.forEachIndexed { index, byte -> rom[index] = byte.toByte() }

        val machine = SnesPrototype(rom)
        machine.testInstructions(128)
        assertEquals(0xffff0000.toInt(), machine.ppu.renderFrame()[0])
    }

    @Test fun stripsCopierHeader() {
        val rom = ByteArray(512 + 0x8000)
        val cart = Cartridge.parse(rom)
        assertTrue(cart.hasCopierHeader)
        assertEquals(0x8000, cart.rom.size)
    }
}
