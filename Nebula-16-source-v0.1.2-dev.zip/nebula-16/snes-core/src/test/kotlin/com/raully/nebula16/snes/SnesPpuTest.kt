package com.raully.nebula16.snes

import kotlin.test.Test
import kotlin.test.assertEquals

class SnesPpuTest {
    @Test fun rendersMode0Bg1TileAndCgramColor() {
        val ppu = SnesPpu()
        ppu.writeRegister(0x2100, 0x0f) // display enabled, full brightness
        ppu.writeRegister(0x212c, 0x01) // enable BG1 on the main screen
        ppu.writeRegister(0x210b, 0x01) // BG1 character base at word 0x800
        ppu.writeVramWord(0x0800, 0x0080) // plane 0: top-left pixel of tile 0
        ppu.writeCgramColor(1, 0x001f) // red in BGR555

        val pixels = ppu.renderFrame()
        assertEquals(0xffff0000.toInt(), pixels[0])
        assertEquals(0xff000000.toInt(), pixels[1])
        assertEquals(SnesPpu.WIDTH * SnesPpu.HEIGHT, pixels.size)
    }

    @Test fun drawsBasic8By8ObjectOverLowPriorityBackground() {
        val ppu = SnesPpu()
        ppu.writeRegister(0x2100, 0x0f)
        ppu.writeRegister(0x212c, 0x10) // enable objects on the main screen
        ppu.writeRegister(0x2107, 0x04) // map base word 0x200, away from pattern data
        ppu.writeVramWord(0x0000, 0x0080) // 4bpp object, first pixel
        ppu.writeVramWord(0x0200, 0x0000) // BG1 map entry: blank tile 0
        ppu.writeCgramColor(129, 0x03e0) // object palette 0, color 1: green
        ppu.writeOamByte(0, 0); ppu.writeOamByte(1, 0)
        ppu.writeOamByte(2, 0); ppu.writeOamByte(3, 0x30) // object priority 3

        assertEquals(0xff00ff00.toInt(), ppu.renderFrame()[0])
    }

    @Test fun honorsHorizontalTileFlipAndForcedBlank() {
        val ppu = SnesPpu()
        ppu.writeRegister(0x2100, 0x0f)
        ppu.writeRegister(0x212c, 0x01) // enable BG1 on the main screen
        ppu.writeRegister(0x210b, 0x01) // BG1 character base at word 0x800
        ppu.writeVramWord(0x0000, 0x4000) // BG1 tilemap entry: horizontal flip
        ppu.writeVramWord(0x0800, 0x0001) // source pixel at tile's right edge
        ppu.writeCgramColor(1, 0x03e0) // green
        ppu.renderFrame()
        assertEquals(0xff00ff00.toInt(), ppu.framebuffer[0])

        ppu.writeRegister(0x2100, 0x80)
        assertEquals(0xff000000.toInt(), ppu.renderFrame()[0])
    }
}
