package com.raully.nebula16.snes

/**
 * Minimal frame runner wiring together the original CPU, LoROM bus, controller, and PPU.
 * The instruction budget is a development approximation; no cycle-accurate scheduler/APU yet.
 */
class SnesMachine(bytes: ByteArray, private val instructionsPerFrame: Int = 12_000) {
    val cartridge = Cartridge.parse(bytes)
    val ppu = SnesPpu()
    val controller = SnesController()
    val cpu = Cpu65816(cartridge, ppu, controller)

    fun setButton(button: SnesButton, pressed: Boolean) = controller.setButton(button, pressed)

    /** Advances a bounded number of CPU instructions, then renders the current PPU state. */
    fun runFrame(): IntArray {
        repeat(instructionsPerFrame.coerceAtLeast(1)) {
            if (!cpu.stopped) cpu.step()
        }
        return ppu.renderFrame()
    }
}
