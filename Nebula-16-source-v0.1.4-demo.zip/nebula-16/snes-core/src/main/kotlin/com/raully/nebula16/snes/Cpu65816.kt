package com.raully.nebula16.snes

/**
 * First from-scratch 65C816 CPU milestone for Nébula 16.
 * The current subset is deliberately explicit: unsupported opcodes stop rather than
 * being silently treated as valid. Timing, decimal arithmetic and native-mode edge
 * cases are still under development.
 */
class Cpu65816(private val cartridge: Cartridge, ppu: SnesPpu? = null, controller: SnesController? = null) {
    private val bus = SnesBus(cartridge, ppu, controller)
    var pc: Int = cartridge.resetVector(); private set
    var a: Int = 0; private set
    var x: Int = 0; private set
    var y: Int = 0; private set
    var status: Int = 0x34; private set
    var stack: Int = 0x01ff; private set
    var dataBank: Int = 0; private set
    var programBank: Int = 0; private set
    var directPage: Int = 0; private set
    var emulationMode: Boolean = true; private set
    var stopped: Boolean = false; private set
    var instructionsExecuted: Long = 0; private set

    private val acc8 get() = (status and FLAG_M) != 0
    private val index8 get() = (status and FLAG_X) != 0
    private fun mask(is8: Boolean) = if (is8) 0xff else 0xffff
    private fun setFlag(flag: Int, on: Boolean) { status = if (on) status or flag else status and flag.inv() }
    private fun flag(flag: Int) = (status and flag) != 0
    private fun nz(value: Int, is8: Boolean) {
        val valueMasked = value and mask(is8)
        setFlag(FLAG_Z, valueMasked == 0)
        val signBit = if (is8) 0x80 else 0x8000
        setFlag(FLAG_N, (valueMasked and signBit) != 0)
    }
    private fun read(address: Int) = bus.read8(address and 0xffffff)
    private fun write(address: Int, value: Int) = bus.write8(address and 0xffffff, value)
    private fun fetch8(): Int { val value = read((programBank shl 16) or pc); pc = (pc + 1) and 0xffff; return value }
    private fun fetch16(): Int { val lo = fetch8(); return lo or (fetch8() shl 8) }
    private fun fetch24(): Int { val lo = fetch16(); return lo or (fetch8() shl 16) }
    private fun fetchImmediate(is8: Boolean) = if (is8) fetch8() else fetch16()
    private fun readWidth(address: Int, is8: Boolean): Int {
        val lo = read(address)
        return if (is8) lo else lo or (read((address + 1) and 0xffffff) shl 8)
    }
    private fun writeWidth(address: Int, value: Int, is8: Boolean) {
        write(address, value)
        if (!is8) write((address + 1) and 0xffffff, value ushr 8)
    }
    private fun dp() = fetch8()
    private fun abs() = (dataBank shl 16) or fetch16()
    private fun dpAddress(offset: Int = 0) = (directPage + fetch8() + offset) and 0xffff
    private fun compare(left: Int, right: Int, is8: Boolean) {
        val m = mask(is8); val r = (left - right) and m
        setFlag(FLAG_C, (left and m) >= (right and m)); nz(r, is8)
    }
    private fun add(value: Int, is8: Boolean, subtract: Boolean = false) {
        val m = mask(is8); val sign = if (is8) 0x80 else 0x8000
        val old = a and m
        val operand = value and m
        val carryIn = if (flag(FLAG_C)) 1 else 0
        val sum = if (subtract) old + (operand xor m) + carryIn else old + operand + carryIn
        val result = sum and m
        setFlag(FLAG_C, sum > m)
        val overflow = if (subtract) ((old xor result) and (old xor operand) and sign) != 0 else ((old xor result).inv() and (result xor operand) and sign) != 0
        setFlag(FLAG_V, overflow)
        a = if (is8) (a and 0xff00) or result else result
        nz(result, is8)
    }
    private fun branch(condition: Boolean) { val displacement = fetch8().toByte().toInt(); if (condition) pc = (pc + displacement) and 0xffff }
    private fun push8(value: Int) { write(0x000100 or (stack and 0xff), value); stack = 0x0100 or ((stack - 1) and 0xff) }
    private fun pop8(): Int { stack = 0x0100 or ((stack + 1) and 0xff); return read(0x000100 or (stack and 0xff)) }
    private fun push16(value: Int) { push8(value ushr 8); push8(value) }
    private fun pop16(): Int { val lo = pop8(); return lo or (pop8() shl 8) }

    /** Run exactly one instruction and return its mnemonic. */
    fun step(): String {
        if (stopped) return "STP"
        val opcodeAddress = pc
        val op = fetch8()
        val name = when (op) {
            0xea -> "NOP"
            0x18 -> { setFlag(FLAG_C, false); "CLC" }
            0x38 -> { setFlag(FLAG_C, true); "SEC" }
            0x58 -> { setFlag(FLAG_I, false); "CLI" }
            0x78 -> { setFlag(FLAG_I, true); "SEI" }
            0xb8 -> { setFlag(FLAG_V, false); "CLV" }
            0xd8 -> { setFlag(FLAG_D, false); "CLD" }
            0xf8 -> { setFlag(FLAG_D, true); "SED" }
            0xc2 -> {
                val bits = fetch8(); status = status and bits.inv()
                if (emulationMode) status = status or FLAG_M or FLAG_X
                "REP"
            }
            0xe2 -> {
                val bits = fetch8(); status = status or bits
                if (index8) { x = x and 0xff; y = y and 0xff }
                "SEP"
            }
            0xfb -> {
                val oldE = emulationMode
                emulationMode = flag(FLAG_C)
                setFlag(FLAG_C, oldE)
                if (emulationMode) {
                    setFlag(FLAG_M, true); setFlag(FLAG_X, true)
                    x = x and 0xff; y = y and 0xff
                    stack = 0x0100 or (stack and 0xff)
                }
                "XCE"
            }

            0xa9 -> { val v = fetchImmediate(acc8); a = if (acc8) (a and 0xff00) or v else v; nz(v, acc8); "LDA #" }
            0xa5 -> { val v = readWidth(dpAddress(), acc8); a = if (acc8) (a and 0xff00) or v else v; nz(v, acc8); "LDA dp" }
            0xb5 -> { val v = readWidth(dpAddress(x), acc8); a = if (acc8) (a and 0xff00) or v else v; nz(v, acc8); "LDA dp,X" }
            0xad -> { val v = readWidth(abs(), acc8); a = if (acc8) (a and 0xff00) or v else v; nz(v, acc8); "LDA abs" }
            0xbd -> { val v = readWidth((dataBank shl 16) or ((fetch16() + x) and 0xffff), acc8); a = if (acc8) (a and 0xff00) or v else v; nz(v, acc8); "LDA abs,X" }
            0xb9 -> { val v = readWidth((dataBank shl 16) or ((fetch16() + y) and 0xffff), acc8); a = if (acc8) (a and 0xff00) or v else v; nz(v, acc8); "LDA abs,Y" }
            0xaf -> { val v = readWidth(fetch24(), acc8); a = if (acc8) (a and 0xff00) or v else v; nz(v, acc8); "LDA long" }
            0xa2 -> { val v = fetchImmediate(index8); x = v and mask(index8); nz(x, index8); "LDX #" }
            0xa0 -> { val v = fetchImmediate(index8); y = v and mask(index8); nz(y, index8); "LDY #" }
            0xa6 -> { x = readWidth(dpAddress(), index8); nz(x, index8); "LDX dp" }
            0xa4 -> { y = readWidth(dpAddress(), index8); nz(y, index8); "LDY dp" }
            0xae -> { x = readWidth((dataBank shl 16) or fetch16(), index8); nz(x, index8); "LDX abs" }
            0xac -> { y = readWidth((dataBank shl 16) or fetch16(), index8); nz(y, index8); "LDY abs" }
            0xbe -> { x = readWidth((dataBank shl 16) or ((fetch16() + y) and 0xffff), index8); nz(x, index8); "LDX abs,Y" }
            0xbc -> { y = readWidth((dataBank shl 16) or ((fetch16() + x) and 0xffff), index8); nz(y, index8); "LDY abs,X" }

            0x85 -> { writeWidth(dpAddress(), a, acc8); "STA dp" }
            0x95 -> { writeWidth(dpAddress(x), a, acc8); "STA dp,X" }
            0x8d -> { writeWidth(abs(), a, acc8); "STA abs" }
            0x9d -> { writeWidth((dataBank shl 16) or ((fetch16() + x) and 0xffff), a, acc8); "STA abs,X" }
            0x99 -> { writeWidth((dataBank shl 16) or ((fetch16() + y) and 0xffff), a, acc8); "STA abs,Y" }
            0x8f -> { writeWidth(fetch24(), a, acc8); "STA long" }
            0x86 -> { writeWidth(dpAddress(), x, index8); "STX dp" }
            0x8e -> { writeWidth((dataBank shl 16) or fetch16(), x, index8); "STX abs" }
            0x84 -> { writeWidth(dpAddress(), y, index8); "STY dp" }
            0x8c -> { writeWidth((dataBank shl 16) or fetch16(), y, index8); "STY abs" }

            0x09 -> { val oldHigh = if (acc8) a and 0xff00 else 0; val v = (a and mask(acc8)) or fetchImmediate(acc8); a = oldHigh or (v and mask(acc8)); nz(v, acc8); "ORA #" }
            0x29 -> { val oldHigh = if (acc8) a and 0xff00 else 0; val v = (a and mask(acc8)) and fetchImmediate(acc8); a = oldHigh or (v and mask(acc8)); nz(v, acc8); "AND #" }
            0x49 -> { val oldHigh = if (acc8) a and 0xff00 else 0; val v = (a and mask(acc8)) xor fetchImmediate(acc8); a = oldHigh or (v and mask(acc8)); nz(v, acc8); "EOR #" }
            0x69 -> { add(fetchImmediate(acc8), acc8); "ADC #" }
            0xe9 -> { add(fetchImmediate(acc8), acc8, true); "SBC #" }
            0xc9 -> { compare(a, fetchImmediate(acc8), acc8); "CMP #" }
            0xe0 -> { compare(x, fetchImmediate(index8), index8); "CPX #" }
            0xc0 -> { compare(y, fetchImmediate(index8), index8); "CPY #" }

            0x1a -> { val v = (a + 1) and mask(acc8); a = if (acc8) (a and 0xff00) or v else v; nz(v, acc8); "INC A" }
            0x3a -> { val v = (a - 1) and mask(acc8); a = if (acc8) (a and 0xff00) or v else v; nz(v, acc8); "DEC A" }
            0xe8 -> { x = (x + 1) and mask(index8); nz(x, index8); "INX" }
            0xca -> { x = (x - 1) and mask(index8); nz(x, index8); "DEX" }
            0xc8 -> { y = (y + 1) and mask(index8); nz(y, index8); "INY" }
            0x88 -> { y = (y - 1) and mask(index8); nz(y, index8); "DEY" }
            0xaa -> { x = a and mask(index8); nz(x, index8); "TAX" }
            0xa8 -> { y = a and mask(index8); nz(y, index8); "TAY" }
            0x8a -> { a = if (acc8) (a and 0xff00) or (x and 0xff) else x; nz(a, acc8); "TXA" }
            0x98 -> { a = if (acc8) (a and 0xff00) or (y and 0xff) else y; nz(a, acc8); "TYA" }
            0x9a -> { stack = if (index8) 0x0100 or (x and 0xff) else x and 0xffff; "TXS" }
            0xba -> { x = stack and mask(index8); nz(x, index8); "TSX" }
            0x5b -> { directPage = a and 0xffff; nz(directPage, false); "TCD" }
            0x7b -> { a = directPage; nz(a, false); "TDC" }

            0x80 -> { branch(true); "BRA" }
            0xf0 -> { branch(flag(FLAG_Z)); "BEQ" }
            0xd0 -> { branch(!flag(FLAG_Z)); "BNE" }
            0x10 -> { branch(!flag(FLAG_N)); "BPL" }
            0x30 -> { branch(flag(FLAG_N)); "BMI" }
            0x90 -> { branch(!flag(FLAG_C)); "BCC" }
            0xb0 -> { branch(flag(FLAG_C)); "BCS" }
            0x50 -> { branch(!flag(FLAG_V)); "BVC" }
            0x70 -> { branch(flag(FLAG_V)); "BVS" }
            0x4c -> { pc = fetch16(); "JMP abs" }
            0x5c -> { val target = fetch24(); programBank = target ushr 16; pc = target and 0xffff; "JMP long" }
            0x20 -> { val target = fetch16(); push16((pc - 1) and 0xffff); pc = target; "JSR" }
            0x60 -> { pc = (pop16() + 1) and 0xffff; "RTS" }
            0x22 -> { val target = fetch24(); push8(programBank); push16((pc - 1) and 0xffff); programBank = target ushr 16; pc = target and 0xffff; "JSL" }
            0x6b -> { pc = (pop16() + 1) and 0xffff; programBank = pop8(); "RTL" }
            0x48 -> { if (acc8) push8(a) else push16(a); "PHA" }
            0x68 -> { a = if (acc8) (a and 0xff00) or pop8() else pop16(); nz(a, acc8); "PLA" }
            0xda -> { if (index8) push8(x) else push16(x); "PHX" }
            0xfa -> { x = if (index8) pop8() else pop16(); nz(x, index8); "PLX" }
            0x5a -> { if (index8) push8(y) else push16(y); "PHY" }
            0x7a -> { y = if (index8) pop8() else pop16(); nz(y, index8); "PLY" }
            0x08 -> { push8(status); "PHP" }
            0x28 -> { status = pop8(); if (emulationMode) status = status or FLAG_M or FLAG_X; if (index8) { x = x and 0xff; y = y and 0xff }; "PLP" }
            0x00 -> { stopped = true; "BRK (interrupts not implemented)" }
            0xdb -> { stopped = true; "STP" }
            else -> { stopped = true; "Unsupported opcode %02X at %02X:%04X".format(op, programBank, opcodeAddress) }
        }
        instructionsExecuted++
        return name
    }

    fun readWram(address: Int): Int = bus.readWram(address)

    companion object {
        private const val FLAG_C = 0x01
        private const val FLAG_Z = 0x02
        private const val FLAG_I = 0x04
        private const val FLAG_D = 0x08
        private const val FLAG_X = 0x10
        private const val FLAG_M = 0x20
        private const val FLAG_V = 0x40
        private const val FLAG_N = 0x80
    }
}

/** ROM inspection and CPU smoke test; video, sound, DMA and interrupts remain unimplemented. */
class SnesPrototype(bytes: ByteArray) {
    val cartridge = Cartridge.parse(bytes)
    val ppu = SnesPpu()
    val cpu = Cpu65816(cartridge, ppu)
    fun testInstructions(count: Int = 16): List<String> = buildList {
        repeat(count) { if (!cpu.stopped) add(cpu.step()) }
    }
}
