# Nébula 16 — demo autoral para Android

Demo Android com interface própria, tema escuro com neon azul-bebê e núcleos escritos no projeto, sem embutir interfaces ou motores de emuladores de terceiros.

## Sistemas nesta demo

- **CHIP-8:** núcleo jogável; aceita ROMs `.ch8` e arquivos binários locais, além do pequeno demo original.
- **Super Nintendo:** núcleo experimental, sem compatibilidade garantida com jogos comerciais. Lê cartuchos LoROM simples e implementa apenas partes iniciais de CPU/PPU.
- **NES e Game Boy:** aparecem como próximos sistemas planejados, mas ainda não são núcleos disponíveis nesta versão.

Durante o jogo há botões para voltar à biblioteca, abrir outra ROM do sistema atual, ver o painel de cheats (ainda não implementados nesta demo) e configurar controles. O mapeamento captura teclas padrão de gamepads reconhecidos pelo Android; sticks analógicos/d-pad também usam os eixos de joystick padrão. A compatibilidade concreta depende do modo de entrada que o controle expõe ao Android.

Nenhuma ROM comercial, BIOS, firmware ou jogo de terceiros acompanha o app. Use somente arquivos que você tem direito de usar.

## Limites da demo

O núcleo SNES é incompleto e experimental: faltam instruções e temporização da CPU, camadas e modos da PPU, APU, DMA/HDMA, interrupções e mapeamento completo de cartuchos. ROMs podem falhar ou não mostrar imagem. Os menus de cheats existem, mas ainda não alteram os jogos.

## Compilar

O workflow GitHub Actions compila e testa os módulos e publica o APK como artefato de build. Requer JDK 17, Android SDK API 35 e Gradle 8.10.2 (configurados automaticamente pelo workflow).
