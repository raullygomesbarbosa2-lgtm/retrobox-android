# Nébula Retro 0.2.1

Nébula Retro has its **own Android screen and game-library flow written in Kotlin for this project**; it does not package the Lemuroid app or its interface. The emulation engines are existing open-source Libretro cores, integrated through LibretroDroid: PPSSPP for PSP and PCSX-ReARMed for PS1. Writing those console emulators from scratch would be a separate, much larger project.

## Use

- Choose one folder for PS1 games and another for PSP games.
- The app scans each selected folder and its subfolders; tap a listed game to start it.
- Gameplay opens in landscape. The screen has a directional pad, face buttons, Start/Select and shoulder buttons. The pad also supplies left-stick movement for PSP games.
- On first PSP launch, the app needs internet to download PPSSPP helper assets. They are not a BIOS or a game.

The APK contains no games, disc images, BIOS, or firmware. PPSSPP uses HLE and does not need a PSP BIOS. PCSX-ReARMed can use HLE without a PS1 BIOS, but compatibility varies; some games may not start correctly. No particular frame rate or performance is guaranteed on every phone.

## Supported Android ABIs

The build bundles only the PS1 and PSP cores for `arm64-v8a`, `armeabi-v7a`, and `x86`. The pinned PPSSPP release does not provide a valid `x86_64` core, so x86_64-only devices are not supported by this build.

## Build and credits

The GitHub Actions workflow builds the standalone Android project. The LibretroDroid frontend library and the PPSSPP and PCSX-ReARMed cores are separate GPL-licensed upstream projects; see `COPYING` and `SOURCE_LICENSES.md`. Core binaries are fetched from the pinned LemuroidCores commit in the build, and only the two required cores are packaged.
