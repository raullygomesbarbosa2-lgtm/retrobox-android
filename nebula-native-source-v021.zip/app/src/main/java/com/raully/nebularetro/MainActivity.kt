package com.raully.nebularetro

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private enum class GameSystemKind(val label: String, val pref: String, val extensions: Set<String>) {
    PS1("PlayStation (PS1)", "folder_ps1", setOf("cue", "chd", "iso", "pbp", "img", "bin")),
    PSP("PlayStation Portable (PSP)", "folder_psp", setOf("iso", "cso", "pbp")),
}

private data class GameEntry(
    val name: String,
    val uri: String,
    val rootUri: String,
    val relativePath: String,
    val system: GameSystemKind,
)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("nebula_library", MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private lateinit var gameList: LinearLayout
    private lateinit var ps1Status: TextView
    private lateinit var pspStatus: TextView

    private val ps1Picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        saveFolder(GameSystemKind.PS1, uri)
    }
    private val pspPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        saveFolder(GameSystemKind.PSP, uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 13, 26)
        window.navigationBarColor = Color.rgb(10, 13, 26)
        window.decorView.systemUiVisibility = 0

        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(10, 13, 26)) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(content)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "NÉBULA RETRO"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.05f
        }
        content.addView(title)
        content.addView(text("PS1 + PSP  •  sua biblioteca, seus jogos", 14f, 0xFFB8C4E2.toInt()).apply {
            setPadding(0, dp(5), 0, dp(16))
        })

        addFolderCard(GameSystemKind.PS1).also { ps1Status = it }
        addFolderCard(GameSystemKind.PSP).also { pspStatus = it }
        content.addView(button("ATUALIZAR BIBLIOTECA", 0xFF8E7CFF.toInt()) { refreshLibrary() }.apply {
            setPadding(dp(12), dp(9), dp(12), dp(9))
        }, marginParams(-1, 52, top = 12, bottom = 16))
        content.addView(text("SEUS JOGOS", 13f, 0xFF8D9AB8.toInt()).apply {
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            setPadding(0, dp(4), 0, dp(8))
        })
        gameList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(gameList)

        refreshFolderLabels()
        refreshLibrary()
    }

    private fun addFolderCard(system: GameSystemKind): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(0xFF171D32.toInt(), 16)
        }
        card.addView(text(system.label, 16f, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD })
        val status = text("Pasta não selecionada", 12f, 0xFFAAB4CD.toInt()).apply {
            setPadding(0, dp(4), 0, dp(8))
        }
        card.addView(status)
        card.addView(button("ESCOLHER PASTA ${if (system == GameSystemKind.PS1) "PS1" else "PSP"}", 0xFF29314C.toInt()) {
            if (system == GameSystemKind.PS1) ps1Picker.launch(null) else pspPicker.launch(null)
        })
        content.addView(card, marginParams(-1, -2, bottom = 10))
        return status
    }

    private fun saveFolder(system: GameSystemKind, uri: Uri?) {
        if (uri == null) return
        runCatching {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        prefs.edit().putString(system.pref, uri.toString()).apply()
        refreshFolderLabels()
        refreshLibrary()
    }

    private fun refreshFolderLabels() {
        ps1Status.text = folderLabel(GameSystemKind.PS1)
        pspStatus.text = folderLabel(GameSystemKind.PSP)
    }

    private fun folderLabel(system: GameSystemKind): String {
        val value = prefs.getString(system.pref, null) ?: return "Pasta não selecionada"
        val uri = runCatching { Uri.parse(value) }.getOrNull() ?: return "Pasta não selecionada"
        return DocumentFile.fromTreeUri(this, uri)?.name ?: "Pasta selecionada"
    }

    private fun refreshLibrary() {
        gameList.removeAllViews()
        gameList.addView(text("Procurando jogos…", 14f, 0xFFB8C4E2.toInt()).apply {
            setPadding(dp(2), dp(8), dp(2), dp(8))
        })
        lifecycleScope.launch {
            val games = withContext(Dispatchers.IO) { scanLibrary() }
            gameList.removeAllViews()
            if (games.isEmpty()) {
                gameList.addView(text("Nenhum jogo encontrado. Escolha as pastas de PS1 e PSP acima.", 14f, 0xFFB8C4E2.toInt()).apply {
                    setPadding(dp(2), dp(8), dp(2), dp(8))
                })
            } else {
                games.forEach { entry ->
                    gameList.addView(button("▶   ${entry.name}\n      ${entry.system.label}", 0xFF171D32.toInt()) {
                        launchGame(entry)
                    }.apply {
                        textAlignment = TextView.TEXT_ALIGNMENT_VIEW_START
                        setPadding(dp(14), dp(10), dp(14), dp(10))
                    }, marginParams(-1, -2, bottom = 7))
                }
            }
        }
    }

    private fun scanLibrary(): List<GameEntry> {
        val result = mutableListOf<GameEntry>()
        GameSystemKind.values().forEach { system ->
            val rootString = prefs.getString(system.pref, null) ?: return@forEach
            val rootUri = runCatching { Uri.parse(rootString) }.getOrNull() ?: return@forEach
            val root = DocumentFile.fromTreeUri(this, rootUri) ?: return@forEach
            scanDirectory(root, rootUri.toString(), "", system, result, 0)
        }
        return result.sortedWith(compareBy({ it.system.ordinal }, { it.name.lowercase(Locale.ROOT) }))
    }

    private fun scanDirectory(
        dir: DocumentFile,
        rootUri: String,
        relative: String,
        system: GameSystemKind,
        result: MutableList<GameEntry>,
        depth: Int,
    ) {
        if (depth > 16 || result.size > 3000) return
        val children = runCatching { dir.listFiles().toList() }.getOrDefault(emptyList())
        val cueBases = children.filter { it.isFile && extension(it.name) == "cue" }
            .mapNotNull { it.name?.substringBeforeLast('.') }
            .toSet()
        children.forEach { child ->
            val name = child.name ?: return@forEach
            if (child.isDirectory) {
                scanDirectory(child, rootUri, if (relative.isEmpty()) name else "$relative/$name", system, result, depth + 1)
            } else if (child.isFile) {
                val ext = extension(name)
                val binHasCue = ext == "bin" && name.substringBeforeLast('.', name) in cueBases
                if (ext in system.extensions && !binHasCue) {
                    result += GameEntry(
                        name = name,
                        uri = child.uri.toString(),
                        rootUri = rootUri,
                        relativePath = if (relative.isEmpty()) name else "$relative/$name",
                        system = system,
                    )
                }
            }
        }
    }

    private fun launchGame(entry: GameEntry) {
        lifecycleScope.launch {
            Toast.makeText(this@MainActivity, "Abrindo ${entry.name}…", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@MainActivity, GameActivity::class.java).apply {
                putExtra(GameActivity.EXTRA_GAME_URI, entry.uri)
                putExtra(GameActivity.EXTRA_ROOT_URI, entry.rootUri)
                putExtra(GameActivity.EXTRA_RELATIVE_PATH, entry.relativePath)
                putExtra(GameActivity.EXTRA_SYSTEM, entry.system.name)
            }
            startActivity(intent)
        }
    }

    private fun extension(name: String?): String = name?.substringAfterLast('.', "")?.lowercase(Locale.ROOT) ?: ""

    private fun button(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = rounded(color, 14)
        setOnClickListener { action() }
    }

    private fun text(value: String, size: Float, color: Int) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun marginParams(width: Int, height: Int, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(width, if (height < 0) ViewGroup.LayoutParams.WRAP_CONTENT else dp(height)).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
