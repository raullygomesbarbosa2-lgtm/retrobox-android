package com.raully.nebula.psp

import kotlin.test.Test
import kotlin.test.assertEquals

class AllegrexCpuTest {
    private class Ram : PspBus {
        private val data = ByteArray(4096)
        override fun read8(address: Int) = data[address].toInt() and 0xFF
        override fun read16(address: Int) = read8(address) or (read8(address + 1) shl 8)
        override fun read32(address: Int) = read8(address) or (read8(address + 1) shl 8) or (read8(address + 2) shl 16) or (read8(address + 3) shl 24)
        override fun write8(address: Int, value: Int) { data[address] = value.toByte() }
        override fun write16(address: Int, value: Int) { write8(address, value); write8(address + 1, value ushr 8) }
        override fun write32(address: Int, value: Int) { repeat(4) { write8(address + it, value ushr (8 * it)) } }
        fun load(vararg words: Int) = words.forEachIndexed { i, word -> write32(i * 4, word) }
    }

    @Test fun arithmeticAndZeroRegister() {
        val ram = Ram().apply { load(i(0x09, 0, 1, 5), i(0x09, 1, 2, -2), i(0x09, 2, 0, 9)) }
        val cpu = AllegrexCpu(ram).apply { reset(0) }
        repeat(3) { cpu.step() }
        assertEquals(5, cpu.gpr[1])
        assertEquals(3, cpu.gpr[2])
        assertEquals(0, cpu.gpr[0])
    }

    @Test fun branchKeepsOneDelaySlot() {
        val ram = Ram().apply { load(i(0x04, 0, 0, 1), i(0x09, 0, 1, 5), i(0x09, 0, 2, 7)) }
        val cpu = AllegrexCpu(ram).apply { reset(0) }
        repeat(3) { cpu.step() }
        assertEquals(5, cpu.gpr[1])
        assertEquals(7, cpu.gpr[2])
        assertEquals(12, cpu.pc)
    }

    @Test fun overflowRaisesAllegrexException() {
        val ram = Ram().apply { load(i(0x0F, 0, 1, 0x7FFF), i(0x0D, 1, 1, 0xFFFF), i(0x08, 1, 2, 1)) }
        val cpu = AllegrexCpu(ram).apply { reset(0) }
        repeat(3) { cpu.step() }
        assertEquals(PspException.OVERFLOW.value, (cpu.cause ushr 2) and 0x1F)
        assertEquals(8, cpu.epc)
    }

    private fun i(op: Int, rs: Int, rt: Int, imm: Int) =
        (op shl 26) or (rs shl 21) or (rt shl 16) or (imm and 0xFFFF)
}
