package com.raully.nebula.psp

import kotlin.test.Test
import kotlin.test.assertEquals

class PspMemoryLoaderTest {
    @Test fun mainRamAndCachedAliasShareBytes() {
        val memory = PspMemory()
        memory.write32(0x08000000, 0x12345678)
        assertEquals(0x12345678, memory.read32(0x88000000.toInt()))
        memory.write8(0x00010000, 0xAB)
        assertEquals(0xAB, memory.read8(0x00010000))
    }

    @Test fun elfLoaderCopiesSegmentClearsBssAndSetsEntry() {
        val elf = makeElf()
        val memory = PspMemory()
        val cpu = AllegrexCpu(memory)
        val info = PspElfLoader.load(elf, memory, cpu)
        assertEquals(0x08000000, info.entryPoint)
        assertEquals(1, info.loadedSegments)
        assertEquals(0x44332211, memory.read32(0x08000000))
        assertEquals(0, memory.read32(0x08000004))
        assertEquals(0x08000000, cpu.pc)
    }

    private fun makeElf(): ByteArray {
        val elf = ByteArray(88)
        elf[0] = 0x7F
        elf[1] = 'E'.code.toByte(); elf[2] = 'L'.code.toByte(); elf[3] = 'F'.code.toByte()
        elf[4] = 1; elf[5] = 1
        put32(elf, 24, 0x08000000)
        put32(elf, 28, 52)
        put16(elf, 42, 32)
        put16(elf, 44, 1)
        put32(elf, 52, 1)
        put32(elf, 56, 84)
        put32(elf, 60, 0x08000000)
        put32(elf, 68, 4)
        put32(elf, 72, 8)
        elf[84] = 0x11; elf[85] = 0x22; elf[86] = 0x33; elf[87] = 0x44
        return elf
    }

    private fun put16(data: ByteArray, at: Int, value: Int) {
        data[at] = value.toByte(); data[at + 1] = (value ushr 8).toByte()
    }

    private fun put32(data: ByteArray, at: Int, value: Int) {
        repeat(4) { data[at + it] = (value ushr (8 * it)).toByte() }
    }
}
