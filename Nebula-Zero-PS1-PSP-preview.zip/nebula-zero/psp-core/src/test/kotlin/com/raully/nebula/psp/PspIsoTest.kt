package com.raully.nebula.psp

import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertFailsWith

class PspIsoTest {
    @Test fun extractsEbootBinFromPspGameDirectory() {
        val expected = byteArrayOf(1, 2, 3, 4, 5, 6)
        val image = ByteArray(24 * SECTOR)
        val pvd = 16 * SECTOR
        image[pvd] = 1
        "CD001".toByteArray(Charsets.US_ASCII).copyInto(image, pvd + 1)
        image[pvd + 6] = 1
        writeRecord(image, pvd + 156, byteArrayOf(0), 20, SECTOR, true)

        var root = 20 * SECTOR
        root = writeRecord(image, root, byteArrayOf(0), 20, SECTOR, true)
        root = writeRecord(image, root, byteArrayOf(1), 20, SECTOR, true)
        writeRecord(image, root, "PSP_GAME".toByteArray(), 21, SECTOR, true)

        var game = 21 * SECTOR
        game = writeRecord(image, game, byteArrayOf(0), 21, SECTOR, true)
        game = writeRecord(image, game, byteArrayOf(1), 20, SECTOR, true)
        writeRecord(image, game, "SYSDIR".toByteArray(), 22, SECTOR, true)

        var sysdir = 22 * SECTOR
        sysdir = writeRecord(image, sysdir, byteArrayOf(0), 22, SECTOR, true)
        sysdir = writeRecord(image, sysdir, byteArrayOf(1), 21, SECTOR, true)
        writeRecord(image, sysdir, "EBOOT.BIN;1".toByteArray(), 23, expected.size, false)
        expected.copyInto(image, 23 * SECTOR)

        assertContentEquals(expected, PspIso(image).readEbootBin())
    }

    @Test fun rejectsNonIsoImage() {
        assertFailsWith<IllegalArgumentException> { PspIso(ByteArray(17 * SECTOR)) }
    }

    private fun writeRecord(out: ByteArray, at: Int, name: ByteArray, extent: Int, size: Int, directory: Boolean): Int {
        val length = 33 + name.size + if (name.size % 2 == 0) 1 else 0
        out[at] = length.toByte()
        put32(out, at + 2, extent)
        put32(out, at + 10, size)
        out[at + 25] = if (directory) 2 else 0
        out[at + 32] = name.size.toByte()
        name.copyInto(out, at + 33)
        return at + length
    }

    private fun put32(out: ByteArray, at: Int, value: Int) {
        repeat(4) { out[at + it] = (value ushr (8 * it)).toByte() }
    }

    private companion object { const val SECTOR = 2048 }
}
