package com.raully.nebula.psp

/** Project-authored Allegrex/MIPS interpreter foundation; not a complete PSP CPU yet. */
class AllegrexCpu(private val bus: PspBus) {
    val gpr = IntArray(32)
    private val cp0 = IntArray(32)
    var hi: Int = 0
        private set
    var lo: Int = 0
        private set
    var pc: Int = 0
        private set
    var instructionsExecuted: Long = 0
        private set
    val cause: Int get() = cp0[13]
    val epc: Int get() = cp0[14]

    private var nextPc = 4
    private var branchDelayPending = false

    fun reset(resetVector: Int = 0xBFC00000.toInt()) {
        gpr.fill(0)
        cp0.fill(0)
        hi = 0
        lo = 0
        pc = resetVector
        nextPc = resetVector + 4
        branchDelayPending = false
        instructionsExecuted = 0
    }

    /** Starts a decrypted ELF/PRX entry directly; PSP firmware services are not emulated yet. */
    fun startDirect(entryPoint: Int, stackPointer: Int = 0x09FFF000) {
        reset(entryPoint)
        gpr[29] = stackPointer
        gpr[30] = stackPointer
    }

    fun readCop0(register: Int): Int = cp0[register and 31]

    fun step() {
        val instructionPc = pc
        val inDelaySlot = branchDelayPending
        try {
            if ((instructionPc and 3) != 0) throw PspCpuTrap(PspException.ADDRESS_LOAD, instructionPc)
            val instruction = try {
                bus.read32(physicalAddress(instructionPc))
            } catch (fault: PspBusFault) {
                throw PspCpuTrap(PspException.BUS_INSTRUCTION, fault.address)
            }
            pc = nextPc
            nextPc = pc + 4
            branchDelayPending = false
            execute(instruction, instructionPc)
            instructionsExecuted++
        } catch (trap: PspCpuTrap) {
            enterException(trap, instructionPc, inDelaySlot)
        } catch (fault: PspBusFault) {
            enterException(PspCpuTrap(PspException.BUS_DATA, fault.address), instructionPc, inDelaySlot)
        }
        gpr[0] = 0
    }

    private fun execute(op: Int, at: Int) {
        val primary = op ushr 26
        val rs = (op ushr 21) and 31
        val rt = (op ushr 16) and 31
        val rd = (op ushr 11) and 31
        val sa = (op ushr 6) and 31
        val imm = op and 0xFFFF
        val signed = (imm shl 16) shr 16
        val target = op and 0x03FFFFFF
        when (primary) {
            0x00 -> special(op, rs, rt, rd, sa)
            0x01 -> {
                val taken = when (rt) {
                    0, 16 -> gpr[rs] < 0
                    1, 17 -> gpr[rs] >= 0
                    else -> trap(PspException.RESERVED_INSTRUCTION)
                }
                if (rt == 16 || rt == 17) gpr[31] = pc + 4
                branch(at, signed, taken)
            }
            0x02 -> jump(at, target)
            0x03 -> { gpr[31] = pc + 4; jump(at, target) }
            0x04 -> branch(at, signed, gpr[rs] == gpr[rt])
            0x05 -> branch(at, signed, gpr[rs] != gpr[rt])
            0x06 -> branch(at, signed, gpr[rs] <= 0)
            0x07 -> branch(at, signed, gpr[rs] > 0)
            0x08 -> gpr[rt] = addOverflow(gpr[rs], signed)
            0x09 -> gpr[rt] = gpr[rs] + signed
            0x0A -> gpr[rt] = if (gpr[rs] < signed) 1 else 0
            0x0B -> gpr[rt] = if (gpr[rs].toUInt() < signed.toUInt()) 1 else 0
            0x0C -> gpr[rt] = gpr[rs] and imm
            0x0D -> gpr[rt] = gpr[rs] or imm
            0x0E -> gpr[rt] = gpr[rs] xor imm
            0x0F -> gpr[rt] = imm shl 16
            0x10 -> cop0Instruction(op, rs, rt, rd)
            0x11, 0x12 -> throw PspCpuTrap(PspException.COPROCESSOR_UNUSABLE, coprocessor = primary - 0x10)
            0x1C -> special2(op, rs, rt, rd)
            0x20 -> gpr[rt] = bus.read8(physicalAddress(gpr[rs] + signed)).toByte().toInt()
            0x21 -> { val a = gpr[rs] + signed; aligned(a, 2, false); gpr[rt] = bus.read16(physicalAddress(a)).toShort().toInt() }
            0x23 -> { val a = gpr[rs] + signed; aligned(a, 4, false); gpr[rt] = bus.read32(physicalAddress(a)) }
            0x24 -> gpr[rt] = bus.read8(physicalAddress(gpr[rs] + signed)) and 0xFF
            0x25 -> { val a = gpr[rs] + signed; aligned(a, 2, false); gpr[rt] = bus.read16(physicalAddress(a)) and 0xFFFF }
            0x28 -> bus.write8(physicalAddress(gpr[rs] + signed), gpr[rt])
            0x29 -> { val a = gpr[rs] + signed; aligned(a, 2, true); bus.write16(physicalAddress(a), gpr[rt]) }
            0x2B -> { val a = gpr[rs] + signed; aligned(a, 4, true); bus.write32(physicalAddress(a), gpr[rt]) }
            0x2F, 0x33 -> Unit // CACHE/PREF do not change architectural state in this first core slice.
            else -> trap(PspException.RESERVED_INSTRUCTION)
        }
    }

    private fun special(op: Int, rs: Int, rt: Int, rd: Int, sa: Int) {
        when (op and 0x3F) {
            0x00 -> gpr[rd] = gpr[rt] shl sa
            0x02 -> gpr[rd] = gpr[rt] ushr sa
            0x03 -> gpr[rd] = gpr[rt] shr sa
            0x04 -> gpr[rd] = gpr[rt] shl (gpr[rs] and 31)
            0x06 -> gpr[rd] = gpr[rt] ushr (gpr[rs] and 31)
            0x07 -> gpr[rd] = gpr[rt] shr (gpr[rs] and 31)
            0x08 -> jumpRegister(gpr[rs])
            0x09 -> { gpr[rd] = pc + 4; jumpRegister(gpr[rs]) }
            0x0C -> trap(PspException.SYSCALL)
            0x0D -> trap(PspException.BREAKPOINT)
            0x10 -> gpr[rd] = hi
            0x11 -> hi = gpr[rs]
            0x12 -> gpr[rd] = lo
            0x13 -> lo = gpr[rs]
            0x18 -> { val p = gpr[rs].toLong() * gpr[rt].toLong(); lo = p.toInt(); hi = (p shr 32).toInt() }
            0x19 -> { val p = gpr[rs].toUInt().toULong() * gpr[rt].toUInt().toULong(); lo = p.toLong().toInt(); hi = (p shr 32).toLong().toInt() }
            0x1A -> divideSigned(gpr[rs], gpr[rt])
            0x1B -> divideUnsigned(gpr[rs], gpr[rt])
            0x20 -> gpr[rd] = addOverflow(gpr[rs], gpr[rt])
            0x21 -> gpr[rd] = gpr[rs] + gpr[rt]
            0x22 -> gpr[rd] = subtractOverflow(gpr[rs], gpr[rt])
            0x23 -> gpr[rd] = gpr[rs] - gpr[rt]
            0x24 -> gpr[rd] = gpr[rs] and gpr[rt]
            0x25 -> gpr[rd] = gpr[rs] or gpr[rt]
            0x26 -> gpr[rd] = gpr[rs] xor gpr[rt]
            0x27 -> gpr[rd] = gpr[rs].inv() and gpr[rt].inv()
            0x2A -> gpr[rd] = if (gpr[rs] < gpr[rt]) 1 else 0
            0x2B -> gpr[rd] = if (gpr[rs].toUInt() < gpr[rt].toUInt()) 1 else 0
            0x0F, 0x2F -> Unit // SYNC/stream hint
            else -> trap(PspException.RESERVED_INSTRUCTION)
        }
    }

    private fun special2(op: Int, rs: Int, rt: Int, rd: Int) {
        when (op and 0x3F) {
            0x00 -> { val p = gpr[rs].toLong() * gpr[rt].toLong() + ((hi.toLong() shl 32) or (lo.toLong() and 0xFFFFFFFFL)); lo = p.toInt(); hi = (p shr 32).toInt() }
            0x01 -> { val p = gpr[rs].toUInt().toULong() * gpr[rt].toUInt().toULong() + ((hi.toUInt().toULong() shl 32) or lo.toUInt().toULong()); lo = p.toLong().toInt(); hi = (p shr 32).toLong().toInt() }
            0x02 -> gpr[rd] = (gpr[rs].toLong() * gpr[rt].toLong()).toInt()
            0x20 -> gpr[rd] = Integer.numberOfLeadingZeros(gpr[rs])
            0x21 -> gpr[rd] = Integer.numberOfLeadingZeros(gpr[rs].inv())
            else -> trap(PspException.RESERVED_INSTRUCTION)
        }
    }

    private fun cop0Instruction(op: Int, rs: Int, rt: Int, rd: Int) {
        when (rs) {
            0 -> gpr[rt] = cp0[rd]
            4 -> if (rd != 13 && rd != 14 && rd != 15) cp0[rd] = gpr[rt]
            16 -> if ((op and 0x3F) == 0x10) {
                val status = cp0[12]
                cp0[12] = (status and -64) or ((status ushr 2) and 0x0F) or (status and 0x30)
            } else trap(PspException.RESERVED_INSTRUCTION)
            else -> trap(PspException.RESERVED_INSTRUCTION)
        }
    }

    private fun branch(at: Int, offset: Int, taken: Boolean) {
        branchDelayPending = true
        if (taken) nextPc = at + 4 + (offset shl 2)
    }

    private fun jump(at: Int, target: Int) {
        branchDelayPending = true
        nextPc = ((at + 4) and -0x10000000) or (target shl 2)
    }

    private fun jumpRegister(target: Int) { branchDelayPending = true; nextPc = target }

    private fun addOverflow(a: Int, b: Int): Int {
        val result = a.toLong() + b.toLong()
        if (result !in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()) trap(PspException.OVERFLOW)
        return result.toInt()
    }

    private fun subtractOverflow(a: Int, b: Int): Int {
        val result = a.toLong() - b.toLong()
        if (result !in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()) trap(PspException.OVERFLOW)
        return result.toInt()
    }

    private fun divideSigned(a: Int, b: Int) {
        if (b == 0) { lo = if (a < 0) 1 else -1; hi = a }
        else if (a == Int.MIN_VALUE && b == -1) { lo = Int.MIN_VALUE; hi = 0 }
        else { lo = a / b; hi = a % b }
    }

    private fun divideUnsigned(a: Int, b: Int) {
        if (b == 0) { lo = -1; hi = a }
        else { lo = a.toUInt().div(b.toUInt()).toInt(); hi = a.toUInt().rem(b.toUInt()).toInt() }
    }

    private fun aligned(address: Int, size: Int, write: Boolean) {
        if ((address and (size - 1)) != 0) throw PspCpuTrap(if (write) PspException.ADDRESS_STORE else PspException.ADDRESS_LOAD, address)
    }

    private fun enterException(trap: PspCpuTrap, at: Int, inDelaySlot: Boolean) {
        val status = cp0[12]
        cp0[12] = (status and -64) or ((status shl 2) and 0x3F)
        cp0[13] = (cp0[13] and 0x0000FF00) or (trap.code.value shl 2) or
            ((trap.coprocessor and 3) shl 28) or (if (inDelaySlot) Int.MIN_VALUE else 0)
        if (trap.badAddress != null && (trap.code == PspException.ADDRESS_LOAD || trap.code == PspException.ADDRESS_STORE)) cp0[8] = trap.badAddress
        cp0[14] = if (inDelaySlot) at - 4 else at
        val vector = if ((status and STATUS_BEV) != 0) EXCEPTION_VECTOR_BEV else EXCEPTION_VECTOR
        pc = vector
        nextPc = vector + 4
        branchDelayPending = false
    }

    private fun physicalAddress(address: Int): Int = when (address ushr 29) {
        4, 5 -> address and 0x1FFFFFFF
        else -> address
    }

    private fun trap(code: PspException): Nothing = throw PspCpuTrap(code)

    private companion object {
        const val STATUS_BEV = 1 shl 22
        const val EXCEPTION_VECTOR = -2147483520
        const val EXCEPTION_VECTOR_BEV = -1077935744
    }
}

interface PspBus {
    fun read8(address: Int): Int
    fun read16(address: Int): Int
    fun read32(address: Int): Int
    fun write8(address: Int, value: Int)
    fun write16(address: Int, value: Int)
    fun write32(address: Int, value: Int)
}

class PspBusFault(val address: Int, val write: Boolean) : RuntimeException()

internal class PspCpuTrap(
    val code: PspException,
    val badAddress: Int? = null,
    val coprocessor: Int = 0
) : RuntimeException()

enum class PspException(val value: Int) {
    INTERRUPT(0), ADDRESS_LOAD(4), ADDRESS_STORE(5), BUS_INSTRUCTION(6), BUS_DATA(7),
    SYSCALL(8), BREAKPOINT(9), RESERVED_INSTRUCTION(10), COPROCESSOR_UNUSABLE(11), OVERFLOW(12)
}
