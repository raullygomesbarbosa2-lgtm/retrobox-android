package com.raully.nebula.psp

import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets

/** Initial PSP UMD ISO reader. It extracts files from a 2048-byte-sector ISO-9660 image. */
class PspIso(buffer: ByteBuffer) {
    private val bytes = buffer.asReadOnlyBuffer()

    constructor(source: ByteArray) : this(ByteBuffer.wrap(source))
    private val root: Entry

    init {
        require(bytes.limit() >= 17 * SECTOR_SIZE) { "PSP ISO is too small." }
        val pvd = 16 * SECTOR_SIZE
        require(u8(pvd) == 1 && ascii(pvd + 1, 5) == "CD001" && u8(pvd + 6) == 1) {
            "Unsupported PSP disc image: ISO-9660 volume descriptor not found."
        }
        root = record(pvd + 156, pvd + SECTOR_SIZE)
        require(root.directory) { "Invalid PSP ISO root directory." }
    }

    /** Returns the game's EBOOT.BIN bytes; encrypted PRX loading/decryption is not included yet. */
    fun readEbootBin(): ByteArray = readFile("PSP_GAME/SYSDIR/EBOOT.BIN")

    fun readFile(path: String): ByteArray {
        val parts = path.replace('\\', '/').split('/').map(::normalize).filter(String::isNotEmpty)
        require(parts.isNotEmpty()) { "A PSP ISO path is required." }
        var directory = root
        parts.dropLast(1).forEach { name ->
            directory = list(directory).firstOrNull { it.directory && normalize(it.name) == name }
                ?: error("PSP ISO directory '$name' was not found.")
        }
        val file = list(directory).firstOrNull { !it.directory && normalize(it.name) == parts.last() }
            ?: error("PSP ISO file '${parts.last()}' was not found.")
        val start = file.extent.toLong() * SECTOR_SIZE
        val end = start + file.size
        require(start >= 0 && end >= start && end <= bytes.limit().toLong()) { "PSP ISO file points outside the image." }
        return readBytes(start.toInt(), file.size)
    }

    private fun list(dir: Entry): List<Entry> {
        require(dir.directory)
        val start = dir.extent.toLong() * SECTOR_SIZE
        val end = start + dir.size
        require(start >= 0 && end >= start && end <= bytes.limit().toLong()) { "PSP ISO directory points outside the image." }
        val result = ArrayList<Entry>()
        var offset = start.toInt()
        val endIndex = end.toInt()
        while (offset < endIndex) {
            val length = u8(offset)
            if (length == 0) {
                offset = ((offset / SECTOR_SIZE) + 1) * SECTOR_SIZE
                continue
            }
            val entry = record(offset, minOf(offset + length, endIndex))
            if (entry.name != "\u0000" && entry.name != "\u0001") result += entry
            offset += length
        }
        return result
    }

    private fun record(offset: Int, limit: Int): Entry {
        require(offset >= 0 && offset + 34 <= limit && limit <= bytes.limit()) { "Malformed PSP ISO directory record." }
        val length = u8(offset)
        require(length >= 34 && offset + length <= limit) { "Malformed PSP ISO record size." }
        val nameLength = u8(offset + 32)
        require(33 + nameLength <= length) { "Malformed PSP ISO filename." }
        val name = readBytes(offset + 33, nameLength).toString(StandardCharsets.ISO_8859_1)
        val extent = u32le(offset + 2)
        val size = u32le(offset + 10)
        val start = extent.toLong() * SECTOR_SIZE
        val end = start + size
        require(extent >= 0 && size >= 0 && start >= 0 && end >= start && end <= bytes.limit().toLong()) {
            "PSP ISO record exceeds image bounds."
        }
        return Entry(name, extent, size, (u8(offset + 25) and 2) != 0)
    }

    private fun normalize(name: String) = name.substringBefore(';').uppercase()
    private fun readBytes(offset: Int, length: Int): ByteArray = ByteArray(length).also { output ->
        val view = bytes.asReadOnlyBuffer()
        view.position(offset)
        view.get(output)
    }
    private fun u8(offset: Int) = bytes.get(offset).toInt() and 0xFF
    private fun ascii(offset: Int, length: Int) = readBytes(offset, length).toString(StandardCharsets.US_ASCII)
    private fun u32le(offset: Int) = u8(offset) or (u8(offset + 1) shl 8) or (u8(offset + 2) shl 16) or (u8(offset + 3) shl 24)
    private data class Entry(val name: String, val extent: Int, val size: Int, val directory: Boolean)

    private companion object { const val SECTOR_SIZE = 2048 }
}
