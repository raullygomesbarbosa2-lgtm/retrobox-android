package com.raully.nebula.psp

/** Initial PSP memory map: main RAM, scratchpad and a separate EDRAM buffer. */
class PspMemory : PspBus {
    private val mainRam = ByteArray(MAIN_RAM_SIZE)
    private val scratchpad = ByteArray(SCRATCHPAD_SIZE)
    private val edram = ByteArray(EDRAM_SIZE)

    override fun read8(address: Int): Int {
        val (region, offset) = locate(address, false)
        return region[offset].toInt() and 0xFF
    }

    override fun read16(address: Int): Int = read8(address) or (read8(address + 1) shl 8)

    override fun read32(address: Int): Int =
        read8(address) or (read8(address + 1) shl 8) or (read8(address + 2) shl 16) or (read8(address + 3) shl 24)

    override fun write8(address: Int, value: Int) {
        val (region, offset) = locate(address, true)
        region[offset] = value.toByte()
    }

    override fun write16(address: Int, value: Int) {
        write8(address, value); write8(address + 1, value ushr 8)
    }

    override fun write32(address: Int, value: Int) {
        repeat(4) { write8(address + it, value ushr (it * 8)) }
    }

    fun loadSegment(address: Int, data: ByteArray, offset: Int = 0, length: Int = data.size - offset) {
        require(offset >= 0 && length >= 0 && offset.toLong() + length <= data.size.toLong()) { "Invalid PSP segment source range." }
        val (region, destination) = locate(address, true)
        require(destination.toLong() + length <= region.size.toLong()) { "PSP segment exceeds its memory region." }
        data.copyInto(region, destination, offset, offset + length)
    }

    fun clearSegment(address: Int, length: Int) {
        require(length >= 0)
        val (region, offset) = locate(address, true)
        require(offset.toLong() + length <= region.size.toLong()) { "PSP BSS exceeds its memory region." }
        region.fill(0, offset, offset + length)
    }

    private fun locate(address: Int, write: Boolean): Pair<ByteArray, Int> {
        val physical = when (address ushr 29) {
            4, 5 -> address and 0x1FFFFFFF
            else -> address
        }
        return when (physical) {
            in MAIN_RAM_BASE until MAIN_RAM_BASE + MAIN_RAM_SIZE -> mainRam to (physical - MAIN_RAM_BASE)
            in SCRATCHPAD_BASE until SCRATCHPAD_BASE + SCRATCHPAD_SIZE -> scratchpad to (physical - SCRATCHPAD_BASE)
            in EDRAM_BASE until EDRAM_BASE + EDRAM_SIZE -> edram to (physical - EDRAM_BASE)
            else -> throw PspBusFault(address, write)
        }
    }

    private companion object {
        const val MAIN_RAM_BASE = 0x08000000
        const val MAIN_RAM_SIZE = 32 * 1024 * 1024
        const val SCRATCHPAD_BASE = 0x00010000
        const val SCRATCHPAD_SIZE = 16 * 1024
        const val EDRAM_BASE = 0x04000000
        const val EDRAM_SIZE = 2 * 1024 * 1024
    }
}
