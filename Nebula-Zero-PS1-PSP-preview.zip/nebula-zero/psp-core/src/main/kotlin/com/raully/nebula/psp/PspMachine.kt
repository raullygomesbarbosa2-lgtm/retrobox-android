package com.raully.nebula.psp

/** Loads plain ELF32/MIPS program segments; encrypted PSP PRX files are not supported yet. */
object PspElfLoader {
    fun load(elf: ByteArray, memory: PspMemory, cpu: AllegrexCpu): PspElfInfo {
        require(elf.size >= ELF_HEADER_SIZE) { "PSP ELF is shorter than its header." }
        require(elf[0] == 0x7F.toByte() && elf[1] == 'E'.code.toByte() && elf[2] == 'L'.code.toByte() && elf[3] == 'F'.code.toByte()) {
            "The selected PSP executable is not an ELF file."
        }
        require((elf[4].toInt() and 0xFF) == 1 && (elf[5].toInt() and 0xFF) == 1) {
            "Only 32-bit little-endian PSP ELF files are supported."
        }
        val entry = u32(elf, 24)
        val phoff = u32(elf, 28)
        val phentsize = u16(elf, 42)
        val phnum = u16(elf, 44)
        require(entry != 0 && phoff >= 0 && phentsize >= PROGRAM_HEADER_SIZE && phnum in 1..MAX_PROGRAM_HEADERS) {
            "Invalid PSP ELF program-header table."
        }
        require(phoff.toLong() + phentsize.toLong() * phnum <= elf.size.toLong()) { "PSP ELF header table exceeds the file." }

        var loadedSegments = 0
        repeat(phnum) { index ->
            val at = phoff + index * phentsize
            if (u32(elf, at) != PT_LOAD) return@repeat
            val fileOffset = u32(elf, at + 4)
            val virtualAddress = u32(elf, at + 8)
            val fileSize = u32(elf, at + 16)
            val memorySize = u32(elf, at + 20)
            require(fileOffset >= 0 && fileSize >= 0 && memorySize >= fileSize) { "Invalid PSP ELF segment sizes." }
            require(fileOffset.toLong() + fileSize <= elf.size.toLong()) { "PSP ELF segment exceeds the file." }
            memory.loadSegment(virtualAddress, elf, fileOffset, fileSize)
            if (memorySize > fileSize) memory.clearSegment(virtualAddress + fileSize, memorySize - fileSize)
            loadedSegments++
        }
        require(loadedSegments > 0) { "PSP ELF has no loadable segments." }
        cpu.startDirect(entry)
        return PspElfInfo(entry, loadedSegments)
    }

    private fun u16(data: ByteArray, at: Int) = (data[at].toInt() and 0xFF) or ((data[at + 1].toInt() and 0xFF) shl 8)
    private fun u32(data: ByteArray, at: Int) = u16(data, at) or (u16(data, at + 2) shl 16)

    private const val ELF_HEADER_SIZE = 52
    private const val PROGRAM_HEADER_SIZE = 32
    private const val MAX_PROGRAM_HEADERS = 128
    private const val PT_LOAD = 1
}

data class PspElfInfo(val entryPoint: Int, val loadedSegments: Int)

/** Initial PSP CPU/memory pairing; UMD, VFPU, GE, audio and HLE services remain incomplete. */
class PspMachine {
    val memory = PspMemory()
    val cpu = AllegrexCpu(memory)

    fun extractEbootFromIso(image: ByteArray): ByteArray = PspIso(image).readEbootBin()
    fun loadDecryptedElf(elf: ByteArray): PspElfInfo = PspElfLoader.load(elf, memory, cpu)
    fun step() = cpu.step()
}
