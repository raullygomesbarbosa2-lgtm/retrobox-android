package com.raully.nebula.psx

import kotlin.test.Test
import kotlin.test.assertEquals

class PsxGpuTest {
    @Test fun fillRectangleConvertsRgbAndRoundsWidthToSixteen() {
        val gpu = PsxGpu()
        gpu.writeGp0(0x020000FF)
        gpu.writeGp0(0)
        gpu.writeGp0((1 shl 16) or 1)
        assertEquals(0x001F, gpu.readVram(0, 0))
        assertEquals(0x001F, gpu.readVram(15, 0))
        assertEquals(0, gpu.readVram(16, 0))
        assertEquals(0xFFFF0000.toInt(), gpu.snapshotArgb()[0])
    }

    @Test fun flatTriangleDrawsIntoVram() {
        val gpu = PsxGpu()
        gpu.writeGp0(0x200000FF)
        gpu.writeGp0(xy(0, 0))
        gpu.writeGp0(xy(8, 0))
        gpu.writeGp0(xy(0, 8))
        assertEquals(0x001F, gpu.readVram(1, 1))
        assertEquals(0, gpu.readVram(8, 8))
    }

    @Test fun imageUploadWritesPackedBgr555Pixels() {
        val gpu = PsxGpu()
        upload(gpu, 2, 3, 2, 1, 0x00007FFF)
        assertEquals(0x7FFF, gpu.readVram(2, 3))
        assertEquals(0, gpu.readVram(3, 3))
    }

    @Test fun textured15BitPolygonSamplesVramAndModulatesColor() {
        val gpu = PsxGpu()
        upload(gpu, 10, 10, 1, 1, 0x0000001F)
        texturedTriangle(gpu, 0x24, xy(100, 100), xy(108, 100), xy(100, 108), uv(10, 10), uv(10, 10, tpage = 0x0100), uv(10, 10))
        assertEquals(0x001F, gpu.readVram(101, 101))
    }

    @Test fun textured4BitPolygonUsesClutPalette() {
        val gpu = PsxGpu()
        upload(gpu, 0, 0, 1, 1, 1)
        upload(gpu, 16, 0, 2, 1, 0x001F0000)
        texturedTriangle(gpu, 0x24, xy(100, 100), xy(108, 100), xy(100, 108), uv(0, 0, clut = 1), uv(0, 0), uv(0, 0))
        assertEquals(0x001F, gpu.readVram(101, 101))
    }

    private fun upload(gpu: PsxGpu, x: Int, y: Int, width: Int, height: Int, vararg words: Int) {
        gpu.writeGp0(0xA0000000.toInt())
        gpu.writeGp0(xy(x, y))
        gpu.writeGp0((height shl 16) or width)
        words.forEach(gpu::writeGp0)
    }

    private fun texturedTriangle(gpu: PsxGpu, opcode: Int, p0: Int, p1: Int, p2: Int, uv0: Int, uv1: Int, uv2: Int) {
        gpu.writeGp0((opcode shl 24) or 0x00808080)
        gpu.writeGp0(p0); gpu.writeGp0(uv0)
        gpu.writeGp0(p1); gpu.writeGp0(uv1)
        gpu.writeGp0(p2); gpu.writeGp0(uv2)
    }

    private fun uv(u: Int, v: Int, clut: Int = 0, tpage: Int = 0) =
        ((if (clut != 0) clut else tpage) shl 16) or ((v and 0xFF) shl 8) or (u and 0xFF)

    private fun xy(x: Int, y: Int) = (y shl 16) or x
}
