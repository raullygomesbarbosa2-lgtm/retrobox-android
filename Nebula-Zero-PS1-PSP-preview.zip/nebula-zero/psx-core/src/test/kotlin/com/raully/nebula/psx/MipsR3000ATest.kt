package com.raully.nebula.psx

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class MipsR3000ATest {
    private class Ram : PsxBus {
        private val words = IntArray(256)
        override fun read8(address: Int) = (words[address ushr 2] ushr ((address and 3) * 8)) and 0xFF
        override fun read16(address: Int) = read8(address) or (read8(address + 1) shl 8)
        override fun read32(address: Int) = words[address ushr 2]
        override fun write8(address: Int, value: Int) {
            val shift = (address and 3) * 8
            val index = address ushr 2
            words[index] = (words[index] and (0xFF shl shift).inv()) or ((value and 0xFF) shl shift)
        }
        override fun write16(address: Int, value: Int) {
            write8(address, value); write8(address + 1, value ushr 8)
        }
        override fun write32(address: Int, value: Int) { words[address ushr 2] = value }
        fun load(address: Int, vararg code: Int) = code.forEachIndexed { i, word -> write32(address + i * 4, word) }
    }

    @Test fun immediateArithmeticAndZeroRegister() {
        val ram = Ram().apply { load(0, i(0x0F, 0, 1, 0x1234), i(0x0D, 1, 2, 0x5678), i(0x09, 2, 0, 1)) }
        val cpu = MipsR3000A(ram).apply { reset(0) }
        repeat(3) { cpu.step() }
        assertEquals(0x12345678, cpu.gpr[2])
        assertEquals(0, cpu.gpr[0])
        assertEquals(3L, cpu.instructionsExecuted)
    }

    @Test fun takenBranchExecutesOneDelaySlotThenJumps() {
        val ram = Ram().apply {
            load(0, i(0x09, 0, 1, 1), i(0x04, 1, 1, 2), i(0x09, 0, 2, 7), i(0x09, 0, 3, 9))
        }
        val cpu = MipsR3000A(ram).apply { reset(0) }
        repeat(4) { cpu.step() }
        assertEquals(7, cpu.gpr[2])
        assertEquals(9, cpu.gpr[3])
        assertEquals(20, cpu.pc)
    }

    @Test fun overflowEntersCop0ExceptionVector() {
        val ram = Ram().apply { load(0, i(0x0F, 0, 1, 0x7FFF), i(0x0D, 1, 1, 0xFFFF), i(0x08, 1, 2, 1)) }
        val cpu = MipsR3000A(ram).apply { reset(0) }
        cpu.step(); cpu.step(); cpu.step()
        assertEquals(PsxExceptionCode.OVERFLOW.value, (cpu.cause ushr 2) and 0x1F)
        assertEquals(8, cpu.epc)
        assertEquals(0xBFC00180.toInt(), cpu.pc)
    }

    @Test fun exceptionInDelaySlotSetsBdAndPointsEpcAtBranch() {
        val ram = Ram().apply { load(0, i(0x04, 0, 0, 2), 0x0000000C) }
        val cpu = MipsR3000A(ram).apply { reset(0) }
        cpu.step()
        cpu.step()
        assertEquals(0, cpu.epc)
        assertEquals(1, (cpu.cause ushr 31) and 1)
        assertEquals(PsxExceptionCode.SYSCALL.value, (cpu.cause ushr 2) and 0x1F)
        assertEquals(0xBFC00180.toInt(), cpu.pc)
    }

    @Test fun unalignedLoadReportsBadVAddr() {
        val ram = Ram().apply { load(0, i(0x23, 1, 2, 0)) }
        val cpu = MipsR3000A(ram).apply { reset(0); gpr[1] = 0x1001 }
        cpu.step()
        assertEquals(PsxExceptionCode.ADDRESS_LOAD.value, (cpu.cause ushr 2) and 0x1F)
        assertEquals(0x1001, cpu.badVAddr)
        assertEquals(0, cpu.epc)
    }

    @Test fun cp2InstructionRaisesCoprocessorUnusableWithCeField() {
        val ram = Ram().apply { load(0, 0x12 shl 26) }
        val cpu = MipsR3000A(ram).apply { reset(0) }
        cpu.step()
        assertEquals(PsxExceptionCode.COPROCESSOR_UNUSABLE.value, (cpu.cause ushr 2) and 0x1F)
        assertEquals(2, (cpu.cause ushr 28) and 3)
    }

    @Test fun cop0StatusMoveAndRfeRestoreModeStack() {
        val initial = (1 shl 4) or (1 shl 2) or 1
        val ram = Ram().apply {
            load(0, cop0(rs = 4, rt = 1, rd = 12), cop0(rs = 16, function = 0x10))
        }
        val cpu = MipsR3000A(ram).apply { reset(0); gpr[1] = initial }
        cpu.step()
        assertEquals(initial, cpu.status)
        cpu.step()
        assertEquals(0b010101, cpu.status and 0x3F)
    }

    @Test fun memoryMirrorsRamAndMapsScratchpadAndUserFirmware() {
        val memory = PsxMemory()
        memory.write32(0x100, 0x12345678)
        assertEquals(0x12345678, memory.read32(0x200100))
        memory.write8(0x1F800010, 0xAB)
        assertEquals(0xAB, memory.read8(0x1F800010))
        val bios = ByteArray(512 * 1024) { (it and 0xFF).toByte() }
        memory.loadFirmware(bios)
        assertEquals(0x03020100, memory.read32(0x1FC00000))
        assertFailsWith<PsxBusFault> { memory.write8(0x1FC00000, 0) }
    }

    private fun i(op: Int, rs: Int, rt: Int, imm: Int) =
        (op shl 26) or (rs shl 21) or (rt shl 16) or (imm and 0xFFFF)

    private fun cop0(rs: Int, rt: Int = 0, rd: Int = 0, function: Int = 0) =
        (0x10 shl 26) or (rs shl 21) or (rt shl 16) or (rd shl 11) or function
}
