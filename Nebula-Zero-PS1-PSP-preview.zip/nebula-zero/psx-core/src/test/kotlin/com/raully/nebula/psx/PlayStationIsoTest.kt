package com.raully.nebula.psx

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class PlayStationIsoTest {
    @Test fun findsSystemCnfBootTargetAndReadsFile() {
        val system = "BOOT = cdrom:\\SLUS_000.00;1\nTCB = 4\n".toByteArray(Charsets.US_ASCII)
        val executable = makeExe()
        val iso = makeIso(system, executable)
        val disc = PlayStationIso(iso)
        assertEquals("/SLUS_000.00;1", disc.bootExecutablePath())
        assertEquals(executable.toList(), disc.readBootExecutable().toList())
    }

    @Test fun loadsPsxExeIntoRamAndSetsInitialCpuRegisters() {
        val memory = PsxMemory()
        val cpu = MipsR3000A(memory)
        val executable = makeExe()
        val loaded = PsxExeLoader.load(executable, memory, cpu)
        assertEquals(0x80010000.toInt(), loaded.entryPoint)
        assertEquals(0x80020000.toInt(), loaded.globalPointer)
        assertEquals(0x80100100.toInt(), loaded.stackPointer)
        assertEquals(0x04030201, memory.read32(0x10000))
        assertEquals(0x80010000.toInt(), cpu.pc)
        assertEquals(0x80020000.toInt(), cpu.gpr[28])
        assertEquals(0x80100100.toInt(), cpu.gpr[29])
    }

    @Test fun rejectsNonIsoImagesAndBadExeHeaders() {
        assertFailsWith<IllegalArgumentException> { PlayStationIso(ByteArray(17 * SECTOR_SIZE)) }
        assertFailsWith<IllegalArgumentException> { PsxExeLoader.load(ByteArray(HEADER_SIZE), PsxMemory(), MipsR3000A(PsxMemory())) }
    }

    private fun makeIso(systemCnf: ByteArray, exe: ByteArray): ByteArray {
        val image = ByteArray(24 * SECTOR_SIZE)
        val pvd = VOLUME_DESCRIPTOR_SECTOR * SECTOR_SIZE
        image[pvd] = 1
        "CD001".toByteArray(Charsets.US_ASCII).copyInto(image, pvd + 1)
        image[pvd + 6] = 1
        writeDirectoryRecord(image, pvd + ROOT_RECORD_OFFSET, 0, ROOT_SECTOR, SECTOR_SIZE, true)

        var cursor = ROOT_SECTOR * SECTOR_SIZE
        cursor = writeDirectoryRecord(image, cursor, 0, ROOT_SECTOR, SECTOR_SIZE, true)
        cursor = writeDirectoryRecord(image, cursor, 1, ROOT_SECTOR, SECTOR_SIZE, true)
        cursor = writeDirectoryRecord(image, cursor, "SYSTEM.CNF;1".toByteArray(Charsets.US_ASCII), SYSTEM_SECTOR, systemCnf.size, false)
        writeDirectoryRecord(image, cursor, "SLUS_000.00;1".toByteArray(Charsets.US_ASCII), EXE_SECTOR, exe.size, false)
        systemCnf.copyInto(image, SYSTEM_SECTOR * SECTOR_SIZE)
        exe.copyInto(image, EXE_SECTOR * SECTOR_SIZE)
        return image
    }

    private fun makeExe(): ByteArray {
        val bytes = ByteArray(HEADER_SIZE + 4)
        "PS-X EXE".toByteArray(Charsets.US_ASCII).copyInto(bytes, 0)
        put32(bytes, 0x10, 0x80010000.toInt())
        put32(bytes, 0x14, 0x80020000.toInt())
        put32(bytes, 0x18, 0x80010000.toInt())
        put32(bytes, 0x1C, 4)
        put32(bytes, 0x30, 0x80100000.toInt())
        put32(bytes, 0x34, 0x100)
        bytes[HEADER_SIZE] = 1
        bytes[HEADER_SIZE + 1] = 2
        bytes[HEADER_SIZE + 2] = 3
        bytes[HEADER_SIZE + 3] = 4
        return bytes
    }

    private fun writeDirectoryRecord(
        out: ByteArray,
        offset: Int,
        identifier: Int,
        extent: Int,
        length: Int,
        directory: Boolean
    ): Int = writeDirectoryRecord(out, offset, byteArrayOf(identifier.toByte()), extent, length, directory)

    private fun writeDirectoryRecord(
        out: ByteArray,
        offset: Int,
        identifier: ByteArray,
        extent: Int,
        length: Int,
        directory: Boolean
    ): Int {
        val recordLength = 33 + identifier.size + if (identifier.size % 2 == 0) 1 else 0
        out[offset] = recordLength.toByte()
        put32(out, offset + 2, extent)
        put32(out, offset + 10, length)
        out[offset + 25] = if (directory) 2 else 0
        out[offset + 32] = identifier.size.toByte()
        identifier.copyInto(out, offset + 33)
        return offset + recordLength
    }

    private fun put32(out: ByteArray, offset: Int, value: Int) {
        repeat(4) { index -> out[offset + index] = (value ushr (index * 8)).toByte() }
    }

    private companion object {
        const val SECTOR_SIZE = 2048
        const val VOLUME_DESCRIPTOR_SECTOR = 16
        const val ROOT_RECORD_OFFSET = 156
        const val ROOT_SECTOR = 20
        const val SYSTEM_SECTOR = 21
        const val EXE_SECTOR = 22
        const val HEADER_SIZE = 0x800
    }
}
