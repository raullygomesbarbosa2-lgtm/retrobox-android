package com.raully.nebula.psx

import kotlin.test.Test
import kotlin.test.assertEquals

class PsxMachineTest {
    @Test fun cpuStoresReachGpuAndProduceArgbFrameBuffer() {
        val machine = PsxMachine()
        val program = intArrayOf(
            i(0x0F, 0, 1, 0x1F80),
            i(0x0D, 1, 1, 0x1810),
            i(0x0F, 0, 2, 0x0200),
            i(0x0D, 2, 2, 0x00FF),
            i(0x2B, 1, 2, 0),
            i(0x2B, 1, 0, 0),
            i(0x0F, 0, 3, 1),
            i(0x0D, 3, 3, 1),
            i(0x2B, 1, 3, 0)
        )
        val bytes = ByteArray(program.size * 4)
        program.forEachIndexed { index, word -> put32(bytes, index * 4, word) }
        machine.memory.loadRam(0, bytes)
        machine.cpu.startDirect(0x80000000.toInt(), 0, 0)
        repeat(program.size) { machine.step() }
        assertEquals(0x001F, machine.gpu.readVram(0, 0))
        assertEquals(0xFFFF0000.toInt(), machine.frameBufferArgb()[0])
    }

    private fun i(op: Int, rs: Int, rt: Int, imm: Int) =
        (op shl 26) or (rs shl 21) or (rt shl 16) or (imm and 0xFFFF)

    private fun put32(data: ByteArray, at: Int, value: Int) {
        repeat(4) { data[at + it] = (value ushr (it * 8)).toByte() }
    }
}
