package com.raully.nebula.psx

import java.nio.charset.StandardCharsets

/** Minimal read-only ISO-9660 reader for 2048-byte data-sector .iso images. */
class PlayStationIso(private val image: ByteArray) {
    private val root: DirectoryEntry

    init {
        require(image.size >= (VOLUME_DESCRIPTOR_SECTOR + 1) * SECTOR_SIZE) { "Disc image is too small to contain an ISO-9660 volume descriptor." }
        val descriptor = VOLUME_DESCRIPTOR_SECTOR * SECTOR_SIZE
        require(u8(descriptor) == 1 && ascii(descriptor + 1, 5) == "CD001" && u8(descriptor + 6) == 1) {
            "This image does not contain a supported ISO-9660 primary volume descriptor."
        }
        root = parseRecord(descriptor + ROOT_RECORD_OFFSET, descriptor + SECTOR_SIZE)
        require(root.directory) { "ISO-9660 root record is not a directory." }
    }

    /** Reads a file by ISO path; names are case-insensitive and ;version suffixes are ignored. */
    fun readFile(path: String): ByteArray {
        val components = normalizePath(path)
        require(components.isNotEmpty()) { "A file path is required." }
        var current = root
        components.dropLast(1).forEach { component ->
            current = listDirectory(current).firstOrNull { it.directory && normalizedName(it.name) == component }
                ?: error("Directory '$component' was not found on the disc.")
        }
        val file = listDirectory(current).firstOrNull { !it.directory && normalizedName(it.name) == components.last() }
            ?: error("File '${components.last()}' was not found on the disc.")
        return image.copyOfRange(file.extent * SECTOR_SIZE, file.extent * SECTOR_SIZE + file.byteLength)
    }

    /** Resolves SYSTEM.CNF's BOOT entry and returns its target file path. */
    fun bootExecutablePath(): String {
        val systemCnf = readFile("SYSTEM.CNF").toString(StandardCharsets.ISO_8859_1)
        val bootLine = systemCnf.lineSequence().firstOrNull { it.substringBefore('=').trim().equals("BOOT", ignoreCase = true) }
            ?: error("SYSTEM.CNF has no BOOT entry.")
        val value = bootLine.substringAfter('=', "").trim().trim('"', '\'')
        val cdromSeparator = value.indexOf(':')
        require(cdromSeparator >= 0) { "Unsupported BOOT path in SYSTEM.CNF." }
        val path = value.substring(cdromSeparator + 1).trim().replace('\\', '/')
        require(normalizePath(path).isNotEmpty()) { "SYSTEM.CNF contains an empty BOOT path." }
        return path
    }

    fun readBootExecutable(): ByteArray = readFile(bootExecutablePath())

    private fun listDirectory(directory: DirectoryEntry): List<DirectoryEntry> {
        require(directory.directory) { "Cannot enumerate a non-directory ISO entry." }
        val start = directory.extent * SECTOR_SIZE
        val end = start + directory.byteLength
        require(start >= 0 && end >= start && end <= image.size) { "ISO directory points outside the image." }
        val found = ArrayList<DirectoryEntry>()
        var offset = start
        while (offset < end) {
            val recordLength = u8(offset)
            if (recordLength == 0) {
                offset = ((offset / SECTOR_SIZE) + 1) * SECTOR_SIZE
                continue
            }
            val recordEnd = offset + recordLength
            if (recordEnd > end) error("Truncated ISO-9660 directory record.")
            val entry = parseRecord(offset, recordEnd)
            if (entry.name != "\u0000" && entry.name != "\u0001") found += entry
            offset = recordEnd
        }
        return found
    }

    private fun parseRecord(offset: Int, limit: Int): DirectoryEntry {
        require(offset >= 0 && offset + 34 <= limit && limit <= image.size) { "Invalid ISO-9660 directory record." }
        val recordLength = u8(offset)
        require(recordLength >= 34 && offset + recordLength <= limit) { "Malformed ISO-9660 directory record." }
        val nameLength = u8(offset + 32)
        require(33 + nameLength <= recordLength) { "Malformed ISO-9660 filename record." }
        val rawName = image.copyOfRange(offset + 33, offset + 33 + nameLength).toString(StandardCharsets.ISO_8859_1)
        val extent = u32le(offset + 2)
        val length = u32le(offset + 10)
        val flags = u8(offset + 25)
        val byteStart = extent.toLong() * SECTOR_SIZE
        val byteEnd = byteStart + length
        require(extent >= 0 && length >= 0 && byteStart >= 0 && byteEnd >= byteStart && byteEnd <= image.size.toLong()) {
            "ISO entry points outside the image."
        }
        return DirectoryEntry(rawName, extent, length, (flags and DIRECTORY_FLAG) != 0)
    }

    private fun normalizePath(path: String): List<String> = path
        .replace('\\', '/')
        .split('/')
        .map { normalizedName(it.trim()) }
        .filter { it.isNotEmpty() }

    private fun normalizedName(name: String): String = name.substringBefore(';').uppercase()

    private fun ascii(offset: Int, length: Int) = image.copyOfRange(offset, offset + length).toString(StandardCharsets.US_ASCII)
    private fun u8(offset: Int) = image[offset].toInt() and 0xFF
    private fun u32le(offset: Int): Int = u8(offset) or (u8(offset + 1) shl 8) or (u8(offset + 2) shl 16) or (u8(offset + 3) shl 24)

    private data class DirectoryEntry(val name: String, val extent: Int, val byteLength: Int, val directory: Boolean)

    private companion object {
        const val SECTOR_SIZE = 2048
        const val VOLUME_DESCRIPTOR_SECTOR = 16
        const val ROOT_RECORD_OFFSET = 156
        const val DIRECTORY_FLAG = 0x02
    }
}

/** Loads the standard 0x800-byte PS-X EXE header and starts it directly, without BIOS code. */
object PsxExeLoader {
    private const val HEADER_SIZE = 0x800
    private val defaultStack = 0x801FFF00.toInt()

    fun load(executable: ByteArray, memory: PsxMemory, cpu: MipsR3000A): LoadedPsxExecutable {
        require(executable.size >= HEADER_SIZE) { "PS-X EXE is shorter than its header." }
        require(executable.copyOfRange(0, 8).toString(StandardCharsets.US_ASCII) == "PS-X EXE") {
            "The selected file is not a PS-X EXE."
        }

        val entryPoint = u32le(executable, 0x10)
        val globalPointer = u32le(executable, 0x14)
        val loadAddress = u32le(executable, 0x18)
        val payloadLength = u32le(executable, 0x1C)
        val memoryClearAddress = u32le(executable, 0x28)
        val memoryClearLength = u32le(executable, 0x2C)
        val stackBase = u32le(executable, 0x30)
        val stackOffset = u32le(executable, 0x34)
        require(payloadLength >= 0 && HEADER_SIZE.toLong() + payloadLength <= executable.size.toLong()) {
            "PS-X EXE payload length is invalid."
        }
        require(entryPoint != 0 && payloadLength > 0) { "PS-X EXE has no entry point or program data." }

        if (memoryClearLength > 0) memory.clearRam(memoryClearAddress, memoryClearLength)
        memory.loadRam(loadAddress, executable, HEADER_SIZE, payloadLength)
        val stackPointer = if (stackBase == 0 && stackOffset == 0) defaultStack else stackBase + stackOffset
        cpu.startDirect(entryPoint, globalPointer, stackPointer)
        return LoadedPsxExecutable(entryPoint, globalPointer, loadAddress, payloadLength, stackPointer)
    }

    private fun u32le(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xFF) or
            ((bytes[offset + 1].toInt() and 0xFF) shl 8) or
            ((bytes[offset + 2].toInt() and 0xFF) shl 16) or
            ((bytes[offset + 3].toInt() and 0xFF) shl 24)
}

data class LoadedPsxExecutable(
    val entryPoint: Int,
    val globalPointer: Int,
    val loadAddress: Int,
    val byteLength: Int,
    val stackPointer: Int
)
