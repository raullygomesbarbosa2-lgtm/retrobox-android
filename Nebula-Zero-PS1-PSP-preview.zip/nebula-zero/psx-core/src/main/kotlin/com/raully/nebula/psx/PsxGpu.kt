package com.raully.nebula.psx

/**
 * Original software-rendered GP0 foundation. It draws selected flat and textured
 * primitives into a PS1-sized 16-bit VRAM buffer. Blending, exact GPU timing and
 * GPU registers on the CPU bus are not implemented yet.
 */
class PsxGpu {
    private val vram = IntArray(VRAM_WIDTH * VRAM_HEIGHT)
    private val packet = IntArray(MAX_PACKET_WORDS)
    private var packetSize = 0
    private var expectedWords = 0
    private var uploadRemainingWords = 0
    private var uploadX = 0
    private var uploadY = 0
    private var uploadWidth = 0
    private var uploadPixelsRemaining = 0
    private var uploadPixelIndex = 0

    private var drawLeft = 0
    private var drawTop = 0
    private var drawRight = VRAM_WIDTH - 1
    private var drawBottom = VRAM_HEIGHT - 1
    private var offsetX = 0
    private var offsetY = 0
    private var maskSet = false
    private var checkMask = false

    /** Supplies one 32-bit word to the GP0 command stream. */
    fun writeGp0(word: Int) {
        if (uploadRemainingWords > 0) {
            consumeUploadWord(word)
            return
        }
        if (packetSize == 0) expectedWords = packetLength(word)
        if (packetSize >= packet.size) {
            packetSize = 0
            expectedWords = 0
            return
        }
        packet[packetSize++] = word
        if (packetSize == expectedWords) {
            executePacket()
            packetSize = 0
            expectedWords = 0
        }
    }

    /** GP1 command subset for resetting this unit. */
    fun writeGp1(word: Int) {
        when ((word ushr 24) and 0xFF) {
            0x00, 0x01 -> resetCommandState()
            0x02 -> {
                vram.fill(0)
                resetCommandState()
            }
        }
    }

    fun readVram(x: Int, y: Int): Int {
        require(x in 0 until VRAM_WIDTH && y in 0 until VRAM_HEIGHT)
        return vram[y * VRAM_WIDTH + x]
    }

    /** Returns a newly allocated opaque ARGB snapshot for a later Android display surface. */
    fun snapshotArgb(): IntArray = IntArray(vram.size) { index ->
        val color = vram[index]
        val r = (color and 0x1F) * 255 / 31
        val g = ((color ushr 5) and 0x1F) * 255 / 31
        val b = ((color ushr 10) and 0x1F) * 255 / 31
        (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    fun resetCommandState() {
        packetSize = 0
        expectedWords = 0
        uploadRemainingWords = 0
        uploadPixelsRemaining = 0
        uploadPixelIndex = 0
        drawLeft = 0
        drawTop = 0
        drawRight = VRAM_WIDTH - 1
        drawBottom = VRAM_HEIGHT - 1
        offsetX = 0
        offsetY = 0
        maskSet = false
        checkMask = false
    }

    private fun packetLength(command: Int): Int {
        val opcode = (command ushr 24) and 0xFF
        return when {
            opcode == 0x80 -> 4
            opcode == 0xA0 || opcode == 0xC0 -> 3
            (opcode and 0xE0) == 0x20 || (opcode and 0xE0) == 0x30 -> {
                val gouraud = (opcode and 0x10) != 0
                val textured = (opcode and 0x04) != 0
                val vertices = if ((opcode and 0x08) != 0) 4 else 3
                1 + vertices + (if (textured) vertices else 0) + (if (gouraud) vertices - 1 else 0)
            }
            (opcode and 0xE0) == 0x40 -> if ((opcode and 0x10) != 0) 4 else 3
            (opcode and 0xE0) == 0x60 -> {
                val textured = (opcode and 0x04) != 0
                val variableSize = (opcode and 0x18) == 0x00
                2 + (if (textured) 1 else 0) + (if (variableSize) 1 else 0)
            }
            opcode in 0xE1..0xE6 -> 1
            opcode == 0x02 -> 3
            else -> 1
        }.coerceIn(1, MAX_PACKET_WORDS)
    }

    private fun executePacket() {
        val opcode = (packet[0] ushr 24) and 0xFF
        when {
            opcode == 0x02 -> fillRectangle(packet[0], packet[1], packet[2])
            (opcode and 0xE0) == 0x20 -> drawPolygon(opcode)
            (opcode and 0xE0) == 0x60 && (opcode and 0x04) == 0 -> drawRectangle(opcode)
            opcode == 0x80 -> copyVram(packet[1], packet[2], packet[3])
            opcode == 0xA0 -> beginImageUpload(packet[1], packet[2])
            opcode == 0xE1 -> Unit // draw-mode state reserved for texture support
            opcode == 0xE3 -> {
                drawLeft = packet[0] and 0x3FF
                drawTop = (packet[0] ushr 10) and 0x1FF
            }
            opcode == 0xE4 -> {
                drawRight = packet[0] and 0x3FF
                drawBottom = (packet[0] ushr 10) and 0x1FF
            }
            opcode == 0xE5 -> {
                offsetX = signExtend11(packet[0] and 0x7FF)
                offsetY = signExtend11((packet[0] ushr 11) and 0x7FF)
            }
            opcode == 0xE6 -> {
                maskSet = (packet[0] and 1) != 0
                checkMask = (packet[0] and 2) != 0
            }
            // Unsupported opcodes and line packets are consumed without drawing.
        }
    }

    private fun beginImageUpload(xyWord: Int, sizeWord: Int) {
        uploadX = xyWord and 0x3FF
        uploadY = (xyWord ushr 16) and 0x1FF
        val encodedWidth = sizeWord and 0x3FF
        val encodedHeight = (sizeWord ushr 16) and 0x1FF
        val width = if (encodedWidth == 0) VRAM_WIDTH else encodedWidth
        val height = if (encodedHeight == 0) VRAM_HEIGHT else encodedHeight
        uploadWidth = width
        uploadPixelsRemaining = width * height
        uploadPixelIndex = 0
        uploadRemainingWords = (uploadPixelsRemaining + 1) / 2
    }

    private fun consumeUploadWord(word: Int) {
        repeat(2) { half ->
            if (uploadPixelsRemaining <= 0) return@repeat
            val x = (uploadX + uploadPixelIndex % uploadWidth) and 0x3FF
            val y = (uploadY + uploadPixelIndex / uploadWidth) and 0x1FF
            val color = (word ushr (half * 16)) and 0xFFFF
            vram[y * VRAM_WIDTH + x] = color
            uploadPixelIndex++
            uploadPixelsRemaining--
        }
        uploadRemainingWords--
    }

    private fun copyVram(sourceWord: Int, destinationWord: Int, sizeWord: Int) {
        val sx = sourceWord and 0x3FF
        val sy = (sourceWord ushr 16) and 0x1FF
        val dx = destinationWord and 0x3FF
        val dy = (destinationWord ushr 16) and 0x1FF
        val encodedWidth = sizeWord and 0x3FF
        val encodedHeight = (sizeWord ushr 16) and 0x1FF
        val width = if (encodedWidth == 0) VRAM_WIDTH else encodedWidth
        val height = if (encodedHeight == 0) VRAM_HEIGHT else encodedHeight
        val copy = IntArray(width * height)
        var index = 0
        for (y in 0 until height) for (x in 0 until width) {
            copy[index++] = vram[((sy + y) and 0x1FF) * VRAM_WIDTH + ((sx + x) and 0x3FF)]
        }
        index = 0
        for (y in 0 until height) for (x in 0 until width) {
            vram[((dy + y) and 0x1FF) * VRAM_WIDTH + ((dx + x) and 0x3FF)] = copy[index++]
        }
    }

    private fun drawPolygon(opcode: Int) {
        val count = if ((opcode and 0x08) != 0) 4 else 3
        val gouraud = (opcode and 0x10) != 0
        val textured = (opcode and 0x04) != 0
        val vertices = ArrayList<PolygonVertex>(count)
        var cursor = 1
        for (index in 0 until count) {
            val color = if (index == 0 || !gouraud) packet[0] else packet[cursor++]
            val rawPoint = point(packet[cursor++])
            val uv = if (textured) packet[cursor++] else 0
            vertices += PolygonVertex(Point(rawPoint.x + offsetX, rawPoint.y + offsetY), uv, color and 0x00FFFFFF)
        }
        val clut = if (textured) (vertices[0].uv ushr 16) and 0xFFFF else 0
        val tpage = if (textured && vertices.size > 1) (vertices[1].uv ushr 16) and 0xFFFF else 0
        rasterTriangle(vertices[0], vertices[1], vertices[2], textured, clut, tpage)
        if (count == 4) rasterTriangle(vertices[0], vertices[2], vertices[3], textured, clut, tpage)
    }

    private fun drawRectangle(opcode: Int) {
        val origin = point(packet[1])
        val sizeWord = when (opcode and 0x18) {
            0x08 -> 0x00010001
            0x10 -> 0x00080008
            0x18 -> 0x00100010
            else -> packet[2]
        }
        val width = sizeWord and 0xFFFF
        val height = (sizeWord ushr 16) and 0xFFFF
        drawRect(origin.x + offsetX, origin.y + offsetY, width, height, rgb24ToBgr555(packet[0]))
    }

    private fun fillRectangle(colorWord: Int, xyWord: Int, sizeWord: Int) {
        val p = point(xyWord)
        val width = sizeWord and 0xFFFF
        val height = (sizeWord ushr 16) and 0xFFFF
        val alignedWidth = if (width == 0) 0 else (width + 15) and -16
        drawRect(p.x, p.y, alignedWidth, height, rgb24ToBgr555(colorWord), obeyDrawArea = false)
    }

    private fun drawRect(x: Int, y: Int, width: Int, height: Int, color: Int, obeyDrawArea: Boolean = true) {
        if (width <= 0 || height <= 0) return
        val left = maxOf(x, 0, if (obeyDrawArea) drawLeft else 0)
        val top = maxOf(y, 0, if (obeyDrawArea) drawTop else 0)
        val right = minOf(x.toLong() + width - 1, VRAM_WIDTH - 1L, if (obeyDrawArea) drawRight.toLong() else VRAM_WIDTH - 1L).toInt()
        val bottom = minOf(y.toLong() + height - 1, VRAM_HEIGHT - 1L, if (obeyDrawArea) drawBottom.toLong() else VRAM_HEIGHT - 1L).toInt()
        if (left > right || top > bottom) return
        for (py in top..bottom) for (px in left..right) plot(px, py, color)
    }

    private fun rasterTriangle(
        first: PolygonVertex,
        second: PolygonVertex,
        third: PolygonVertex,
        textured: Boolean,
        clut: Int,
        tpage: Int
    ) {
        var a = first
        var b = second
        var c = third
        var area = edge(a.point, b.point, c.point.x, c.point.y)
        if (area == 0L) return
        if (area < 0) {
            area = -area
            val swap = b
            b = c
            c = swap
        }
        val left = maxOf(minOf(a.point.x, b.point.x, c.point.x), 0, drawLeft)
        val top = maxOf(minOf(a.point.y, b.point.y, c.point.y), 0, drawTop)
        val right = minOf(maxOf(a.point.x, b.point.x, c.point.x), VRAM_WIDTH - 1, drawRight)
        val bottom = minOf(maxOf(a.point.y, b.point.y, c.point.y), VRAM_HEIGHT - 1, drawBottom)
        if (left > right || top > bottom) return
        for (y in top..bottom) for (x in left..right) {
            val w0 = edge(b.point, c.point, x, y)
            val w1 = edge(c.point, a.point, x, y)
            val w2 = edge(a.point, b.point, x, y)
            if (w0 < 0 || w1 < 0 || w2 < 0) continue
            val color = interpolateColor(a.color, b.color, c.color, w0, w1, w2, area)
            if (textured) {
                val u = interpolateUv(a.uv and 0xFF, b.uv and 0xFF, c.uv and 0xFF, w0, w1, w2, area)
                val v = interpolateUv((a.uv ushr 8) and 0xFF, (b.uv ushr 8) and 0xFF, (c.uv ushr 8) and 0xFF, w0, w1, w2, area)
                val texel = sampleTexture(u, v, clut, tpage) ?: continue
                if ((texel and 0x7FFF) == 0 && (texel and 0x8000) == 0) continue
                plot(x, y, modulateTexture(texel, color))
            } else {
                plot(x, y, rgb24ToBgr555(color))
            }
        }
    }

    private fun sampleTexture(u: Int, v: Int, clut: Int, tpage: Int): Int? {
        val pageX = (tpage and 0x0F) * 64
        val pageY = ((tpage ushr 4) and 1) * 256
        val depth = (tpage ushr 7) and 3
        return when (depth) {
            0 -> {
                val packed = vram[((pageY + v) and 0x1FF) * VRAM_WIDTH + ((pageX + (u ushr 2)) and 0x3FF)]
                val index = (packed ushr ((u and 3) * 4)) and 0x0F
                val clutX = ((clut and 0x3F) * 16 + index) and 0x3FF
                val clutY = (clut ushr 6) and 0x1FF
                vram[clutY * VRAM_WIDTH + clutX]
            }
            1 -> {
                val packed = vram[((pageY + v) and 0x1FF) * VRAM_WIDTH + ((pageX + (u ushr 1)) and 0x3FF)]
                val index = (packed ushr ((u and 1) * 8)) and 0xFF
                val clutX = ((clut and 0x3F) * 16 + index) and 0x3FF
                val clutY = (clut ushr 6) and 0x1FF
                vram[clutY * VRAM_WIDTH + clutX]
            }
            2 -> vram[((pageY + v) and 0x1FF) * VRAM_WIDTH + ((pageX + u) and 0x3FF)]
            else -> null
        }
    }

    private fun interpolateColor(a: Int, b: Int, c: Int, wa: Long, wb: Long, wc: Long, area: Long): Int {
        fun channel(shift: Int) = (((((a ushr shift) and 0xFF) * wa) + (((b ushr shift) and 0xFF) * wb) + (((c ushr shift) and 0xFF) * wc) + area / 2) / area).toInt().coerceIn(0, 255)
        return channel(0) or (channel(8) shl 8) or (channel(16) shl 16)
    }

    private fun interpolateUv(a: Int, b: Int, c: Int, wa: Long, wb: Long, wc: Long, area: Long): Int =
        (((a * wa) + (b * wb) + (c * wc) + area / 2) / area).toInt().coerceIn(0, 255)

    private fun modulateTexture(texel: Int, color: Int): Int {
        fun channel(texShift: Int, colorShift: Int): Int {
            val texture8 = ((texel ushr texShift) and 0x1F) * 255 / 31
            val modulation = (color ushr colorShift) and 0xFF
            return (texture8 * modulation / 128).coerceAtMost(255)
        }
        val rgb = channel(0, 0) or (channel(5, 8) shl 8) or (channel(10, 16) shl 16)
        return rgb24ToBgr555(rgb)
    }

    private fun plot(x: Int, y: Int, rawColor: Int) {
        if (x !in 0 until VRAM_WIDTH || y !in 0 until VRAM_HEIGHT) return
        val index = y * VRAM_WIDTH + x
        val old = vram[index]
        if (checkMask && (old and 0x8000) != 0) return
        vram[index] = (rawColor and 0x7FFF) or (if (maskSet) 0x8000 else 0)
    }

    private fun point(word: Int) = Point(signExtend11(word and 0x7FF), signExtend11((word ushr 16) and 0x7FF))
    private fun signExtend11(value: Int) = (value shl 21) shr 21
    private fun edge(a: Point, b: Point, x: Int, y: Int): Long =
        (x - a.x).toLong() * (b.y - a.y) - (y - a.y).toLong() * (b.x - a.x)

    private fun rgb24ToBgr555(word: Int): Int =
        ((word and 0xFF) ushr 3) or (((word ushr 8) and 0xFF) ushr 3 shl 5) or
            (((word ushr 16) and 0xFF) ushr 3 shl 10)

    private data class Point(val x: Int, val y: Int)
    private data class PolygonVertex(val point: Point, val uv: Int, val color: Int)

    companion object {
        const val VRAM_WIDTH = 1024
        const val VRAM_HEIGHT = 512
        const val VRAM_SIZE = VRAM_WIDTH * VRAM_HEIGHT
        private const val MAX_PACKET_WORDS = 16
    }
}
