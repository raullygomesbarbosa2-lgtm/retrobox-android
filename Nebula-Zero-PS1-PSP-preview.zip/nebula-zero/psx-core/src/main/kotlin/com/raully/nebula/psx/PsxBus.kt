package com.raully.nebula.psx

/** Address/data interface owned by this project; addresses are physical 32-bit addresses. */
interface PsxBus {
    fun read8(address: Int): Int
    fun read16(address: Int): Int
    fun read32(address: Int): Int
    fun write8(address: Int, value: Int)
    fun write16(address: Int, value: Int)
    fun write32(address: Int, value: Int)
}

class PsxBusFault(val address: Int, val isWrite: Boolean) : RuntimeException(
    "Unmapped ${if (isWrite) "write" else "read"} at 0x${address.toUInt().toString(16)}"
)

enum class PsxExceptionCode(val value: Int) {
    INTERRUPT(0), ADDRESS_LOAD(4), ADDRESS_STORE(5), BUS_INSTRUCTION(6), BUS_DATA(7),
    SYSCALL(8), BREAKPOINT(9), RESERVED_INSTRUCTION(10), COPROCESSOR_UNUSABLE(11), OVERFLOW(12)
}

/** Internal architectural trap; CPU.step() converts it into a PlayStation exception. */
internal class PsxTrap(
    val code: PsxExceptionCode,
    val badAddress: Int? = null,
    val coprocessor: Int = 0
) : RuntimeException()
