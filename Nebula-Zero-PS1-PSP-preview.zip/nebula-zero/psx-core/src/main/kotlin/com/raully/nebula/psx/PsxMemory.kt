package com.raully.nebula.psx

/**
 * First project-authored PS1 memory map slice: mirrored 2 MiB main RAM,
 * 1 KiB scratchpad, and an optional user-supplied 512 KiB firmware image.
 * Hardware registers and the rest of the bus are deliberately not emulated yet.
 */
class PsxMemory : PsxBus {
    private val ram = ByteArray(RAM_SIZE)
    private val scratchpad = ByteArray(SCRATCHPAD_SIZE)
    private val firmware = ByteArray(FIRMWARE_SIZE)
    private var firmwareLoaded = false

    override fun read8(address: Int): Int = when {
        address in RAM_START..RAM_END -> ram[address and RAM_MASK].toInt() and 0xFF
        address in SCRATCHPAD_START..SCRATCHPAD_END -> scratchpad[address - SCRATCHPAD_START].toInt() and 0xFF
        address in FIRMWARE_START..FIRMWARE_END && firmwareLoaded -> firmware[address - FIRMWARE_START].toInt() and 0xFF
        address in FIRMWARE_START..FIRMWARE_END -> throw PsxBusFault(address, false)
        else -> throw PsxBusFault(address, false)
    }

    override fun read16(address: Int): Int = read8(address) or (read8(address + 1) shl 8)

    override fun read32(address: Int): Int =
        read8(address) or (read8(address + 1) shl 8) or
            (read8(address + 2) shl 16) or (read8(address + 3) shl 24)

    override fun write8(address: Int, value: Int) {
        when {
            address in RAM_START..RAM_END -> ram[address and RAM_MASK] = value.toByte()
            address in SCRATCHPAD_START..SCRATCHPAD_END -> scratchpad[address - SCRATCHPAD_START] = value.toByte()
            else -> throw PsxBusFault(address, true)
        }
    }

    override fun write16(address: Int, value: Int) {
        write8(address, value)
        write8(address + 1, value ushr 8)
    }

    override fun write32(address: Int, value: Int) {
        write8(address, value)
        write8(address + 1, value ushr 8)
        write8(address + 2, value ushr 16)
        write8(address + 3, value ushr 24)
    }

    /** Loads a BIOS image supplied by the device owner; this project ships no firmware. */
    fun loadFirmware(image: ByteArray) {
        require(image.size == FIRMWARE_SIZE) { "PS1 firmware image must be exactly 512 KiB." }
        image.copyInto(firmware)
        firmwareLoaded = true
    }

    /** Copies an executable/data image into a physical main-RAM address. */
    fun loadRam(address: Int, bytes: ByteArray, sourceOffset: Int = 0, length: Int = bytes.size - sourceOffset) {
        val start = ramOffset(address)
        require(sourceOffset >= 0 && length >= 0 && sourceOffset + length <= bytes.size) { "Invalid source range." }
        require(start + length <= RAM_SIZE) { "Image does not fit in the selected RAM range." }
        bytes.copyInto(ram, start, sourceOffset, sourceOffset + length)
    }

    fun clearRam(address: Int, length: Int) {
        val start = ramOffset(address)
        require(length >= 0 && start + length <= RAM_SIZE) { "Invalid RAM clear range." }
        ram.fill(0, start, start + length)
    }

    private fun ramOffset(address: Int): Int {
        val physical = when (address ushr 29) {
            4, 5 -> address and 0x1FFFFFFF
            else -> address
        }
        require(physical in 0 until 0x00800000) { "Address is outside main RAM." }
        return physical and RAM_MASK
    }

    fun clear() {
        ram.fill(0)
        scratchpad.fill(0)
        firmware.fill(0)
        firmwareLoaded = false
    }

    private companion object {
        const val RAM_SIZE = 2 * 1024 * 1024
        const val RAM_MASK = RAM_SIZE - 1
        const val RAM_START = 0x00000000
        const val RAM_END = 0x007FFFFF
        const val SCRATCHPAD_START = 0x1F800000
        const val SCRATCHPAD_SIZE = 1024
        const val SCRATCHPAD_END = SCRATCHPAD_START + SCRATCHPAD_SIZE - 1
        const val FIRMWARE_START = 0x1FC00000
        const val FIRMWARE_SIZE = 512 * 1024
        const val FIRMWARE_END = FIRMWARE_START + FIRMWARE_SIZE - 1
    }
}
