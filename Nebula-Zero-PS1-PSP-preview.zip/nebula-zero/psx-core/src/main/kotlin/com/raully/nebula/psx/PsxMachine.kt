package com.raully.nebula.psx

/** PS1 memory/bus wiring for the implemented RAM and the initial GP0/GP1 GPU ports. */
class PsxMachineBus(
    val memory: PsxMemory = PsxMemory(),
    val gpu: PsxGpu = PsxGpu()
) : PsxBus {
    override fun read8(address: Int): Int {
        if (address in GPU_GP0..GPU_GP0 + 3) throw PsxBusFault(address, false)
        if (address in GPU_GP1..GPU_GP1 + 3) return (GPU_STATUS ushr ((address and 3) * 8)) and 0xFF
        return memory.read8(address)
    }

    override fun read16(address: Int): Int = read8(address) or (read8(address + 1) shl 8)

    override fun read32(address: Int): Int = when (address) {
        GPU_GP0 -> 0 // GP0 read FIFO/readback is not emulated yet.
        GPU_GP1 -> GPU_STATUS
        else -> memory.read32(address)
    }

    override fun write8(address: Int, value: Int) {
        if (address in GPU_GP0..GPU_GP0 + 3 || address in GPU_GP1..GPU_GP1 + 3) throw PsxBusFault(address, true)
        memory.write8(address, value)
    }

    override fun write16(address: Int, value: Int) {
        if (address in GPU_GP0..GPU_GP0 + 3 || address in GPU_GP1..GPU_GP1 + 3) throw PsxBusFault(address, true)
        memory.write16(address, value)
    }

    override fun write32(address: Int, value: Int) {
        when (address) {
            GPU_GP0 -> gpu.writeGp0(value)
            GPU_GP1 -> gpu.writeGp1(value)
            else -> memory.write32(address, value)
        }
    }

    private companion object {
        const val GPU_GP0 = 0x1F801810
        const val GPU_GP1 = 0x1F801814
        const val GPU_STATUS = 0x14802000
    }
}

/** Wires the initial PS1 CPU, memory, ISO/EXE loader and software GPU together. */
class PsxMachine {
    val bus = PsxMachineBus()
    val cpu = MipsR3000A(bus)
    val gpu: PsxGpu get() = bus.gpu
    val memory: PsxMemory get() = bus.memory

    fun loadIso(image: ByteArray): LoadedPsxExecutable {
        val executable = PlayStationIso(image).readBootExecutable()
        return PsxExeLoader.load(executable, memory, cpu)
    }

    fun startExe(executable: ByteArray): LoadedPsxExecutable = PsxExeLoader.load(executable, memory, cpu)
    fun step() = cpu.step()
    fun frameBufferArgb(): IntArray = gpu.snapshotArgb()
}
