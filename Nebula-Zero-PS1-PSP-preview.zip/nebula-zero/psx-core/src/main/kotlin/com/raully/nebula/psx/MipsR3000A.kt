package com.raully.nebula.psx

/**
 * Project-authored interpreter for a growing subset of the PlayStation's MIPS R3000A.
 * This is still only one component of an unfinished emulator, not a complete PS1 core.
 */
class MipsR3000A(private val bus: PsxBus) {
    val gpr = IntArray(32)
    private val cop0 = IntArray(16)
    var hi: Int = 0
        private set
    var lo: Int = 0
        private set
    var pc: Int = 0
        private set

    private var nextPc: Int = 4
    private var branchDelayPending = false
    var instructionsExecuted: Long = 0
        private set

    val status: Int get() = cop0[COP0_STATUS]
    val cause: Int get() = cop0[COP0_CAUSE]
    val epc: Int get() = cop0[COP0_EPC]
    val badVAddr: Int get() = cop0[COP0_BAD_VADDR]

    fun readCop0(register: Int): Int = cop0[register and 15]

    /** Starts a loaded PS-X EXE directly, skipping the firmware boot ROM. */
    fun startDirect(entryPoint: Int, globalPointer: Int, stackPointer: Int) {
        reset(entryPoint)
        gpr[28] = globalPointer
        gpr[29] = stackPointer
        gpr[30] = stackPointer
    }

    fun reset(resetVector: Int = 0xBFC00000.toInt()) {
        gpr.fill(0)
        cop0.fill(0)
        cop0[COP0_STATUS] = STATUS_BEV
        cop0[COP0_PRID] = 0x00000002
        hi = 0
        lo = 0
        pc = resetVector
        nextPc = resetVector + 4
        branchDelayPending = false
        instructionsExecuted = 0
    }

    /** Executes one instruction and converts architectural traps into COP0 exceptions. */
    fun step() {
        val instructionPc = pc
        val wasDelaySlot = branchDelayPending
        try {
            if ((instructionPc and 3) != 0) {
                throw PsxTrap(PsxExceptionCode.ADDRESS_LOAD, instructionPc)
            }
            val instruction = try {
                bus.read32(physicalAddress(instructionPc))
            } catch (fault: PsxBusFault) {
                throw PsxTrap(PsxExceptionCode.BUS_INSTRUCTION, fault.address)
            }
            pc = nextPc
            nextPc = pc + 4
            branchDelayPending = false
            execute(instruction, instructionPc)
            instructionsExecuted++
        } catch (trap: PsxTrap) {
            raiseException(trap, instructionPc, wasDelaySlot)
        } catch (fault: PsxBusFault) {
            raiseException(PsxTrap(PsxExceptionCode.BUS_DATA, fault.address), instructionPc, wasDelaySlot)
        }
        gpr[0] = 0
    }

    private fun execute(op: Int, instructionPc: Int) {
        val rs = (op ushr 21) and 31
        val rt = (op ushr 16) and 31
        val rd = (op ushr 11) and 31
        val shamt = (op ushr 6) and 31
        val imm = op and 0xFFFF
        val signedImm = (imm shl 16) shr 16
        val target = op and 0x03FFFFFF

        when ((op ushr 26) and 0x3F) {
            0x00 -> executeSpecial(op, rs, rt, rd, shamt, instructionPc)
            0x01 -> {
                val take = when (rt) {
                    0x00, 0x10 -> gpr[rs] < 0
                    0x01, 0x11 -> gpr[rs] >= 0
                    else -> trap(PsxExceptionCode.RESERVED_INSTRUCTION)
                }
                if (rt == 0x10 || rt == 0x11) gpr[31] = pc + 4
                branch(instructionPc, signedImm, take)
            }
            0x02 -> jump(instructionPc, target)
            0x03 -> {
                gpr[31] = pc + 4
                jump(instructionPc, target)
            }
            0x04 -> branch(instructionPc, signedImm, gpr[rs] == gpr[rt])
            0x05 -> branch(instructionPc, signedImm, gpr[rs] != gpr[rt])
            0x06 -> branch(instructionPc, signedImm, gpr[rs] <= 0)
            0x07 -> branch(instructionPc, signedImm, gpr[rs] > 0)
            0x08 -> gpr[rt] = checkedAdd(gpr[rs], signedImm)
            0x09 -> gpr[rt] = gpr[rs] + signedImm
            0x0A -> gpr[rt] = if (gpr[rs] < signedImm) 1 else 0
            0x0B -> gpr[rt] = if (gpr[rs].toUInt() < signedImm.toUInt()) 1 else 0
            0x0C -> gpr[rt] = gpr[rs] and imm
            0x0D -> gpr[rt] = gpr[rs] or imm
            0x0E -> gpr[rt] = gpr[rs] xor imm
            0x0F -> gpr[rt] = imm shl 16
            0x10 -> executeCop0(op, rs, rt, rd)
            0x11, 0x12, 0x13 -> throw PsxTrap(
                PsxExceptionCode.COPROCESSOR_UNUSABLE,
                coprocessor = ((op ushr 26) and 0x3F) - 0x10
            )
            0x20 -> gpr[rt] = bus.read8(physicalAddress(gpr[rs] + signedImm)).toByte().toInt()
            0x21 -> {
                val address = gpr[rs] + signedImm
                requireAligned(address, 2, false)
                gpr[rt] = bus.read16(physicalAddress(address)).toShort().toInt()
            }
            0x23 -> {
                val address = gpr[rs] + signedImm
                requireAligned(address, 4, false)
                gpr[rt] = bus.read32(physicalAddress(address))
            }
            0x24 -> gpr[rt] = bus.read8(physicalAddress(gpr[rs] + signedImm)) and 0xFF
            0x25 -> {
                val address = gpr[rs] + signedImm
                requireAligned(address, 2, false)
                gpr[rt] = bus.read16(physicalAddress(address)) and 0xFFFF
            }
            0x28 -> bus.write8(physicalAddress(gpr[rs] + signedImm), gpr[rt])
            0x29 -> {
                val address = gpr[rs] + signedImm
                requireAligned(address, 2, true)
                bus.write16(physicalAddress(address), gpr[rt])
            }
            0x2B -> {
                val address = gpr[rs] + signedImm
                requireAligned(address, 4, true)
                bus.write32(physicalAddress(address), gpr[rt])
            }
            else -> trap(PsxExceptionCode.RESERVED_INSTRUCTION)
        }
    }

    private fun executeSpecial(op: Int, rs: Int, rt: Int, rd: Int, shamt: Int, at: Int) {
        when (op and 0x3F) {
            0x00 -> gpr[rd] = gpr[rt] shl shamt
            0x02 -> gpr[rd] = gpr[rt] ushr shamt
            0x03 -> gpr[rd] = gpr[rt] shr shamt
            0x04 -> gpr[rd] = gpr[rt] shl (gpr[rs] and 31)
            0x06 -> gpr[rd] = gpr[rt] ushr (gpr[rs] and 31)
            0x07 -> gpr[rd] = gpr[rt] shr (gpr[rs] and 31)
            0x08 -> jumpRegister(gpr[rs])
            0x09 -> {
                gpr[rd] = pc + 4
                jumpRegister(gpr[rs])
            }
            0x0C -> trap(PsxExceptionCode.SYSCALL)
            0x0D -> trap(PsxExceptionCode.BREAKPOINT)
            0x10 -> gpr[rd] = hi
            0x11 -> hi = gpr[rs]
            0x12 -> gpr[rd] = lo
            0x13 -> lo = gpr[rs]
            0x18 -> {
                val product = gpr[rs].toLong() * gpr[rt].toLong()
                lo = product.toInt()
                hi = (product shr 32).toInt()
            }
            0x19 -> {
                val product = gpr[rs].toUInt().toULong() * gpr[rt].toUInt().toULong()
                lo = product.toLong().toInt()
                hi = (product shr 32).toLong().toInt()
            }
            0x1A -> divideSigned(gpr[rs], gpr[rt])
            0x1B -> divideUnsigned(gpr[rs], gpr[rt])
            0x20 -> gpr[rd] = checkedAdd(gpr[rs], gpr[rt])
            0x21 -> gpr[rd] = gpr[rs] + gpr[rt]
            0x22 -> gpr[rd] = checkedSub(gpr[rs], gpr[rt])
            0x23 -> gpr[rd] = gpr[rs] - gpr[rt]
            0x24 -> gpr[rd] = gpr[rs] and gpr[rt]
            0x25 -> gpr[rd] = gpr[rs] or gpr[rt]
            0x26 -> gpr[rd] = gpr[rs] xor gpr[rt]
            0x27 -> gpr[rd] = gpr[rs].inv() and gpr[rt].inv()
            0x2A -> gpr[rd] = if (gpr[rs] < gpr[rt]) 1 else 0
            0x2B -> gpr[rd] = if (gpr[rs].toUInt() < gpr[rt].toUInt()) 1 else 0
            else -> trap(PsxExceptionCode.RESERVED_INSTRUCTION)
        }
    }

    private fun executeCop0(op: Int, rs: Int, rt: Int, rd: Int) {
        when (rs) {
            0x00 -> gpr[rt] = cop0[rd] // MFC0
            0x04 -> writeCop0(rd, gpr[rt]) // MTC0
            0x10 -> {
                if ((op and 0x3F) != 0x10) trap(PsxExceptionCode.RESERVED_INSTRUCTION)
                // RFE restores the two nested interrupt/user-mode status stacks.
                val old = cop0[COP0_STATUS]
                cop0[COP0_STATUS] = (old and 0xFFFFFFC0.toInt()) or ((old ushr 2) and 0x0F) or (old and 0x30)
            }
            else -> trap(PsxExceptionCode.RESERVED_INSTRUCTION)
        }
    }

    private fun writeCop0(register: Int, value: Int) {
        when (register) {
            COP0_BAD_VADDR, COP0_PRID -> Unit // read-only on this processor model
            COP0_CAUSE -> cop0[register] = (cop0[register] and 0xFFFFFCFF.toInt()) or (value and 0x00000300)
            else -> cop0[register] = value
        }
    }

    private fun branch(instructionPc: Int, signedOffset: Int, taken: Boolean) {
        branchDelayPending = true
        if (taken) nextPc = instructionPc + 4 + (signedOffset shl 2)
    }

    private fun jump(instructionPc: Int, target: Int) {
        branchDelayPending = true
        nextPc = ((instructionPc + 4) and -0x10000000) or (target shl 2)
    }

    private fun jumpRegister(target: Int) {
        branchDelayPending = true
        nextPc = target
    }

    private fun checkedAdd(a: Int, b: Int): Int {
        val result = a.toLong() + b.toLong()
        if (result !in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()) trap(PsxExceptionCode.OVERFLOW)
        return result.toInt()
    }

    private fun checkedSub(a: Int, b: Int): Int {
        val result = a.toLong() - b.toLong()
        if (result !in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()) trap(PsxExceptionCode.OVERFLOW)
        return result.toInt()
    }

    private fun divideSigned(a: Int, b: Int) {
        if (b == 0) {
            lo = if (a < 0) 1 else -1
            hi = a
        } else if (a == Int.MIN_VALUE && b == -1) {
            lo = Int.MIN_VALUE
            hi = 0
        } else {
            lo = a / b
            hi = a % b
        }
    }

    private fun divideUnsigned(a: Int, b: Int) {
        if (b == 0) {
            lo = -1
            hi = a
        } else {
            lo = a.toUInt().div(b.toUInt()).toInt()
            hi = a.toUInt().rem(b.toUInt()).toInt()
        }
    }

    private fun requireAligned(address: Int, alignment: Int, write: Boolean) {
        if ((address and (alignment - 1)) != 0) {
            throw PsxTrap(
                if (write) PsxExceptionCode.ADDRESS_STORE else PsxExceptionCode.ADDRESS_LOAD,
                address
            )
        }
    }

    private fun raiseException(trap: PsxTrap, instructionPc: Int, inDelaySlot: Boolean) {
        val oldStatus = cop0[COP0_STATUS]
        cop0[COP0_STATUS] = (oldStatus and -64) or ((oldStatus shl 2) and 0x3F)
        cop0[COP0_CAUSE] = (cop0[COP0_CAUSE] and CAUSE_PENDING_MASK) or
            (trap.code.value shl 2) or
            ((trap.coprocessor and 3) shl 28) or
            (if (inDelaySlot) CAUSE_BRANCH_DELAY else 0)
        if (trap.badAddress != null && (trap.code == PsxExceptionCode.ADDRESS_LOAD || trap.code == PsxExceptionCode.ADDRESS_STORE)) {
            cop0[COP0_BAD_VADDR] = trap.badAddress
        }
        cop0[COP0_EPC] = if (inDelaySlot) instructionPc - 4 else instructionPc
        val vector = if ((cop0[COP0_STATUS] and STATUS_BEV) != 0) EXCEPTION_VECTOR_BEV else EXCEPTION_VECTOR
        pc = vector
        nextPc = vector + 4
        branchDelayPending = false
    }

    /** KSEG0/KSEG1 alias the low physical 512 MiB range. */
    private fun physicalAddress(address: Int): Int = when (address ushr 29) {
        4, 5 -> address and 0x1FFFFFFF
        else -> address
    }

    private fun trap(code: PsxExceptionCode): Nothing = throw PsxTrap(code)

    private companion object {
        const val COP0_BAD_VADDR = 8
        const val COP0_STATUS = 12
        const val COP0_CAUSE = 13
        const val COP0_EPC = 14
        const val COP0_PRID = 15
        const val STATUS_BEV = 1 shl 22
        const val CAUSE_BRANCH_DELAY = -2147483647 - 1
        const val CAUSE_PENDING_MASK = 0x0000FF00
        const val EXCEPTION_VECTOR = -2147483520
        const val EXCEPTION_VECTOR_BEV = -1077935744
    }
}
