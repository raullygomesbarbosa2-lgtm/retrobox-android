# Nébula Zero — prévia Android PS1 + PSP

App de desenvolvimento em Kotlin que hospeda motores autorais de PS1 e PSP. Não reutiliza núcleos, código nem interfaces de outros emuladores.

## Esta build é apenas uma prévia técnica

O app pode desenhar um padrão no framebuffer da GPU própria de PS1 e examinar a estrutura de ISOs 2048-byte sector. Ainda não executa jogos comerciais. A inspeção do PS1 localiza o PS-X EXE, mas não inicializa o jogo; no PSP, EBOOT.BIN é extraído, mas PRX criptografado não é carregado. Não há garantia de compatibilidade universal.

## Estrutura

- `app`: app Android padrão com teste gráfico PS1 e inspeção de ISO.
- `psx-core`: CPU/Memória/ISO/GPU PS1 em implementação progressiva.
- `psp-core`: CPU/Memória/ISO PSP e loader ELF inicial.

## Build de prévia no GitHub

O workflow `build-preview-apk.yml` executa os testes e compila `app-debug.apk`, publicando-o como artefato do GitHub Actions se tudo passar. O arquivo é uma prévia de desenvolvimento, não um emulador final.

Nenhuma BIOS, firmware, ISO ou jogo acompanha o projeto.
