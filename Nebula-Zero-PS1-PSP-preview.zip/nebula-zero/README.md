# Nébula Zero — motores próprios PS1 + PSP (em desenvolvimento)

Implementações autorais em Kotlin, sem incorporar código, cores ou interfaces de outros emuladores. O objetivo é abrir ISOs dos dois consoles e renderizar a imagem na tela do app; este repositório ainda contém somente protótipos de baixo nível, não um emulador jogável.

## Estado desta etapa

- **PS1:** subset da CPU MIPS R3000A/COP0; RAM/scratchpad inicial; leitura ISO-9660 de SYSTEM.CNF/BOOT e loader direto de PS-X EXE; GPU em software com VRAM 1024×512, primitivas planas e amostragem de texturas; CPU ligada aos registradores GP0/GP1 básicos.
- **PSP:** início de um interpretador Allegrex/MIPS, RAM/EDRAM inicial, extração de EBOOT.BIN de ISO-9660 e loader para ELF32 não criptografado.
- PSP comercial ainda requer descriptografia e loader de PRX, VFPU, GE, firmware HLE e áudio. O PS1 ainda precisa de HLE de serviços de BIOS, CD-ROM completo, GPU/áudio completos, controles e tela Android.
- Não existe APK jogável ainda. Testes foram escritos, mas não executados neste ambiente.

Nenhuma BIOS, firmware, ISO ou jogo acompanha o projeto. Não é possível prometer que todos os jogos funcionarão. Consulte `PREVIEW-STATUS.md` para o estado público detalhado.
