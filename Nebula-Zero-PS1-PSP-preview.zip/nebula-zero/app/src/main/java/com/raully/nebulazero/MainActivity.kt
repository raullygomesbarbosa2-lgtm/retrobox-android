package com.raully.nebulazero

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.channels.FileChannel
import com.raully.nebula.psx.PsxGpu
import com.raully.nebula.psx.PsxMachine
import com.raully.nebula.psx.PlayStationIso
import com.raully.nebula.psp.PspIso

/** Honest development harness for the original PS1/PSP cores; it does not claim game playback. */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var gpuPreview: ImageView
    private var requestedSystem: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 13, 26)
        window.navigationBarColor = Color.rgb(10, 13, 26)
        buildScreen()
    }

    private fun buildScreen() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
            setBackgroundColor(Color.rgb(10, 13, 26))
        }
        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)

        content.addView(label("NÉBULA ZERO", 28f, Color.WHITE, true))
        content.addView(label("PS1 + PSP • prévia técnica", 16f, 0xFFB8C4E2.toInt()).apply {
            setPadding(0, dp(4), 0, dp(16))
        })
        content.addView(label(
            "Esta build testa código próprio de CPU, ISO e GPU. Ainda não roda jogos comerciais nem representa a versão final.",
            14f, 0xFFE2C98A.toInt()
        ).apply { setPadding(0, 0, 0, dp(18)) })

        content.addView(button("TESTAR GPU PS1", 0xFF8E7CFF.toInt()) { showGpuTestPattern() })
        gpuPreview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            contentDescription = "Prévia do framebuffer de teste do PS1"
        }
        content.addView(gpuPreview, LinearLayout.LayoutParams(-1, dp(230)).apply { topMargin = dp(10); bottomMargin = dp(10) })

        content.addView(button("EXAMINAR ISO PS1", 0xFF253355.toInt()) { openIso("PS1") })
        content.addView(button("EXAMINAR ISO PSP", 0xFF253355.toInt()) { openIso("PSP") })
        status = label("Escolha um teste acima. A execução de jogos ainda não está disponível.", 14f, 0xFFCAD2E8.toInt())
        status.setPadding(dp(12), dp(14), dp(12), dp(14))
        content.addView(status)
        content.addView(label(
            "Limitações desta prévia: serviços HLE, CD-ROM/UMD, áudio e vídeo completo ainda faltam; EBOOT.BIN criptografado do PSP não é executado.",
            12f, 0xFF8F9AB7.toInt()
        ).apply { setPadding(0, dp(12), 0, 0) })
    }

    private fun showGpuTestPattern() {
        val machine = PsxMachine()
        val gpu = machine.gpu
        gpu.writeGp0(0x020000C0)
        gpu.writeGp0(xy(0, 0))
        gpu.writeGp0((140 shl 16) or 256)
        gpu.writeGp0(0x2000FF00)
        gpu.writeGp0(xy(60, 25))
        gpu.writeGp0(xy(240, 25))
        gpu.writeGp0(xy(150, 125))
        val pixels = machine.frameBufferArgb()
        val bitmap = Bitmap.createBitmap(pixels, PsxGpu.VRAM_WIDTH, PsxGpu.VRAM_HEIGHT, Bitmap.Config.ARGB_8888)
        gpuPreview.setImageBitmap(bitmap)
        status.text = "A GPU própria desenhou um padrão de teste no framebuffer. Isso não é um jogo nem uma execução de ISO."
    }

    private fun openIso(system: String) {
        requestedSystem = system
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, REQUEST_ISO)
    }

    @Deprecated("Result API kept on the platform Activity to avoid extra libraries in this prototype.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_ISO || resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        val system = requestedSystem ?: return
        status.text = "Lendo a ISO $system…"
        Thread {
            try {
                val cacheFile = File(cacheDir, "selected-preview.iso")
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(cacheFile).use { output -> input.copyTo(output, 1024 * 1024) }
                } ?: error("Não consegui abrir esse arquivo.")
                val mapped = FileInputStream(cacheFile).channel.use { channel ->
                    check(channel.size() > 0 && channel.size() <= Int.MAX_VALUE) { "Tamanho de ISO não suportado nesta prévia." }
                    channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size()).asReadOnlyBuffer()
                }
                val message = if (system == "PS1") {
                    val disc = PlayStationIso(mapped)
                    val path = disc.bootExecutablePath()
                    val executable = disc.readFile(path)
                    "ISO PS1 reconhecida. BOOT: $path (${executable.size} bytes). Esta prévia localiza o executável, mas ainda não inicia o jogo."
                } else {
                    val eboot = PspIso(mapped).readEbootBin()
                    val isElf = eboot.size >= 4 && eboot[0] == 0x7F.toByte() && eboot[1] == 'E'.code.toByte()
                    "ISO PSP reconhecida. EBOOT.BIN: ${eboot.size} bytes. " +
                        if (isElf) "ELF sem criptografia detectado; ainda sem execução/renderização PSP."
                        else "PRX criptografado detectado/não suportado; ainda não inicia o jogo."
                }
                runOnUiThread { status.text = message }
                cacheFile.delete()
            } catch (error: Throwable) {
                runOnUiThread { status.text = "Não consegui examinar essa ISO: ${error.message ?: "formato ainda não suportado"}" }
            }
        }.start()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        gravity = Gravity.START
    }

    private fun button(text: String, color: Int, action: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { bottomMargin = dp(8) }
    }

    private fun xy(x: Int, y: Int) = (y shl 16) or x
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private companion object { const val REQUEST_ISO = 43 }
}
