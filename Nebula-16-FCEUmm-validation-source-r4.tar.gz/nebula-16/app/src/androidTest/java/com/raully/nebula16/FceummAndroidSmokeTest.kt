package com.raully.nebula16

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/** End-to-end Android test: the app's own NES launch route, JNI adapter, and rendered view. */
@RunWith(AndroidJUnit4::class)
class FceummAndroidSmokeTest {
    @Test
    fun launchesGeneratedHomebrewThroughNebulaAdapterAndRendersNesFrame() {
        val testContext = InstrumentationRegistry.getInstrumentation().context
        val rom = testContext.assets.open("homebrew.nes").use { it.readBytes() }
        assertTrue("fixture must be an iNES NROM image", rom.size == 16 + 0x4000 + 0x2000 &&
            rom[0] == 'N'.code.toByte() && rom[1] == 'E'.code.toByte() &&
            rom[2] == 'S'.code.toByte() && rom[3] == 0x1a.toByte())

        var rendered: Bitmap? = null
        var diagnostic = "activity not launched"
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                // This is the same launch entry point used by the app's ROM picker.
                activity.startFceumm(rom)
                diagnostic = activity.fceummDebugStatus()
            }

            val deadline = System.currentTimeMillis() + 15_000
            while (System.currentTimeMillis() < deadline && rendered == null) {
                scenario.onActivity { activity ->
                    val frameView = findFrameView(activity.window.decorView)
                    rendered = (frameView?.drawable as? BitmapDrawable)?.bitmap
                    diagnostic = activity.fceummDebugStatus()
                }
                if (rendered == null) Thread.sleep(50)
            }

            val bitmap = rendered ?: throw AssertionError("No FCEUmm frame reached the app ImageView within 15s; $diagnostic")
            assertEquals("expected NES framebuffer width", 256, bitmap.width)
            assertEquals("expected NES framebuffer height", 240, bitmap.height)

            var visiblePixels = 0
            for (y in 0 until bitmap.height) for (x in 0 until bitmap.width) {
                if ((bitmap.getPixel(x, y) and 0x00ffffff) != 0) visiblePixels++
            }
            assertTrue("FCEUmm returned only a blank/black image", visiblePixels > 0)
        }
    }

    private fun findFrameView(view: View): ImageView? {
        if (view is ImageView && view.contentDescription == "Quadro do núcleo FCEUmm") return view
        if (view is ViewGroup) {
            for (index in 0 until view.childCount) {
                findFrameView(view.getChildAt(index))?.let { return it }
            }
        }
        return null
    }
}
