# Nébula 16 — beta incremental de integração Libretro

Interface e biblioteca Nébula originais para Android, com tema neon azul-bebê. Esta etapa acrescenta um adaptador próprio para o core Libretro FCEUmm; nenhuma tela ou frontend do Lemuroid foi copiado. Não distribua os binários antigos de PS1/PSP do APK 0.2.1: as fontes exatas, avisos e obrigações dessas cores ainda não foram verificadas.

## Estado honesto de compatibilidade

- **CHIP-8:** jogável; abre ROMs próprias do usuário (até 3.584 bytes) e `.ch8` em ZIP; inclui uma demonstração original.
- **NES (integração proposta com FCEUmm):** o caminho de seleção ROM→Libretro→buffer de pixels está implementado no código, com core pinado no commit `7a542dab1e87679921962a9f056186eca425c0c2`. O workflow configura um smoke test host que gera um homebrew original, carrega-o e verifica callback de quadro 256×240 com pixels visíveis, mas não foi executado aqui. Até o teste verde e validação no aparelho, **não conte NES como sistema confirmado**; a interface o marca como integração beta experimental/pending.
- **NES NROM autoral experimental:** núcleo próprio separado, restrito ao subconjunto já documentado/testado anteriormente; não é necessário para o caminho FCEUmm.
- **SNES:** protótipo muito incompleto, experimental; não conta como sistema jogável completo.
- O catálogo de 50 continua sendo roadmap. Só CHIP-8 permanece contado como executável confirmado nesta fonte não testada; FCEUmm é integração beta ainda não verificada. Não conte NES nem Famicom Disk System, Dendy, VS. System, outros consoles ou os demais nomes sem teste ROM→quadro específico.

O upstream FCEUmm também declara suporte a Famicom, Famicom Disk System, Dendy e VS. System. Isso não significa que esses tipos de conteúdo foram habilitados/testados nesta interface. O FDS depende de `disksys.rom`, fornecida pelo próprio usuário; o app não fornece BIOS e ainda não tem fluxo de importação de BIOS.

## Licença e origem do core

- Core FCEUmm: projeto [libretro-fceumm](https://github.com/libretro/libretro-fceumm), fonte completa vendorizada em `third_party/libretro-fceumm/` a partir do commit `7a542dab1e87679921962a9f056186eca425c0c2`.
- Licença upstream: GNU GPL versão 2; texto integral e autores preservados no diretório do core. Aviso também está dentro do APK em `assets/licenses/`.
- O adaptador Android é `app/src/main/cpp/libretro_bridge.cpp`, escrito para esta UI; não utiliza código de tela do Lemuroid.
- Distribuir o core ligado ao app exige cumprir GPL-2.0, incluindo disponibilizar a fonte correspondente completa e avisos com cada binário. A fonte vendorizada, o adaptador, os arquivos de build e a licença devem acompanhar o APK em qualquer distribuição. O workflow incremental cria pacote-fonte separado para o artefato; não é um lançamento público.
- Não empacota ROMs, BIOS, firmware nem jogos.

## Build e teste

O workflow GitHub Actions `Build and verify Nébula FCEUmm incremental beta` compila a fonte exata do core para `arm64-v8a` e `armeabi-v7a`, executa um smoke test nativo host com um NROM homebrew gerado pelo próprio teste, roda os testes de módulos e monta APK debug.

Build manual, após provisionar Android SDK 35, NDK 27.2.12479018 e CMake 3.22.1:

1. No diretório do projeto, compile o core FCEUmm da fonte vendorizada para cada ABI com a toolchain Android NDK e coloque `fceumm_libretro.so` em `app/src/main/jniLibs/<ABI>/libfceumm_libretro.so`.
2. Execute `gradle --no-daemon :rom-import:test :chip8-core:test :nes-core:test :snes-core:test :app:assembleDebug`.

Esta fonte beta ainda requer execução de CI e teste num dispositivo Android antes de anunciar APK verificado. Nenhum ROM comercial deve ser usado nos testes distribuídos; o smoke test usa um fixture de homebrew original criado em `tests/make_homebrew_nrom.py`.
