#!/usr/bin/env python3
"""Generate an original, tiny iNES NROM homebrew fixture for native smoke tests."""
from pathlib import Path
import sys

out = Path(sys.argv[1])
header = bytearray(16)
header[:4] = b"NES\x1a"
header[4] = 1  # 16 KiB PRG-ROM
header[5] = 1  # 8 KiB CHR-ROM
prg = bytearray([0xEA] * 0x4000)
# Initialize the PPU, set the universal backdrop to a visible blue, enable BG,
# then idle forever. Pattern table tile 0 is zeroed in the generated CHR-ROM.
code = bytes([
    0x78,                         # SEI
    0xA9, 0x00, 0x8D, 0x00, 0x20, # PPUCTRL = 0
    0x8D, 0x01, 0x20,             # PPUMASK = 0
    0xA9, 0x3F, 0x8D, 0x06, 0x20, # PPUADDR high = $3f
    0xA9, 0x00, 0x8D, 0x06, 0x20, # PPUADDR low = $00
    0xA9, 0x21, 0x8D, 0x07, 0x20, # universal palette color = blue
    0xA9, 0x0A, 0x8D, 0x01, 0x20, # show background
])
prg[:len(code)] = code
loop_addr = 0x8000 + len(code)
prg[len(code):len(code) + 3] = bytes([0x4C, loop_addr & 0xFF, loop_addr >> 8])
for off in (0x3FFA, 0x3FFC, 0x3FFE):
    prg[off:off + 2] = b"\x00\x80"
chr_rom = bytes(0x2000)
out.write_bytes(header + prg + chr_rom)
print(f"Wrote original generated iNES NROM fixture ({out.stat().st_size} bytes): {out}")
