package com.raully.nebularetro

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.VirtualFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.zip.ZipInputStream

class GameActivity : ComponentActivity() {
    private var retroView: GLRetroView? = null
    private val openDescriptors = mutableListOf<ParcelFileDescriptor>()
    private val pressedDirections = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val loading = TextView(this).apply {
            text = "Preparando jogo…"
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
        }
        setContentView(loading)

        val gameUri = intent.getStringExtra(EXTRA_GAME_URI)
        val rootUri = intent.getStringExtra(EXTRA_ROOT_URI)
        val relativePath = intent.getStringExtra(EXTRA_RELATIVE_PATH)
        val system = intent.getStringExtra(EXTRA_SYSTEM)
        if (gameUri == null || rootUri == null || relativePath == null || system == null) {
            fail("Não consegui abrir esse jogo.")
            return
        }

        lifecycleScope.launch {
            try {
                val gameData = withContext(Dispatchers.IO) {
                    if (system == "PSP") ensurePpssppAssets()
                    createRetroData(Uri.parse(rootUri), relativePath, system)
                }
                runOnUiThread { showGame(gameData) }
            } catch (e: Throwable) {
                runOnUiThread { fail(e.message ?: "Falha ao preparar o jogo.") }
            }
        }
    }

    private fun createRetroData(rootUri: Uri, relativePath: String, system: String): GLRetroViewData {
        val coreName = if (system == "PSP") "libppsspp_libretro_android.so" else "libpcsx_rearmed_libretro_android.so"
        val coreFile = File(applicationInfo.nativeLibraryDir, coreName)
        check(coreFile.isFile) { "Núcleo não encontrado neste aparelho ($coreName)." }

        val root = DocumentFile.fromTreeUri(this, rootUri) ?: error("Pasta de jogos indisponível.")
        val selected = findDocument(root, relativePath) ?: error("O arquivo não está mais na pasta escolhida.")
        val parentPath = relativePath.substringBeforeLast('/', "")
        val parent = if (parentPath.isEmpty()) root else findDocument(root, parentPath)
            ?: error("Não consegui acessar a pasta do jogo.")
        val virtualFolder = "/nebula/${system.lowercase(Locale.ROOT)}/${parentPath}"
        val virtualFiles = mutableListOf<VirtualFile>()

        fun addFile(doc: DocumentFile, virtualPath: String) {
            val fd = contentResolver.openFileDescriptor(doc.uri, "r") ?: error("Não consegui ler ${doc.name}.")
            openDescriptors += fd
            virtualFiles += VirtualFile(virtualPath, fd)
        }

        val selectedName = selected.name ?: error("Nome do jogo inválido.")
        addFile(selected, "$virtualFolder/$selectedName")

        if (selectedName.substringAfterLast('.', "").equals("cue", ignoreCase = true)) {
            val cueText = contentResolver.openInputStream(selected.uri)?.bufferedReader()?.use { it.readText() }
                ?: error("Não consegui ler o arquivo CUE.")
            val referenced = Regex("(?im)^\\s*FILE\\s+\"?([^\"\\r\\n]+)\"?")
                .findAll(cueText)
                .map { it.groupValues[1].trim() }
                .distinct()
            referenced.forEach { fileName ->
                val trackName = fileName.substringAfterLast('/')
                parent.findFile(trackName)?.let { addFile(it, "$virtualFolder/$trackName") }
            }
        }

        val systemDir = File(filesDir, "system").apply { mkdirs() }
        val saveDir = File(filesDir, "saves").apply { mkdirs() }
        return GLRetroViewData(this).apply {
            coreFilePath = coreFile.absolutePath
            gameVirtualFiles = virtualFiles
            systemDirectory = systemDir.absolutePath
            savesDirectory = saveDir.absolutePath
        }
    }

    private fun findDocument(root: DocumentFile, path: String): DocumentFile? {
        var current: DocumentFile = root
        path.split('/').filter { it.isNotBlank() }.forEach { part ->
            current = current.findFile(part) ?: return null
        }
        return current
    }

    private fun ensurePpssppAssets() {
        val systemRoot = File(filesDir, "system")
        val root = File(systemRoot, "PPSSPP")
        val marker = File(root, ".nebula-assets-ready")
        if (marker.isFile && File(root, "flash0/font/ltn0.pgf").isFile) return
        val staging = File(systemRoot, "PPSSPP.download")
        staging.deleteRecursively()
        staging.mkdirs()
        val url = URL("https://github.com/Swordfish90/LemuroidCores/raw/1.15/assets/ppsspp.zip")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 60_000
            instanceFollowRedirects = true
        }
        try {
            connection.connect()
            check(connection.responseCode in 200..299) { "Não consegui baixar os arquivos auxiliares do PPSSPP." }
            ZipInputStream(connection.inputStream.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val out = File(staging, entry.name)
                    val canonicalRoot = staging.canonicalPath + File.separator
                    check(out.canonicalPath.startsWith(canonicalRoot) || out.canonicalFile == staging.canonicalFile) {
                        "Arquivo auxiliar inválido."
                    }
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().buffered().use { zip.copyTo(it) }
                    }
                    zip.closeEntry()
                }
            }
            check(File(staging, "flash0/font/ltn0.pgf").isFile) { "O pacote auxiliar do PPSSPP veio incompleto." }
            File(staging, ".nebula-assets-ready").writeText("1")
            root.deleteRecursively()
            check(staging.renameTo(root)) { "Não consegui instalar os arquivos auxiliares do PPSSPP." }
        } catch (e: Throwable) {
            staging.deleteRecursively()
            throw e
        } finally {
            connection.disconnect()
        }
    }

    private fun showGame(data: GLRetroViewData) {
        val view = GLRetroView(this, data).apply {
            isFocusable = true
            isFocusableInTouchMode = true
        }
        retroView = view
        lifecycle.addObserver(view)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(view, FrameLayout.LayoutParams(-1, -1))
        root.addView(buildControls(), FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        view.requestFocus()
        lifecycleScope.launch {
            view.getGLRetroErrors().collect { error ->
                runOnUiThread {
                    Toast.makeText(this@GameActivity, "O núcleo não conseguiu iniciar o jogo ($error).", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun buildControls(): View {
        val overlay = FrameLayout(this)
        val dpad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        middle.addView(control("◀", 6, dpad = true))
        middle.addView(control("•", null))
        middle.addView(control("▶", 7, dpad = true))
        dpad.addView(control("▲", 4, dpad = true))
        dpad.addView(middle)
        dpad.addView(control("▼", 5, dpad = true))
        overlay.addView(dpad, FrameLayout.LayoutParams(dp(186), dp(174), Gravity.START or Gravity.BOTTOM).apply {
            setMargins(dp(14), 0, 0, dp(14))
        })

        val face = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        top.addView(control("△", 1)); top.addView(control("□", 9))
        bottom.addView(control("○", 0)); bottom.addView(control("×", 8))
        face.addView(top); face.addView(bottom)
        overlay.addView(face, FrameLayout.LayoutParams(dp(168), dp(122), Gravity.END or Gravity.BOTTOM).apply {
            setMargins(0, 0, dp(14), dp(15))
        })

        val center = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        center.addView(control("SELECT", 2, wide = true)); center.addView(control("START", 3, wide = true))
        overlay.addView(center, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44), Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply {
            bottomMargin = dp(18)
        })

        val shoulders = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        shoulders.addView(control("L", 10, wide = true)); shoulders.addView(control("R", 11, wide = true))
        overlay.addView(shoulders, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42), Gravity.END or Gravity.TOP).apply {
            topMargin = dp(10); rightMargin = dp(16)
        })
        return overlay
    }

    private fun control(label: String, key: Int?, dpad: Boolean = false, wide: Boolean = false): TextView {
        val view = TextView(this).apply {
            text = label
            textSize = if (wide) 11f else 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            alpha = 0.78f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xAA29324A.toInt())
                setStroke(dp(1), 0xAA9FAAD0.toInt())
            }
        }
        val sizeW = if (wide) 76 else 54
        view.layoutParams = LinearLayout.LayoutParams(dp(sizeW), dp(54)).apply {
            setMargins(dp(3), dp(3), dp(3), dp(3))
        }
        if (key == null) return view
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    retroView?.sendKeyEvent(KeyEvent.ACTION_DOWN, key)
                    if (dpad) pressedDirections.add(key)
                    updateAnalog()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                    retroView?.sendKeyEvent(KeyEvent.ACTION_UP, key)
                    if (dpad) pressedDirections.remove(key)
                    updateAnalog()
                    true
                }
                else -> true
            }
        }
        return view
    }

    private fun updateAnalog() {
        val x = (if (7 in pressedDirections) 1f else 0f) - (if (6 in pressedDirections) 1f else 0f)
        val y = (if (5 in pressedDirections) 1f else 0f) - (if (4 in pressedDirections) 1f else 0f)
        retroView?.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, x, y)
    }

    private fun fail(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        finish()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (retroView?.dispatchKeyEvent(event) == true) return true
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (retroView?.dispatchGenericMotionEvent(event) == true) return true
        return super.dispatchGenericMotionEvent(event)
    }

    override fun onDestroy() {
        // Let ComponentActivity dispatch ON_DESTROY to GLRetroView before closing game descriptors.
        super.onDestroy()
        openDescriptors.forEach { runCatching { it.close() } }
        openDescriptors.clear()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_GAME_URI = "game_uri"
        const val EXTRA_ROOT_URI = "root_uri"
        const val EXTRA_RELATIVE_PATH = "relative_path"
        const val EXTRA_SYSTEM = "system"
    }
}
