#include <jni.h>
#include <algorithm>
#include <cstdint>
#include <string>
#include <vector>
#include "libretro.h"

namespace {
using Pixel = uint32_t;
std::vector<Pixel> frame;
unsigned frame_width = 0, frame_height = 0;
unsigned input_mask = 0;
bool initialized = false, game_loaded = false, pixel_format_ready = false;
std::string system_directory;

bool environment(unsigned command, void* data) {
    switch (command) {
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        pixel_format_ready = data && *static_cast<retro_pixel_format*>(data) == RETRO_PIXEL_FORMAT_XRGB8888;
        return pixel_format_ready;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
        if (!data) return false;
        *static_cast<const char**>(data) = system_directory.c_str();
        return true;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE:
        if (!data) return false;
        *static_cast<bool*>(data) = false;
        return true;
    case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS:
        return true;
    case RETRO_ENVIRONMENT_SET_VARIABLES:
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS:
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
        return true;
    default:
        return false;
    }
}

void video_refresh(const void* data, unsigned width, unsigned height, size_t pitch) {
    if (!data || !width || !height || width > 2048 || height > 1024 || pitch < width * sizeof(Pixel)) return;
    frame.resize(static_cast<size_t>(width) * height);
    const auto* source = static_cast<const uint8_t*>(data);
    for (unsigned y = 0; y < height; ++y) {
        const auto* row = reinterpret_cast<const Pixel*>(source + static_cast<size_t>(y) * pitch);
        for (unsigned x = 0; x < width; ++x) frame[static_cast<size_t>(y) * width + x] = row[x] | 0xff000000u;
    }
    frame_width = width;
    frame_height = height;
}
void audio_sample(int16_t, int16_t) {}
size_t audio_batch(const int16_t*, size_t frames) { return frames; }
void input_poll() {}
int16_t input_state(unsigned port, unsigned, unsigned device, unsigned, unsigned id) {
    if (port != 0 || device != RETRO_DEVICE_JOYPAD) return 0;
    if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return static_cast<int16_t>(input_mask);
    return id < 16 && (input_mask & (1u << id)) ? 1 : 0;
}
void shutdown_core() {
    if (game_loaded) { retro_unload_game(); game_loaded = false; }
    if (initialized) { retro_deinit(); initialized = false; }
    frame.clear(); frame_width = frame_height = 0; input_mask = 0; pixel_format_ready = false;
}
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_raully_nebula16_MainActivity_nativeInit(JNIEnv*, jobject) {
    if (!initialized) {
        retro_set_environment(environment);
        retro_set_video_refresh(video_refresh);
        retro_set_audio_sample(audio_sample);
        retro_set_audio_sample_batch(audio_batch);
        retro_set_input_poll(input_poll);
        retro_set_input_state(input_state);
        retro_init();
        initialized = true;
    }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_raully_nebula16_MainActivity_nativeLoad(JNIEnv* env, jobject, jbyteArray bytes, jstring system_dir) {
    if (!bytes || !system_dir) return JNI_FALSE;
    shutdown_core();
    const char* directory = env->GetStringUTFChars(system_dir, nullptr);
    if (!directory) return JNI_FALSE;
    system_directory = directory;
    env->ReleaseStringUTFChars(system_dir, directory);
    if (!Java_com_raully_nebula16_MainActivity_nativeInit(env, nullptr)) return JNI_FALSE;
    const jsize length = env->GetArrayLength(bytes);
    if (length <= 0) return JNI_FALSE;
    jbyte* raw = env->GetByteArrayElements(bytes, nullptr);
    if (!raw) return JNI_FALSE;
    retro_game_info game{};
    const std::string logical_path = system_directory + "/selected-content.nes";
    // FCEUmm requires a non-empty path for format/region handling even when
    // the frontend supplies the complete selected ROM in game.data.
    game.path = logical_path.c_str();
    game.data = raw;
    game.size = static_cast<size_t>(length);
    game.meta = nullptr;
    const bool loaded = retro_load_game(&game);
    env->ReleaseByteArrayElements(bytes, raw, JNI_ABORT);
    game_loaded = loaded;
    if (!loaded) shutdown_core();
    return loaded ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_raully_nebula16_MainActivity_nativeRunFrame(JNIEnv* env, jobject) {
    if (!game_loaded) return nullptr;
    retro_run();
    if (frame.empty()) return nullptr;
    jintArray result = env->NewIntArray(static_cast<jsize>(frame.size()));
    if (result) env->SetIntArrayRegion(result, 0, static_cast<jsize>(frame.size()), reinterpret_cast<const jint*>(frame.data()));
    return result;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_raully_nebula16_MainActivity_nativeFrameWidth(JNIEnv*, jobject) { return static_cast<jint>(frame_width); }
extern "C" JNIEXPORT jint JNICALL
Java_com_raully_nebula16_MainActivity_nativeFrameHeight(JNIEnv*, jobject) { return static_cast<jint>(frame_height); }
extern "C" JNIEXPORT void JNICALL
Java_com_raully_nebula16_MainActivity_nativeSetInput(JNIEnv*, jobject, jint mask) { input_mask = static_cast<unsigned>(mask); }
extern "C" JNIEXPORT void JNICALL
Java_com_raully_nebula16_MainActivity_nativeUnload(JNIEnv*, jobject) { shutdown_core(); }
