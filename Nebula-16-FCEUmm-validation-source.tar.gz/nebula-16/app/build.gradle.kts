plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.raully.nebula16"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.raully.nebula16"
        minSdk = 23
        targetSdk = 35
        versionCode = 9
        versionName = "0.2.0-libretro-beta"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        externalNativeBuild { cmake { cppFlags += listOf("-std=c++17") } }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    sourceSets["main"].jniLibs.srcDirs("src/main/jniLibs")
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(project(":snes-core"))
    implementation(project(":chip8-core"))
    implementation(project(":nes-core"))
    implementation(project(":rom-import"))
}
