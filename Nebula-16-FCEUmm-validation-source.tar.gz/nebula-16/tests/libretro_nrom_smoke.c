#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "libretro.h"

static unsigned frames, width, height, colored_pixels;
static char system_dir[] = ".";
static bool environment(unsigned cmd, void *data) {
    switch (cmd) {
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        return data && *(enum retro_pixel_format *)data == RETRO_PIXEL_FORMAT_XRGB8888;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
        if (!data) return false;
        *(const char **)data = system_dir;
        return true;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE:
        if (!data) return false;
        *(bool *)data = false;
        return true;
    case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS:
    case RETRO_ENVIRONMENT_SET_VARIABLES:
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS:
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
        return true;
    default:
        return false;
    }
}
static void video(const void *data, unsigned w, unsigned h, size_t pitch) {
    if (!data || !w || !h) return;
    frames++; width = w; height = h;
    colored_pixels = 0;
    for (unsigned y = 0; y < h; ++y) {
        const uint32_t *row = (const uint32_t *)((const uint8_t *)data + (size_t)y * pitch);
        for (unsigned x = 0; x < w; ++x) if ((row[x] & 0x00ffffffu) != 0) colored_pixels++;
    }
}
static void audio_sample(int16_t l, int16_t r) { (void)l; (void)r; }
static size_t audio_batch(const int16_t *data, size_t n) { (void)data; return n; }
static void input_poll(void) {}
static int16_t input_state(unsigned p, unsigned d, unsigned dev, unsigned i, unsigned id) {
    (void)p; (void)d; (void)dev; (void)i; (void)id; return 0;
}
int main(int argc, char **argv) {
    if (argc != 2) { fprintf(stderr, "usage: %s generated-homebrew.nes\n", argv[0]); return 2; }
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("open homebrew ROM"); return 2; }
    fseek(f, 0, SEEK_END); long n = ftell(f); rewind(f);
    if (n <= 0) { fclose(f); return 2; }
    void *rom = malloc((size_t)n);
    if (!rom || fread(rom, 1, (size_t)n, f) != (size_t)n) { fclose(f); free(rom); return 2; }
    fclose(f);
    retro_set_environment(environment); retro_set_video_refresh(video);
    retro_set_audio_sample(audio_sample); retro_set_audio_sample_batch(audio_batch);
    retro_set_input_poll(input_poll); retro_set_input_state(input_state); retro_init();
    struct retro_game_info game = { argv[1], rom, (size_t)n, NULL };
    if (!retro_load_game(&game)) { fprintf(stderr, "FCEUmm rejected generated NROM\n"); retro_deinit(); free(rom); return 1; }
    for (int i = 0; i < 8; ++i) retro_run();
    retro_unload_game(); retro_deinit(); free(rom);
    if (frames < 2 || width != 256 || height != 240 || colored_pixels == 0) {
        fprintf(stderr, "no usable rendered frame: frames=%u size=%ux%u visible=%u\n", frames, width, height, colored_pixels);
        return 1;
    }
    printf("PASS: FCEUmm rendered %u 256x240 frames from generated NROM; %u non-black pixels in final frame.\n", frames, colored_pixels);
    return 0;
}
