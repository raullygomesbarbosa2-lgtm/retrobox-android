# FCEUmm vendored source and attribution

- Upstream project: https://github.com/libretro/libretro-fceumm
- Pinned upstream commit: `7a542dab1e87679921962a9f056186eca425c0c2` (2026-09-26)
- Pinned commit URL: https://github.com/libretro/libretro-fceumm/commit/7a542dab1e87679921962a9f056186eca425c0c2
- Upstream description: Libretro port of FCEUmm; the upstream README lists NES, Famicom, Famicom Disk System, Dendy, and VS. System support.
- License: GNU General Public License version 2 (GPL-2.0-only), as stated by the upstream project. Full upstream license text is retained as `Copying` and duplicated as `LICENSE-GPL-2.0.txt`; upstream `Authors` is retained as `AUTHORS.txt`.
- Source provenance: this directory is the source snapshot from the pinned upstream commit, not binaries recovered from an APK. The libretro frontend bridge under `app/src/main/cpp/` is Nébula code and does not use Lemuroid screens or frontend code.

Any distributed build containing the linked FCEUmm library is subject to the GPL-2.0 terms. The corresponding source for the exact core build must accompany every binary distribution, including the Nébula source/bridge and build scripts, with this notice and the full license. Preserve upstream copyright and license notices in source files. The app's separate original code license does not replace or relicense FCEUmm.

This app does not bundle games, ROMs, BIOS images, firmware, or FDS system BIOS files. FDS content needs a user-provided `disksys.rom`; FDS loading is not enabled in this beta UI unless such a system-file workflow is added and tested.
