/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#include "fceu-types.h"
#include "video.h"
#include "fceu.h"
#include "general.h"
#include "fceu-memory.h"
#include "crc32.h"
#include "state.h"
#include "palette.h"
#include "nsf.h"
#include "input.h"
#include "vsuni.h"

uint8_t *XBuf = NULL;
uint8_t *XDBuf = NULL;
int show_crosshair = 0;

void FCEU_KillVirtualVideo(void)
{
	if (XBuf)
		free(XBuf);
   XBuf = 0;
   if (XDBuf)
		free(XDBuf);
   XDBuf = 0;
}

int FCEU_InitVirtualVideo(void)
{
   /* 256 bytes per scanline, * 240 scanline maximum, +8 for alignment, */
   if (!XBuf)
      XBuf = (uint8_t*)(FCEU_malloc(256 * (256 + extrascanlines + 8)));
   if (!XDBuf)
      XDBuf = (uint8_t*)(FCEU_malloc(256 * (256 + extrascanlines + 8)));

   if (!XBuf || !XDBuf)
   {
      /* Free whatever did allocate to avoid leaking on retry */
      if (XBuf) { free(XBuf); XBuf = NULL; }
      if (XDBuf) { free(XDBuf); XDBuf = NULL; }
      return 0;
   }

   memset(XBuf, 128, 256 * (256 + extrascanlines + 8));
   memset(XDBuf, 0, 256 * (256 + extrascanlines + 8));
   return 1;
}

#include "drawing.h"

void FCEU_PutImage(void)
{
	if (GameInfo->type == GIT_NSF)
		DrawNSF(XBuf);
   else
   {
		if (GameInfo->type == GIT_VSUNI)
			FCEU_VSUniDraw(XBuf);
	}
	if (show_crosshair)
		FCEU_DrawInput(XBuf);
}

static void FCEU_PutImageDummy(void)
{
}

void FCEU_DispMessage(enum retro_log_level level, unsigned duration, const char *format, ...)
{
   static char msg[512] = {0};
   va_list ap;

   if (!format || (*format == '\0'))
      return;

   va_start(ap, format);
   /* Use vsnprintf to bound the write to msg[]. The previous vsprintf
    * had no length cap; format strings are currently all literals with
    * controlled args, but a future caller passing a long ROM name into
    * a %s format would overrun the 512-byte buffer. */
   vsnprintf(msg, sizeof(msg), format, ap);
   va_end(ap);

   FCEUD_DispMessage(level, duration, msg);
}
