/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2025 NewRisingSun
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"
#include "asic_latch.h"

static uint8_t submapper;
static uint8_t pad;
static uint8_t padSelect;

static DECLFR (interceptPRGRead_submapper0) {
	return Latch_address &0x200? CartBR(A &~0xF | pad &0xF): CartBR(A);
}

static DECLFR (readPad_submapper1) {
	return pad;
}

static DECLFR (interceptPRGRead_submapper2) {
	return padSelect &1? CartBR(A &~0x3 | pad &0x3): CartBR(A);
}

static void sync () {
	int prg = Latch_address >>2 &0x1F | Latch_address >>3 &0x20 | Latch_address >>4 &0x40;
	if (Latch_address &0x080) {
		if (Latch_address &0x001)
			setprg32(0x8000, prg >>1);
		else {
			setprg16(0x8000, prg);
			setprg16(0xC000, prg);
		}
		setmirror(Latch_data &0x10? MI_1: MI_0);
	} else {
		setprg16(0x8000, prg);
		setprg16(0xC000, prg | 7);
	}
	SetupCartCHRMapping(0, CHRptr[0], CHRsize[0], submapper == 0 && Latch_address &0x80? 0: 1);
	setchr8(Latch_data);
	setmirror(Latch_address &0x002? MI_H: MI_V);
}

static DECLFW (writePad_submapper2) {
	padSelect = V;
	sync();
}

static void power () {
	pad = padSelect = 0;
	Latch_power();
	switch(submapper) {
		case 0:
			SetReadHandler(0x8000, 0xFFFF, interceptPRGRead_submapper0);
			break;
		case 1:
			SetReadHandler(0x5000, 0x5FFF, readPad_submapper1);
			break;
		case 2:
			SetReadHandler(0x8000, 0xFFFF, interceptPRGRead_submapper2);
			SetWriteHandler(0x6000, 0x7FFF, writePad_submapper2);
			break;
	}
}

static void reset () {
	pad++;
	padSelect = 0;
	Latch_clear();
}

void Mapper449_Init (CartInfo *info) {
	submapper = info->submapper;
	Latch_init(info, sync, 0x8000, 0xFFFF, NULL);
	info->Power = power;
	info->Reset = reset;
	AddExState(&pad, 1, 0, "DIPS");
	if (submapper == 2) AddExState(&padSelect, 1, 0, "DIPE");
}
