/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2003 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <string.h>
#include "share.h"

static uint8_t HSVal, HSValR;


static uint8_t FP_FASTAPASS(2) HS_Read(int w, uint8_t ret) {
	if (w) ret |= HSValR;

	return(ret);
}

static void HS_Strobe(void) {
	HSValR = HSVal << 1;
}

static void FP_FASTAPASS(2) HS_Update(void *data, int arg) {
	HSVal = *(uint8_t*)data;
}

static INPUTCFC HyperShot = { HS_Read, 0, HS_Strobe, HS_Update, 0, 0 };

INPUTCFC *FCEU_InitHS(void) {
	HSVal = HSValR = 0;
	return(&HyperShot);
}
