/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include <sys/types.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <direct.h>
#else
#include <unistd.h>
#endif

#include <compat/strl.h>
#include <file/file_path.h>

#include "fceu-types.h"
#include "fceu.h"

#include "general.h"
#include "state.h"

#include "driver.h"

#include "md5.h"

static char BaseDirectory[2048] = {0};

void FCEUI_SetBaseDirectory(const char *dir)
{
	strlcpy(BaseDirectory, dir, sizeof(BaseDirectory));
}

char *FCEU_MakeFName(int type, int id1, const char *cd1)
{
   char tmp[4096 + 512] = {0}; /* +512 for no reason :D */
   char *ret      = 0;
   size_t len;

   switch (type)
   {
      case FCEUMKF_GGROM:
         fill_pathname_join(tmp, BaseDirectory,
               "gamegenie.nes", sizeof(tmp));
         break;
      case FCEUMKF_FDSROM:
         fill_pathname_join(tmp, BaseDirectory,
               "disksys.rom", sizeof(tmp));
         break;
      case FCEUMKF_PALETTE:
         fill_pathname_join(tmp, BaseDirectory,
               "nes.pal", sizeof(tmp));
         break;
      default:
         break;
   }

   FCEU_printf(" FCEU_MakeFName: %s\n", tmp);

   len = strlen(tmp) + 1;
   ret = (char*)malloc(len);
   if (!ret) return NULL;
   strlcpy(ret, tmp, len);

   return(ret);
}

uint32_t uppow2(uint32_t n)
{
   int x;

   if (n == 0)
      return 0;

   /* If n already has bit 31 set and isn't exactly 0x80000000, the next
    * power of two would be 1u << 32 which is undefined; clamp to 0x80000000
    * instead so callers don't end up with a wrap-to-0 allocation that's
    * smaller than the requested size. */
   if (n > 0x80000000u)
      return 0x80000000u;

   for (x = 31; x >= 0; x--)
      if (n & (1u << x))
      {
         if ((1u << x) != n)
            return(1u << (x + 1));
         break;
      }
   return n;
}
