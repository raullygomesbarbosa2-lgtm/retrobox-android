package com.raully.nebula16

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.raully.nebula16.chip8.Chip8
import com.raully.nebula16.snes.SnesButton
import com.raully.nebula16.snes.SnesMachine
import com.raully.nebula16.snes.SnesPpu
import com.raully.nebula16.snes.SnesHomebrewDemo
import com.raully.nebula16.snes.SnesRomFileTypes
import kotlin.math.min

/** Nébula 16 development build: original CHIP-8 play mode plus honest SNES core prototype. */
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val vm = Chip8()
    private var gameView: PixelView? = null
    private var running = false
    private var lastTick = 0L
    private var timerCredit = 0L
    @Volatile private var snesMachine: SnesMachine? = null
    private var snesImage: ImageView? = null
    private var snesBitmap: Bitmap? = null
    @Volatile private var snesRunning = false
    private var snesWorker: Thread? = null
    private var awaitingButtonMapping: SnesButton? = null
    private var controllerSettingsVisible = false
    private lateinit var body: LinearLayout
    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            repeat(10) { try { vm.cycle() } catch (e: Exception) { stopGame(); Toast.makeText(this@MainActivity, e.message ?: "Erro na ROM", Toast.LENGTH_LONG).show(); return } }
            val now = System.nanoTime()
            if (lastTick == 0L) lastTick = now
            timerCredit += now - lastTick
            lastTick = now
            while (timerCredit >= 16_666_667L) { vm.tickTimers(); timerCredit -= 16_666_667L }
            gameView?.invalidate()
            handler.postDelayed(this, 16)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); showHome() }

    private fun showHome(note: String? = null) {
        running = false; handler.removeCallbacks(frame); gameView = null
        stopSnes()
        awaitingButtonMapping = null
        controllerSettingsVisible = false
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        setImmersiveMode(false)
        window.statusBarColor = Color.rgb(9, 13, 25); window.navigationBarColor = Color.rgb(9, 13, 25)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(9, 13, 25)) }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(32), dp(22), dp(28)); gravity = Gravity.CENTER_HORIZONTAL }
        scroll.addView(body); setContentView(scroll)
        body.addView(label("NÉBULA 16", 30f, Color.WHITE, true))
        body.addView(label("Projeto autoral • demo SNES interativa + CHIP-8 jogável", 15f, 0xFFBAC6DF.toInt()).apply { setPadding(0, dp(8), 0, dp(20)) })
        button("JOGAR DEMO CHIP-8", 0xFF71E2B6.toInt()) { startChip8(Chip8.demo) }
        button("ABRIR ROM CHIP-8", 0xFF233451.toInt()) { pick(1) }
        button("JOGAR DEMO SNES AUTORAL · A DIREITA / B ESQUERDA", 0xFF8B5CF6.toInt()) { startSnes(SnesHomebrewDemo.createRom()) }
        button("ABRIR ROM SUPER NINTENDO (.SFC / .SMC / .FIG)", 0xFF233451.toInt()) { pick(2) }
        button("CONFIGURAR CONTROLE BLUETOOTH", 0xFF233451.toInt()) { showControllerSettings() }
        val status = label(note ?: "CHIP-8 jogável. Demo SNES autoral interativa; jogos comerciais ainda não verificados.", 14f, 0xFFE2C98A.toInt())
        status.setPadding(dp(13), dp(18), dp(13), dp(6)); body.addView(status)
        body.addView(label("Feito sem núcleos de emulação de terceiros. Não acompanha jogos, ROMs comerciais, BIOS ou firmware.", 12f, 0xFF9BA9C1.toInt()).apply { setPadding(dp(12), dp(12), dp(12), 0) })
    }

    private fun showControllerSettings(note: String? = null) {
        running = false; handler.removeCallbacks(frame); stopSnes()
        awaitingButtonMapping = null
        controllerSettingsVisible = true
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        setImmersiveMode(false)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(9, 13, 25)) }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(24)) }
        scroll.addView(body); setContentView(scroll)
        body.addView(label("CONTROLE BLUETOOTH · MAPEAMENTO", 22f, Color.WHITE, true))
        body.addView(label(note ?: "Conecte um controle Bluetooth nas configurações do Android. Toque em um botão abaixo e pressione a tecla física desejada.", 14f, 0xFFBAC6DF.toInt()).apply { setPadding(0, dp(10), 0, dp(16)) })
        button("VOLTAR", 0xFF233451.toInt()) { showHome() }
        for (button in SnesButton.values()) {
            val keyCode = controllerPreferences().getInt(mappingPreferenceKey(button), defaultSnesKey(button))
            val current = if (keyCode < 0) "Sem tecla" else KeyEvent.keyCodeToString(keyCode).removePrefix("KEYCODE_")
            body.addView(Button(this).apply {
                text = "${button.name}  ←  $current"
                setTextColor(Color.WHITE); setBackgroundColor(0xFF263550.toInt()); isAllCaps = false
                setOnClickListener {
                    awaitingButtonMapping = button
                    showControllerSettings("Agora pressione o botão físico que deve executar ${button.name}. ESC/Voltar cancela.")
                    awaitingButtonMapping = button
                }
            }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(5) })
        }
        button("RESTAURAR MAPEAMENTO PADRÃO", 0xFF233451.toInt()) {
            controllerPreferences().edit().clear().apply()
            showControllerSettings("Mapeamento padrão restaurado.")
        }
    }

    private fun controllerPreferences() = getSharedPreferences("snes_controller_mapping", MODE_PRIVATE)
    private fun mappingPreferenceKey(button: SnesButton) = "key_${button.name}"
    private fun defaultSnesKey(button: SnesButton): Int = when (button) {
        SnesButton.A -> KeyEvent.KEYCODE_BUTTON_A
        SnesButton.B -> KeyEvent.KEYCODE_BUTTON_B
        SnesButton.X -> KeyEvent.KEYCODE_BUTTON_X
        SnesButton.Y -> KeyEvent.KEYCODE_BUTTON_Y
        SnesButton.L -> KeyEvent.KEYCODE_BUTTON_L1
        SnesButton.R -> KeyEvent.KEYCODE_BUTTON_R1
        SnesButton.SELECT -> KeyEvent.KEYCODE_BUTTON_SELECT
        SnesButton.START -> KeyEvent.KEYCODE_BUTTON_START
        SnesButton.UP -> KeyEvent.KEYCODE_DPAD_UP
        SnesButton.DOWN -> KeyEvent.KEYCODE_DPAD_DOWN
        SnesButton.LEFT -> KeyEvent.KEYCODE_DPAD_LEFT
        SnesButton.RIGHT -> KeyEvent.KEYCODE_DPAD_RIGHT
    }

    private fun mappedSnesButton(keyCode: Int): SnesButton? = SnesButton.values().firstOrNull { button ->
        controllerPreferences().getInt(mappingPreferenceKey(button), defaultSnesKey(button)) == keyCode
    }

    @Suppress("DEPRECATION")
    private fun setImmersiveMode(enabled: Boolean) {
        window.decorView.systemUiVisibility = if (enabled) {
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        } else View.SYSTEM_UI_FLAG_VISIBLE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && snesMachine != null) setImmersiveMode(true)
    }

    private fun pick(kind: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivityForResult(intent, kind) } catch (_: Exception) { Toast.makeText(this, "Não consegui abrir o seletor de arquivos.", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Legacy result API supports the project's no-dependency Android UI")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        try {
            val uri = data.data!!
            val name = documentName(uri)
            val isSnesRom = SnesRomFileTypes.isSupportedName(name)
            if (requestCode == 2 && !isSnesRom) {
                Toast.makeText(this, "Selecione uma ROM SNES .sfc, .smc ou .fig.", Toast.LENGTH_LONG).show()
                return
            }
            if (requestCode == 1 && isSnesRom) {
                Toast.makeText(this, "Esse arquivo é SNES. Abra pelo botão de Super Nintendo; ele não é uma ROM CHIP-8.", Toast.LENGTH_LONG).show()
                return
            }
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Arquivo vazio.")
            when (requestCode) {
                1 -> startChip8(bytes)
                2 -> startSnes(bytes)
            }
        } catch (e: Exception) { Toast.makeText(this, e.message ?: "Arquivo inválido.", Toast.LENGTH_LONG).show() }
    }

    private fun documentName(uri: Uri): String {
        val fromProvider = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
        return fromProvider ?: uri.lastPathSegment.orEmpty()
    }

    private fun startSnes(bytes: ByteArray) {
        val machine = try { SnesMachine(bytes) } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "ROM SNES inválida.", Toast.LENGTH_LONG).show(); return
        }
        stopSnes()
        controllerSettingsVisible = false
        running = false; handler.removeCallbacks(frame)
        snesMachine = machine
        snesBitmap = Bitmap.createBitmap(SnesPpu.WIDTH, SnesPpu.HEIGHT, Bitmap.Config.ARGB_8888)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setImmersiveMode(true)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        top.addView(Button(this).apply { text = "VOLTAR"; setOnClickListener { showHome() } })
        top.addView(label("SNES EXPERIMENTAL · COMPATIBILIDADE LIMITADA", 12f, 0xFFFFD27A.toInt()).apply { setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top, LinearLayout.LayoutParams(-1, dp(48)))

        snesImage = ImageView(this).apply {
            setBackgroundColor(Color.BLACK)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageBitmap(snesBitmap)
            contentDescription = "Imagem do jogo SNES experimental"
        }
        root.addView(snesImage, LinearLayout.LayoutParams(-1, 0, 1f))
        val padRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(2), dp(8), dp(8)) }
        padRow.addView(snesDpad(), LinearLayout.LayoutParams(0, dp(122), 1.1f))
        val faceGroup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val faceTop = LinearLayout(this).apply { gravity = Gravity.CENTER }
        faceTop.addView(snesKeyButton("X", SnesButton.X)); faceTop.addView(snesKeyButton("Y", SnesButton.Y))
        val faceBottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        faceBottom.addView(snesKeyButton("B", SnesButton.B)); faceBottom.addView(snesKeyButton("A", SnesButton.A))
        faceGroup.addView(faceTop); faceGroup.addView(faceBottom)
        padRow.addView(faceGroup, LinearLayout.LayoutParams(0, dp(122), 1.2f))
        val utility = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val utilityTop = LinearLayout(this).apply { gravity = Gravity.CENTER }
        utilityTop.addView(snesKeyButton("L", SnesButton.L)); utilityTop.addView(snesKeyButton("R", SnesButton.R))
        val utilityBottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        utilityBottom.addView(snesKeyButton("SEL", SnesButton.SELECT)); utilityBottom.addView(snesKeyButton("START", SnesButton.START))
        utility.addView(utilityTop); utility.addView(utilityBottom)
        padRow.addView(utility, LinearLayout.LayoutParams(0, dp(122), 1.2f))
        root.addView(padRow, LinearLayout.LayoutParams(-1, dp(130)))
        setContentView(root)
        snesRunning = true
        snesWorker = Thread({
            while (snesRunning) {
                val pixels = try {
                    machine.runFrame()
                } catch (e: Exception) {
                    val message = e.message ?: "A ROM parou durante a execução."
                    handler.post {
                        if (snesMachine === machine) {
                            stopSnes()
                            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                        }
                    }
                    return@Thread
                }
                val fault = machine.faultMessage
                if (fault != null) {
                    handler.post {
                        if (snesMachine === machine) {
                            stopSnes()
                            Toast.makeText(this, fault, Toast.LENGTH_LONG).show()
                        }
                    }
                    return@Thread
                }
                handler.post {
                    val bitmap = snesBitmap
                    if (snesMachine === machine && snesRunning && bitmap != null) {
                        bitmap.setPixels(pixels, 0, SnesPpu.WIDTH, 0, 0, SnesPpu.WIDTH, SnesPpu.HEIGHT)
                        snesImage?.invalidate()
                    }
                }
                try {
                    Thread.sleep(16)
                } catch (_: InterruptedException) {
                    return@Thread
                }
            }
        }, "Nebula16-SNES").apply { isDaemon = true; start() }
    }

    private fun stopSnes() {
        snesRunning = false
        snesWorker?.interrupt()
        snesWorker = null
        snesMachine = null; snesImage = null; snesBitmap = null
    }

    private fun snesDpad(): View {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        grid.addView(snesKeyButton("▲", SnesButton.UP))
        val middle = LinearLayout(this).apply { gravity = Gravity.CENTER }
        middle.addView(snesKeyButton("◀", SnesButton.LEFT))
        middle.addView(snesKeyButton("▼", SnesButton.DOWN))
        middle.addView(snesKeyButton("▶", SnesButton.RIGHT))
        grid.addView(middle)
        return grid
    }

    private fun snesKeyButton(text: String, key: SnesButton): Button = Button(this).apply {
        this.text = text; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(0xFF263550.toInt())
        setOnTouchListener { _, event ->
            val down = event.actionMasked == MotionEvent.ACTION_DOWN || event.actionMasked == MotionEvent.ACTION_POINTER_DOWN
            val up = event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_POINTER_UP || event.actionMasked == MotionEvent.ACTION_CANCEL
            if (down || up) snesMachine?.setButton(key, down)
            true
        }
    }

    private fun startChip8(rom: ByteArray) {
        try { vm.load(rom) } catch (e: Exception) { Toast.makeText(this, e.message ?: "ROM CHIP-8 inválida.", Toast.LENGTH_LONG).show(); return }
        controllerSettingsVisible = false
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        setImmersiveMode(false)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK) }
        val top = LinearLayout(this).apply { gravity = Gravity.END; setPadding(dp(8), dp(4), dp(8), dp(4)) }
        top.addView(Button(this).apply { text = "VOLTAR"; setOnClickListener { showHome() } })
        root.addView(top, LinearLayout.LayoutParams(-1, dp(52)))
        gameView = PixelView().also { root.addView(it, LinearLayout.LayoutParams(-1, 0, 1f)) }
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(6), dp(4), dp(6), dp(8)) }
        controls.addView(directionPad(), LinearLayout.LayoutParams(0, dp(130), 1.3f))
        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(keyButton("A", 5)); row.addView(keyButton("B", 13))
        actions.addView(row)
        controls.addView(actions, LinearLayout.LayoutParams(0, dp(130), 1f))
        root.addView(controls, LinearLayout.LayoutParams(-1, dp(145)))
        setContentView(root); running = true; lastTick = 0; timerCredit = 0; handler.post(frame)
    }

    private fun directionPad(): View {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        grid.addView(keyButton("▲", 2))
        val middle = LinearLayout(this).apply { gravity = Gravity.CENTER }
        middle.addView(keyButton("◀", 4)); middle.addView(keyButton("▼", 8)); middle.addView(keyButton("▶", 6))
        grid.addView(middle); return grid
    }

    private fun keyButton(text: String, key: Int): Button = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); setBackgroundColor(0xFF263550.toInt()); isAllCaps = false
        setOnTouchListener { _, event -> when (event.actionMasked) { MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> vm.setKey(key, true); MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_UP -> vm.setKey(key, false) }; true }
    }

    private fun stopGame() { running = false; handler.removeCallbacks(frame) }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val target = awaitingButtonMapping
        if (target != null) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                awaitingButtonMapping = null
                showControllerSettings("Mapeamento cancelado.")
                return true
            }
            val preferences = controllerPreferences()
            val editor = preferences.edit()
            for (button in SnesButton.values()) {
                if (button != target && preferences.getInt(mappingPreferenceKey(button), defaultSnesKey(button)) == keyCode) {
                    editor.putInt(mappingPreferenceKey(button), -1)
                }
            }
            editor.putInt(mappingPreferenceKey(target), keyCode).apply()
            awaitingButtonMapping = null
            showControllerSettings("${target.name} mapeado para ${KeyEvent.keyCodeToString(keyCode)}.")
            return true
        }
        if (controllerSettingsVisible) {
            if (keyCode == KeyEvent.KEYCODE_BACK) showHome()
            return true
        }
        val snesKey = mappedSnesButton(keyCode)
        if (snesMachine != null && snesKey != null) { snesMachine?.setButton(snesKey, true); return true }
        val k = keyFor(keyCode); if (k != null) { vm.setKey(k, true); return true }
        return super.onKeyDown(keyCode, event)
    }
    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (controllerSettingsVisible) return true
        val snesKey = mappedSnesButton(keyCode)
        if (snesMachine != null && snesKey != null) { snesMachine?.setButton(snesKey, false); return true }
        val k = keyFor(keyCode); if (k != null) { vm.setKey(k, false); return true }
        return super.onKeyUp(keyCode, event)
    }
    private fun keyFor(code: Int): Int? = when (code) { KeyEvent.KEYCODE_DPAD_UP -> 2; KeyEvent.KEYCODE_DPAD_DOWN -> 8; KeyEvent.KEYCODE_DPAD_LEFT -> 4; KeyEvent.KEYCODE_DPAD_RIGHT -> 6; KeyEvent.KEYCODE_BUTTON_A -> 5; KeyEvent.KEYCODE_BUTTON_B -> 13; KeyEvent.KEYCODE_BUTTON_X -> 7; KeyEvent.KEYCODE_BUTTON_Y -> 8; else -> null }

    private inner class PixelView : View(this@MainActivity) {
        private val paint = Paint().apply { color = 0xFF8CFFBB.toInt(); style = Paint.Style.FILL }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); canvas.drawColor(Color.BLACK)
            val scale = min(width.toFloat() / 64, height.toFloat() / 32); val left = (width - 64 * scale) / 2; val top = (height - 32 * scale) / 2
            val px = vm.screen()
            for (y in 0 until 32) for (x in 0 until 64) if (px[y * 64 + x]) canvas.drawRect(left + x * scale, top + y * scale, left + (x + 1) * scale + .5f, top + (y + 1) * scale + .5f, paint)
        }
    }

    private fun button(text: String, color: Int, action: () -> Unit) { body.addView(Button(this).apply { this.text = text; setTextColor(if (color == 0xFF71E2B6.toInt()) Color.BLACK else Color.WHITE); setBackgroundColor(color); setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(9) }) }
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER; if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
