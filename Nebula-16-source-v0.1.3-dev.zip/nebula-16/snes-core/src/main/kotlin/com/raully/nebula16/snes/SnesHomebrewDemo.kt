package com.raully.nebula16.snes

/**
 * Tiny original LoROM demo generated from hand-assembled 65C816 bytes at runtime.
 * Hold controller A to move the solid player block right; hold B to move it left.
 * This is only an integration/playability smoke demo, not a commercial game or compatibility test.
 */
object SnesHomebrewDemo {
    fun createRom(): ByteArray {
        val p = Program()
        fun lda(value: Int) { p.emit(0xa9, value) }
        fun ldaAbsolute(address: Int) { p.emit(0xad, address and 0xff, address ushr 8) }
        fun sta(address: Int) { p.emit(0x8d, address and 0xff, address ushr 8) }
        fun setRegister(address: Int, value: Int) { lda(value); sta(address) }

        // Display mode 0 with the main BG1/OBJ screen enabled and OBJ tile data at word $1000.
        setRegister(0x2100, 0x0f)
        setRegister(0x2101, 0x01)
        setRegister(0x2107, 0x04)
        setRegister(0x212c, 0x11)

        // One 8x8, color-index-1 object in 4bpp format: a solid square.
        setRegister(0x2115, 0x80)
        setRegister(0x2116, 0x00)
        setRegister(0x2117, 0x10)
        repeat(8) {
            setRegister(0x2118, 0xff); setRegister(0x2119, 0x00) // plane 0
            setRegister(0x2118, 0x00); setRegister(0x2119, 0x00) // planes 1-3
        }
        setRegister(0x2121, 0x81) // OBJ palette 0, color 1
        setRegister(0x2122, 0x1f); setRegister(0x2122, 0x00) // red, BGR555

        p.label("poll")
        setRegister(0x4016, 0x01)
        setRegister(0x4016, 0x00)
        ldaAbsolute(0x4016)
        p.emit(0x29, 0x01) // AND #$01 — controller A
        p.branch(0xf0, "checkB") // BEQ
        lda(40)
        p.branch(0x80, "writeX") // BRA
        p.label("checkB")
        ldaAbsolute(0x4016)
        p.emit(0x29, 0x01) // next serial bit is controller B
        p.branch(0xf0, "center")
        lda(24)
        p.branch(0x80, "writeX")
        p.label("center")
        lda(32)
        p.label("writeX")
        sta(0x0000) // temporary X position in mirrored WRAM
        setRegister(0x2102, 0x00)
        setRegister(0x2103, 0x00)
        ldaAbsolute(0x0000); sta(0x2104) // OAM X
        setRegister(0x2104, 64) // OAM Y
        setRegister(0x2104, 0)  // tile 0
        setRegister(0x2104, 0)  // palette/priority/flip attributes
        p.branch(0x80, "poll")

        val rom = ByteArray(0x8000)
        p.finish().copyInto(rom)
        val title = "NEBULA HOME DEMO".toByteArray(Charsets.US_ASCII)
        title.copyInto(rom, 0x7fc0, endIndex = minOf(title.size, 21))
        rom[0x7ffc] = 0x00
        rom[0x7ffd] = 0x80.toByte()
        return rom
    }

    private class Program {
        private val code = mutableListOf<Int>()
        private val labels = mutableMapOf<String, Int>()
        private val branches = mutableListOf<Pair<Int, String>>()

        fun emit(vararg bytes: Int) { bytes.forEach { code += it and 0xff } }
        fun label(name: String) { check(labels.put(name, code.size) == null) { "Duplicate label: $name" } }
        fun branch(opcode: Int, label: String) {
            emit(opcode)
            branches += code.size to label
            emit(0)
        }
        fun finish(): ByteArray {
            for ((operandIndex, label) in branches) {
                val target = labels[label] ?: error("Unknown label: $label")
                val displacement = target - (operandIndex + 1)
                require(displacement in -128..127) { "Branch out of range to $label" }
                code[operandIndex] = displacement and 0xff
            }
            return ByteArray(code.size) { code[it].toByte() }
        }
    }
}
