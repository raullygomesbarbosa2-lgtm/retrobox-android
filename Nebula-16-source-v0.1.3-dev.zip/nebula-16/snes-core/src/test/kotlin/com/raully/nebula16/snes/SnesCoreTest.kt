package com.raully.nebula16.snes

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SnesCoreTest {
    @Test fun recognizesCommonSnesFileExtensionsWithoutTreatingChip8AsSnes() {
        assertTrue(SnesRomFileTypes.isSupportedName("game.sfc"))
        assertTrue(SnesRomFileTypes.isSupportedName("GAME.SMC"))
        assertTrue(SnesRomFileTypes.isSupportedName("backup.fig"))
        assertTrue(!SnesRomFileTypes.isSupportedName("demo.ch8"))
        assertTrue(!SnesRomFileTypes.isSupportedName("game.bin"))
    }

    @Test fun parsesLoRomResetVectorAndRunsOriginalSubset() {
        val rom = ByteArray(0x8000)
        rom[0x7ffc] = 0x00; rom[0x7ffd] = 0x80.toByte()
        rom[0] = 0xA9.toByte(); rom[1] = 0x2A
        rom[2] = 0x8D.toByte(); rom[3] = 0x00; rom[4] = 0x10
        rom[5] = 0xDB.toByte()
        val machine = SnesPrototype(rom)
        assertEquals(0x8000, machine.cpu.pc)
        machine.testInstructions(3)
        assertEquals(0x2a, machine.cpu.readWram(0x1000))
        assertTrue(machine.cpu.stopped)
    }

    @Test fun runs16BitAccumulatorAndRepSep() {
        val rom = ByteArray(0x8000)
        rom[0x7ffc] = 0x00; rom[0x7ffd] = 0x80.toByte()
        val program = byteArrayOf(
            0x18,                             // CLC
            0xFB.toByte(),                    // XCE — enter native mode
            0xC2.toByte(), 0x30,              // REP #$30 — 16-bit A and indexes
            0xA9.toByte(), 0x34, 0x12,        // LDA #$1234
            0x8D.toByte(), 0x00, 0x10,        // STA $1000
            0xE2.toByte(), 0x20,              // SEP #$20 — 8-bit A
            0xDB.toByte()                     // STP
        )
        program.forEachIndexed { index, value -> rom[index] = value }
        val machine = SnesPrototype(rom)
        machine.testInstructions(7)
        assertEquals(0x34, machine.cpu.readWram(0x1000))
        assertEquals(0x12, machine.cpu.readWram(0x1001))
        assertEquals(0x1234, machine.cpu.a)
        assertTrue(machine.cpu.stopped)
    }

    @Test fun originalLoRomHomebrewSmokeProgramRunsThroughMachineIntoPpuFrame() {
        val rom = ByteArray(0x8000)
        rom[0x7ffc] = 0x00; rom[0x7ffd] = 0x80.toByte()
        val program = mutableListOf<Int>()
        fun lda(value: Int) { program.add(0xA9); program.add(value and 0xff) }
        fun sta(address: Int) { program.add(0x8D); program.add(address and 0xff); program.add((address ushr 8) and 0xff) }
        fun setReg(address: Int, value: Int) { lda(value); sta(address) }
        setReg(0x2100, 0x0f) // show the display
        setReg(0x212c, 0x01) // enable BG1 on the main screen
        setReg(0x2107, 0x04) // BG1 map begins at VRAM word 0x0200
        setReg(0x2115, 0x80) // increment VRAM address after high-byte writes
        setReg(0x2116, 0x00); setReg(0x2117, 0x00)
        repeat(8) { row ->
            // Original checker tile: red stripes on even rows, green stripes on odd rows.
            setReg(0x2118, if (row % 2 == 0) 0xaa else 0x00)
            setReg(0x2119, if (row % 2 == 0) 0x00 else 0xaa)
        }
        setReg(0x2116, 0x00); setReg(0x2117, 0x02)
        setReg(0x2118, 0x00); setReg(0x2119, 0x00) // map entry points at tile 0
        setReg(0x2121, 0x01); setReg(0x2122, 0x1f); setReg(0x2122, 0x00) // palette 1 red
        setReg(0x2121, 0x02); setReg(0x2122, 0xe0); setReg(0x2122, 0x03) // palette 2 green
        program += 0xDB
        program.forEachIndexed { index, byte -> rom[index] = byte.toByte() }

        val machine = SnesMachine(rom, instructionsPerFrame = 1_000)
        val frame = machine.runFrame()
        assertEquals(0xffff0000.toInt(), frame[0])
        assertEquals(0xff000000.toInt(), frame[1])
        assertEquals(0xff00ff00.toInt(), frame[SnesPpu.WIDTH])
        assertEquals(null, machine.faultMessage)
        assertTrue(machine.cpu.stopped)
    }

    @Test fun controllerPortIsReachableThroughCpuBus() {
        val rom = ByteArray(0x8000)
        rom[0x7ffc] = 0x00; rom[0x7ffd] = 0x80.toByte()
        val program = byteArrayOf(
            0xA9.toByte(), 0x01, 0x8D.toByte(), 0x16, 0x40,
            0xA9.toByte(), 0x00, 0x8D.toByte(), 0x16, 0x40,
            0xAD.toByte(), 0x16, 0x40, 0x8D.toByte(), 0x00, 0x10, 0xDB.toByte()
        )
        program.forEachIndexed { index, value -> rom[index] = value }
        val machine = SnesMachine(rom)
        machine.setButton(SnesButton.A, true)
        machine.runFrame()
        assertEquals(1, machine.cpu.readWram(0x1000))
        assertTrue(machine.cpu.stopped)
    }

    @Test fun originalHomebrewDemoDrawsPlayerAndControllerMovesItBothWays() {
        val machine = SnesMachine(SnesHomebrewDemo.createRom(), instructionsPerFrame = 200)
        val row = 64 * SnesPpu.WIDTH
        val red = 0xffff0000.toInt()
        val black = 0xff000000.toInt()

        var frame = machine.runFrame()
        assertEquals(null, machine.faultMessage, "CPU stop before first draw; pc=%04x steps=%d".format(machine.cpu.pc, machine.cpu.instructionsExecuted))
        assertEquals(0x00ff, machine.ppu.readVramWord(0x0008), "tile 1 plane data")
        assertEquals(0x0001, machine.ppu.readVramWord(0x0304), "center tilemap entry")
        assertEquals(red, frame[row + 32], "center position before input, pixel=%08x".format(frame[row + 32]))
        machine.setButton(SnesButton.A, true)
        frame = machine.runFrame()
        assertEquals(red, frame[row + 40], "A moves the player right")
        assertEquals(black, frame[row + 32], "the former player position is cleared")
        machine.setButton(SnesButton.A, false)
        machine.setButton(SnesButton.B, true)
        frame = machine.runFrame()
        assertEquals(red, frame[row + 24], "B moves the player left")
        assertEquals(null, machine.faultMessage)
    }

    @Test fun machineReportsUnsupportedOpcodeInsteadOfSilentlyShowingAFrozenFrame() {
        val rom = ByteArray(0x8000)
        rom[0x7ffc] = 0x00; rom[0x7ffd] = 0x80.toByte()
        rom[0] = 0x02 // deliberately unsupported COP opcode for this partial CPU
        val machine = SnesMachine(rom, instructionsPerFrame = 32)

        machine.runFrame()

        assertTrue(machine.cpu.stopped)
        assertEquals("Unsupported 65C816 opcode 02 at 00:8000", machine.faultMessage)
        assertEquals(1, machine.cpu.instructionsExecuted)
    }

    @Test fun stripsCopierHeader() {
        val rom = ByteArray(512 + 0x8000)
        val cart = Cartridge.parse(rom)
        assertTrue(cart.hasCopierHeader)
        assertEquals(0x8000, cart.rom.size)
    }
}
