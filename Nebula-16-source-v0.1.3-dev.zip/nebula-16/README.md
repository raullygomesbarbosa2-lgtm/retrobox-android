# Nébula 16 — projeto autoral Android

Aplicativo Android em desenvolvimento, com uma interface própria e dois sistemas selecionáveis: um interpretador CHIP-8 jogável e um núcleo SNES experimental, escrito do zero em Kotlin. Não embute interfaces ou núcleos de outros emuladores.

## Situação real desta prévia

- **CHIP-8:** roda o demo original incluído no código e aceita ROMs `.ch8`/arquivos binários locais. Inclui controles de toque e suporte básico a controles físicos reconhecidos pelo Android.
- **Super Nintendo:** lê cartucho LoROM simples, tem frame loop experimental em uma thread de execução separada da interface, controles de toque/controle físico, CPU 65C816 parcial, WRAM/LoROM, PPU Mode 0 BG1 e objetos básicos 8×8. Se a CPU encontrar uma instrução ainda não implementada, o protótipo agora informa o ponto em que parou.
- **Ainda não é um emulador SNES compatível com jogos.** O frame loop usa um orçamento aproximado; ROMs podem parar numa instrução ainda não implementada ou não mostrar nada. Há um teste sintético original que executa uma cena simples pelo CPU/barramento/PPU, mas isso não é um jogo nem prova compatibilidade com cartuchos comerciais. Faltam muitas instruções e timing da CPU, outros modos/camadas/sprites da PPU, APU, DMA/HDMA, interrupções, mapeamento completo e precisão de cartucho. Nenhum jogo SNES comercial foi verificado.
- Nenhuma ROM comercial, BIOS, firmware ou jogo de terceiros é incluído.

O projeto é original, mas isso não significa que ninguém jamais tenha feito um emulador de SNES: o que é novo aqui é este código e esta identidade de projeto. Compatibilidade não é garantida.

## Compilar pelo GitHub Actions

Envie o conteúdo desta pasta para um repositório GitHub e rode o workflow **Build Nébula 16** em Actions (ou faça push na branch `main`). O workflow testa os núcleos e produz `app-debug.apk` como artefato para baixar. Requer Android SDK API 35, JDK 17 e Gradle 8.10.2; o workflow configura isso automaticamente.

## Estrutura

- `app/` — app nativo, interface e controles.
- `chip8-core/` — interpretador CHIP-8 autoral e testes.
- `snes-core/` — carregador LoROM, mapeamento inicial e CPU 65C816 parcial, com testes.
