plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.raully.retrobox"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.raully.retrobox"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "0.1.1"
    }
}
