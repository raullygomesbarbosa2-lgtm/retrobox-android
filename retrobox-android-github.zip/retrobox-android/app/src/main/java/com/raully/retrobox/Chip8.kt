package com.raully.retrobox

import kotlin.random.Random

/** Compact CHIP-8 interpreter. Runs at 600 instructions/s with 60 Hz timers. */
class Chip8 {
    private val memory = IntArray(4096)
    private val v = IntArray(16)
    private val stack = IntArray(16)
    private val display = BooleanArray(64 * 32)
    private val keys = BooleanArray(16)
    private var sp = 0
    private var i = 0
    private var pc = 0x200
    var delayTimer = 0
        private set
    var soundTimer = 0
        private set
    var changed = true
        private set

    val pixels: BooleanArray get() = display

    private val font = intArrayOf(
        0xF0,0x90,0x90,0x90,0xF0, 0x20,0x60,0x20,0x20,0x70,
        0xF0,0x10,0xF0,0x80,0xF0, 0xF0,0x10,0xF0,0x10,0xF0,
        0x90,0x90,0xF0,0x10,0x10, 0xF0,0x80,0xF0,0x10,0xF0,
        0xF0,0x80,0xF0,0x90,0xF0, 0xF0,0x10,0x20,0x40,0x40,
        0xF0,0x90,0xF0,0x90,0xF0, 0xF0,0x90,0xF0,0x10,0xF0,
        0xF0,0x90,0xF0,0x90,0x90, 0xE0,0x90,0xE0,0x90,0xE0,
        0xF0,0x80,0x80,0x80,0xF0, 0xE0,0x90,0x90,0x90,0xE0,
        0xF0,0x80,0xF0,0x80,0xF0, 0xF0,0x80,0xF0,0x80,0x80
    )

    fun load(bytes: ByteArray) {
        require(bytes.isNotEmpty() && bytes.size <= 3584) { "CHIP-8 ROM must be 1–3584 bytes." }
        memory.fill(0); v.fill(0); stack.fill(0); display.fill(false); keys.fill(false)
        font.forEachIndexed { index, value -> memory[0x50 + index] = value }
        bytes.forEachIndexed { index, value -> memory[0x200 + index] = value.toInt() and 0xFF }
        sp = 0; i = 0; pc = 0x200; delayTimer = 0; soundTimer = 0; changed = true
    }

    fun setKey(key: Int, down: Boolean) { if (key in 0..15) keys[key] = down }
    fun tickTimers() { if (delayTimer > 0) delayTimer--; if (soundTimer > 0) soundTimer-- }

    fun cycle() {
        if (pc !in 0..4094) { pc = 0x200; return }
        val op = ((memory[pc] shl 8) or memory[pc + 1]) and 0xFFFF
        val x = (op shr 8) and 0xF
        val y = (op shr 4) and 0xF
        val n = op and 0xF
        val nn = op and 0xFF
        val nnn = op and 0xFFF
        pc = (pc + 2) and 0xFFF
        when (op and 0xF000) {
            0x0000 -> when (op) {
                0x00E0 -> { display.fill(false); changed = true }
                0x00EE -> if (sp > 0) pc = stack[--sp]
            }
            0x1000 -> pc = nnn
            0x2000 -> { if (sp < stack.size) { stack[sp++] = pc; pc = nnn } }
            0x3000 -> if (v[x] == nn) pc += 2
            0x4000 -> if (v[x] != nn) pc += 2
            0x5000 -> if (n == 0 && v[x] == v[y]) pc += 2
            0x6000 -> v[x] = nn
            0x7000 -> v[x] = (v[x] + nn) and 0xFF
            0x8000 -> when (n) {
                0x0 -> v[x] = v[y]
                0x1 -> v[x] = v[x] or v[y]
                0x2 -> v[x] = v[x] and v[y]
                0x3 -> v[x] = v[x] xor v[y]
                0x4 -> { val sum = v[x] + v[y]; v[15] = if (sum > 255) 1 else 0; v[x] = sum and 0xFF }
                0x5 -> { v[15] = if (v[x] >= v[y]) 1 else 0; v[x] = (v[x] - v[y]) and 0xFF }
                0x6 -> { v[15] = v[x] and 1; v[x] = v[x] ushr 1 }
                0x7 -> { v[15] = if (v[y] >= v[x]) 1 else 0; v[x] = (v[y] - v[x]) and 0xFF }
                0xE -> { v[15] = (v[x] ushr 7) and 1; v[x] = (v[x] shl 1) and 0xFF }
            }
            0x9000 -> if (n == 0 && v[x] != v[y]) pc += 2
            0xA000 -> i = nnn
            0xB000 -> pc = (nnn + v[0]) and 0xFFF
            0xC000 -> v[x] = Random.nextInt(256) and nn
            0xD000 -> {
                val px = v[x] % 64; val py = v[y] % 32; v[15] = 0
                for (row in 0 until n) {
                    val sprite = memory[(i + row) and 0xFFF]
                    for (bit in 0..7) if ((sprite and (0x80 shr bit)) != 0) {
                        val at = ((py + row) % 32) * 64 + ((px + bit) % 64)
                        if (display[at]) v[15] = 1
                        display[at] = !display[at]
                    }
                }
                changed = true
            }
            0xE000 -> when (nn) {
                0x9E -> if (keys[v[x] and 0xF]) pc += 2
                0xA1 -> if (!keys[v[x] and 0xF]) pc += 2
            }
            0xF000 -> when (nn) {
                0x07 -> v[x] = delayTimer
                0x0A -> { val pressed = keys.indexOfFirst { it }; if (pressed < 0) pc -= 2 else v[x] = pressed }
                0x15 -> delayTimer = v[x]
                0x18 -> soundTimer = v[x]
                0x1E -> i = (i + v[x]) and 0xFFF
                0x29 -> i = 0x50 + (v[x] and 0xF) * 5
                0x33 -> { memory[i] = v[x] / 100; memory[(i + 1) and 0xFFF] = (v[x] / 10) % 10; memory[(i + 2) and 0xFFF] = v[x] % 10 }
                0x55 -> for (r in 0..x) memory[(i + r) and 0xFFF] = v[r]
                0x65 -> for (r in 0..x) v[r] = memory[(i + r) and 0xFFF]
            }
        }
        pc = pc and 0xFFF
    }
}
