package com.raully.retrobox

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val vm = Chip8()
    private var gameView: Chip8GameView? = null
    private var running = false
    private var waitingForButton = false
    private var selectedChipKey = 5
    private val physicalMap = mutableMapOf<Int, Int>()
    private val defaults = mapOf(
        KeyEvent.KEYCODE_DPAD_UP to 2, KeyEvent.KEYCODE_DPAD_DOWN to 8,
        KeyEvent.KEYCODE_DPAD_LEFT to 4, KeyEvent.KEYCODE_DPAD_RIGHT to 6,
        KeyEvent.KEYCODE_BUTTON_A to 5, KeyEvent.KEYCODE_BUTTON_B to 13,
        KeyEvent.KEYCODE_BUTTON_X to 7, KeyEvent.KEYCODE_BUTTON_Y to 8,
        KeyEvent.KEYCODE_BUTTON_L1 to 10, KeyEvent.KEYCODE_BUTTON_R1 to 11,
        KeyEvent.KEYCODE_BUTTON_START to 12, KeyEvent.KEYCODE_BUTTON_SELECT to 14
    )
    private val handler = android.os.Handler(mainLooper)
    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            repeat(10) { vm.cycle() }
            if (SystemClockCompat.now() - lastTimer >= 16) { vm.tickTimers(); lastTimer = SystemClockCompat.now() }
            gameView?.invalidate()
            handler.postDelayed(this, 16)
        }
    }
    private var lastTimer = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            loadMappings()
            showHome()
        } catch (e: Exception) {
            showStartupError(e)
        }
    }

    private fun showStartupError(error: Exception) {
        val details = error.message ?: error.javaClass.simpleName
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 20, 28, 20)
            setBackgroundColor(Color.rgb(10, 15, 24))
        }
        screen.addView(TextView(this).apply {
            text = "RetroBox não conseguiu iniciar"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        screen.addView(TextView(this).apply {
            text = "Diagnóstico: $details"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 0)
        })
        setContentView(screen)
    }

    private fun immersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 20, 28, 20); setBackgroundColor(Color.rgb(10, 15, 24)) }
        root.addView(TextView(this).apply { text = "RetroBox"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 0, 0, 8) })
        root.addView(TextView(this).apply { text = "CHIP-8 offline"; textSize = 15f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, 22) })
        root.addView(Button(this).apply { text = "ABRIR ROM CHIP-8"; setOnClickListener { openRom() } })
        root.addView(Button(this).apply { text = "CONFIGURAR CONTROLE"; setOnClickListener { showControllerSetup() } })
        root.addView(TextView(this).apply { text = "Este protótipo já roda CHIP-8. O núcleo SNES ainda não está integrado."; textSize = 12f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(18, 16, 18, 0) })
        setContentView(root)
    }

    private fun openRom() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(i, 10)
    }

    @Deprecated("The document picker result is handled for broad Android compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 10 || resultCode != RESULT_OK || data?.data == null) return
        try {
            val bytes = contentResolver.openInputStream(data.data!!)?.use { it.readBytes() } ?: error("Não foi possível abrir o arquivo")
            vm.load(bytes)
            startGame()
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "ROM inválida", Toast.LENGTH_LONG).show()
        }
    }

    private fun startGame() {
        immersive(); running = true; lastTimer = SystemClockCompat.now()
        gameView = Chip8GameView(this, vm).apply { isFocusable = true; isFocusableInTouchMode = true }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(gameView, FrameLayout.LayoutParams(-1, -1))
        val close = Button(this).apply { text = "×"; textSize = 20f; alpha = .65f; setOnClickListener { running = false; handler.removeCallbacks(loop); showHome() } }
        val settings = Button(this).apply { text = "⚙"; textSize = 18f; alpha = .65f; setOnClickListener { showControllerSetup() } }
        val lpClose = FrameLayout.LayoutParams(dp(48), dp(46), Gravity.TOP or Gravity.END).apply { topMargin = dp(4); rightMargin = dp(8) }
        val lpSettings = FrameLayout.LayoutParams(dp(48), dp(46), Gravity.TOP or Gravity.END).apply { topMargin = dp(4); rightMargin = dp(58) }
        root.addView(settings, lpSettings); root.addView(close, lpClose)
        setContentView(root); gameView?.requestFocus(); handler.removeCallbacks(loop); handler.post(loop)
    }

    private fun showControllerSetup() {
        val keys = arrayOf("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F")
        AlertDialog.Builder(this).setTitle("Mapear controle Bluetooth/USB")
            .setItems(keys) { _, which ->
                selectedChipKey = which
                waitingForButton = true
                Toast.makeText(this, "Agora pressione o botão físico que quer associar à tecla ${keys[which]}", Toast.LENGTH_LONG).show()
            }
            .setNeutralButton("Restaurar padrão") { _, _ -> physicalMap.clear(); saveMappings(); Toast.makeText(this, "Mapeamento padrão restaurado", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Fechar", null).show()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_GAMEPAD) || event.isFromSource(InputDevice.SOURCE_DPAD) || event.keyCode in defaults.keys || physicalMap.containsKey(event.keyCode)) {
            if (waitingForButton && event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                physicalMap[event.keyCode] = selectedChipKey; waitingForButton = false; saveMappings()
                Toast.makeText(this, "Botão associado", Toast.LENGTH_SHORT).show(); return true
            }
            val k = physicalMap[event.keyCode] ?: defaults[event.keyCode]
            if (k != null) { vm.setKey(k, event.action == KeyEvent.ACTION_DOWN); gameView?.invalidate(); return true }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: android.view.MotionEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_JOYSTICK) && event.action == android.view.MotionEvent.ACTION_MOVE) {
            val x = event.getAxisValue(android.view.MotionEvent.AXIS_X); val y = event.getAxisValue(android.view.MotionEvent.AXIS_Y)
            vm.setKey(4, x < -.45f); vm.setKey(6, x > .45f); vm.setKey(2, y < -.45f); vm.setKey(8, y > .45f)
            gameView?.invalidate(); return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    private fun loadMappings() {
        val raw = getSharedPreferences("pads", MODE_PRIVATE).getString("map", "") ?: ""
        raw.split(",").forEach { pair -> val p = pair.split(":"); if (p.size == 2) p[0].toIntOrNull()?.let { a -> p[1].toIntOrNull()?.let { b -> physicalMap[a] = b } } }
    }
    private fun saveMappings() { getSharedPreferences("pads", MODE_PRIVATE).edit().putString("map", physicalMap.entries.joinToString(",") { "${it.key}:${it.value}" }).apply() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onPause() { super.onPause(); running = false; handler.removeCallbacks(loop) }
    override fun onResume() { super.onResume(); if (gameView != null && !running) { running = true; lastTimer = SystemClockCompat.now(); handler.post(loop) }; if (gameView != null) immersive() }
}

private object SystemClockCompat { fun now() = android.os.SystemClock.uptimeMillis() }
