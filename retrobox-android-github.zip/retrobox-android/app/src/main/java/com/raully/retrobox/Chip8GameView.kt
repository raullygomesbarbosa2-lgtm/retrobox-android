package com.raully.retrobox

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

class Chip8GameView(context: Context, private val vm: Chip8) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val activePointers = HashMap<Int, Int>()
    private val chipColor = 0xFF8CFFBB.toInt()
    private val controlColor = 0x66D7E4F5
    init { isFocusable = true; isFocusableInTouchMode = true; setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xFF000000.toInt())
        val scale = min(width.toFloat() / 64f, height.toFloat() / 32f)
        val w = scale * 64f; val h = scale * 32f
        val left = (width - w) / 2f; val top = (height - h) / 2f
        paint.color = chipColor; paint.style = Paint.Style.FILL
        val px = vm.pixels
        for (y in 0 until 32) for (x in 0 until 64) if (px[y * 64 + x]) {
            canvas.drawRect(left + x * scale, top + y * scale, left + (x + 1) * scale + .4f, top + (y + 1) * scale + .4f, paint)
        }
        drawControls(canvas)
    }

    private fun drawControls(c: Canvas) {
        val unit = resources.displayMetrics.density
        val r = 22f * unit
        val cx = 74f * unit; val cy = height - 76f * unit
        paint.color = controlColor; paint.style = Paint.Style.FILL
        c.drawCircle(cx, cy - r * 1.25f, r, paint); c.drawCircle(cx - r * 1.3f, cy, r, paint)
        c.drawCircle(cx + r * 1.3f, cy, r, paint); c.drawCircle(cx, cy + r * 1.25f, r, paint)
        val ax = width - 86f * unit; val ay = height - 76f * unit
        c.drawCircle(ax, ay, r * 1.12f, paint); c.drawCircle(ax + r * 1.7f, ay - r * .6f, r * 1.12f, paint)
        paint.color = 0xFFFFFFFF.toInt(); paint.textSize = 14f * unit; paint.textAlign = Paint.Align.CENTER
        c.drawText("A", ax, ay + 5f * unit, paint); c.drawText("B", ax + r * 1.7f, ay - r * .6f + 5f * unit, paint)
    }

    private fun keyAt(x: Float, y: Float): Int? {
        val unit = resources.displayMetrics.density
        val r = 30f * unit; val leftCx = 74f * unit; val cy = height - 76f * unit
        if (x < width * .42f && y > height * .55f) {
            val dx = x - leftCx; val dy = y - cy
            if (kotlin.math.abs(dx) > kotlin.math.abs(dy) && kotlin.math.abs(dx) > r * .5f) return if (dx < 0) 4 else 6
            if (kotlin.math.abs(dy) > r * .5f) return if (dy < 0) 2 else 8
        }
        if (x > width * .62f && y > height * .55f) return if (x < width * .86f) 5 else 13
        return null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val idx = event.actionIndex; val id = event.getPointerId(idx)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                keyAt(event.getX(idx), event.getY(idx))?.let { activePointers[id] = it; vm.setKey(it, true) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                activePointers.remove(id)?.let { key -> if (activePointers.values.none { it == key }) vm.setKey(key, false) }
            }
            MotionEvent.ACTION_MOVE -> {
                for (p in 0 until event.pointerCount) {
                    val pid = event.getPointerId(p); val old = activePointers[pid]; val now = keyAt(event.getX(p), event.getY(p))
                    if (old != now) { old?.let { vm.setKey(it, false) }; now?.let { vm.setKey(it, true) }; if (now == null) activePointers.remove(pid) else activePointers[pid] = now }
                }
            }
        }
        invalidate(); return true
    }
}
