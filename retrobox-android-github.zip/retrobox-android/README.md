# Nébula Retro — PSP + PlayStation

Este APK é uma personalização de código aberto do projeto [Lemuroid](https://github.com/Swordfish90/Lemuroid), distribuída sob GPLv3 e com os créditos/licenças preservados em `COPYING` e `SOURCE_LICENSES.md`.

## Sistemas habilitados

- **PSP:** núcleo PPSSPP via Libretro. O PPSSPP usa HLE e não exige uma BIOS de PSP.
- **PlayStation original (PS1):** núcleo PCSX-ReARMed. Sem BIOS compatível, o núcleo recorre ao HLE; alguns jogos podem apresentar incompatibilidades ou não iniciar.

Os jogos e BIOS não acompanham o aplicativo. O usuário escolhe a pasta da biblioteca, mantém os jogos de PSP e PS1 em pastas distintas e toca no jogo listado para iniciar. A tela de jogo fica em paisagem e usa controles táteis próprios de cada sistema. O desempenho depende do aparelho, do jogo e da configuração; 30 FPS é uma meta, não uma garantia para todos os celulares.

## Fontes e licenças

- Aplicativo/frontend: Lemuroid, GPLv3 — https://github.com/Swordfish90/Lemuroid
- Núcleos Android empacotados pela distribuição de cores do Lemuroid: https://github.com/Swordfish90/LemuroidCores (commit `fee2e824525daa22bcf318f96127fe43fa8a15ad`)
- Núcleo PSP PPSSPP, HLE/sem BIOS — https://github.com/hrydgard/ppsspp
- Núcleo PS1 PCSX-ReARMed/HLE — https://github.com/libretro/pcsx_rearmed e https://docs.libretro.com/library/pcsx_rearmed/

O projeto não inclui jogos, imagens de disco, BIOS ou firmware proprietário. Os avisos de copyright das dependências foram mantidos. Consulte `COPYING` e os arquivos de licença nas fontes dos núcleos.

## Build

O workflow do repositório compila a variante Android `freeBundleDebug`, usando JDK 17, Gradle 8.10.2 e SDK Android 35. O projeto original usa o submódulo público `LemuroidCores`, fixado no commit acima.
