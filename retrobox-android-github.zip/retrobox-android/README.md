# Nébula Retro — projeto Android nativo

O APK deste projeto chama-se **Nébula Retro** e **não é um emulador PSP/PS1**. A implementação atual é um emulador básico de CHIP-8, com abertura de ROM local, controles por toque e suporte básico a controles físicos. O aplicativo não possui núcleos PSP ou PS1, portanto não executa jogos dessas plataformas. A inicialização foi simplificada e, se a tela inicial falhar, o app tenta mostrar o erro e os dados do aparelho para diagnóstico.

## Estado atual

- **CHIP-8:** implementado no app.
- **PSP:** não integrado. Nenhum jogo PSP pode ser aberto/executado nesta versão.
- **PlayStation original (PS1):** não integrado. Nenhum jogo PS1 pode ser aberto/executado nesta versão.
- O projeto não inclui jogos, ROMs, BIOS/firmware ou assets proprietários.

## Pesquisa para uma integração PSP + PS1

A pesquisa confirma caminhos open-source possíveis, mas ainda não fornece uma integração pronta e testada para este app:

- **PSP — PPSSPP:** o projeto upstream é um emulador HLE e declara que não requer arquivo de BIOS; sua licença é GPL-2.0-or-later. A documentação do core Libretro também descreve o PPSSPP, mas diz que assets auxiliares (por exemplo, fontes e fundos) são necessários para funcionalidade completa. A existência dessa documentação/core não demonstra que haja um artefato Android pronto, compatível e mantido que possa ser simplesmente adicionado a este app. Não foi incorporado nenhum binário nem fonte de terceiros nesta alteração.
- **PS1 — PCSX-ReARMed:** o core é GPL-2.0 e possui BIOS HLE como fallback quando não encontra uma BIOS compatível. A documentação oficial do Libretro alerta que o HLE reduz a compatibilidade e pode causar problemas em alguns jogos, telas pretas e problemas de memory card. Portanto, não é correto prometer compatibilidade universal ou uma experiência PS1 equivalente à de uma BIOS real.

Fontes consultadas:

- PPSSPP upstream (descrição HLE, requisito de BIOS e licença): https://github.com/hrydgard/ppsspp
- Documentação Libretro do core PPSSPP (assets e extensões aceitas): https://docs.libretro.com/library/ppsspp/
- Documentação Libretro do core PCSX-ReARMed (BIOS/HLE, limitações e extensões): https://docs.libretro.com/library/pcsx_rearmed/
- Repositório PCSX-ReARMed: https://github.com/libretro/pcsx_rearmed
- Relato de junho de 2026 sobre interrupção recente de builds do core PPSSPP no buildbot Libretro — um sinal adicional para verificar o estado de manutenção antes de adotar esse pacote: https://github.com/libretro/libretro-super/issues/1987

## Próximas etapas técnicas para PSP + PS1

Para entregar um único APK real, será necessário selecionar e fixar versões de código-fonte licenciadas dos dois núcleos, validar o estado de manutenção/build para Android e cumprir as licenças (incluindo avisos e disponibilização das fontes/alterações exigidos pelas licenças GPL). Depois será preciso compilar os núcleos para as ABIs Android escolhidas, implementar a ponte JNI/renderização/entrada/áudio e ciclo de vida, persistência de saves e uma biblioteca com áreas claramente separadas para PSP e PS1. Os seletores de arquivo deverão aceitar formatos próprios de cada core (por exemplo, PSP ISO/CSO/CHD e PS1 BIN/CUE/CHD); a leitura de jogos e de possíveis arquivos escolhidos pelo usuário deve funcionar sem empacotar conteúdo protegido.

A organização planejada deve manter conteúdo e dados internos separados, por exemplo `files/psp/` e `files/ps1/`, incluindo saves/estados próprios de cada sistema. A biblioteca deve ter seções e seletores locais independentes; um arquivo escolhido para um sistema nunca deve ser enviado ao core do outro.

**Meta de desempenho: 30 FPS.** Tratar como objetivo de renderização/desempenho a validar em dispositivos e jogos, não como promessa de desempenho mínimo nem como limite de velocidade da emulação. A temporização de cada jogo deve seguir o relógio/timing do core; frameskip/adaptação de renderização não pode acelerar, desacelerar ou quebrar a lógica do jogo. Qualquer taxa sustentada deve ser medida por aparelho/jogo antes de ser anunciada.

No PSP, a rota mais segura a avaliar é integrar o código-fonte Android upstream do PPSSPP, que tem HLE e não exige BIOS. Para PS1, PCSX-ReARMed pode permitir inicialização via HLE sem uma BIOS fornecida, mas essa escolha precisa ser testada com uma matriz de jogos e deve comunicar a compatibilidade limitada. Não foi adicionada uma tela de seleção de jogos PSP/PS1 que pudesse sugerir que a emulação já funciona.

## Compilar o app atual

O workflow `.github/workflows/android-apk.yml` gera um APK de depuração em GitHub Actions após push em `main`/`master` ou execução manual. O workflow não foi acionado nesta tarefa e exige um repositório já configurado pelo usuário. Para compilar manualmente, use Android Studio, JDK 17 e Android SDK Platform 35; abra a pasta do projeto e execute **Build > Build APK(s)**.

## CHIP-8

O interpretador suporta os opcodes comuns de CHIP-8, temporizadores a 60 Hz e desenho 64×32. Variantes como SCHIP/XO-CHIP, áudio e comportamentos específicos podem não ser compatíveis. O mapeamento de botões físicos é salvo no aparelho.
