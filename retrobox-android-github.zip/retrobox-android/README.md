# RetroBox — projeto Android nativo (protótipo)

Este projeto é um ponto de partida **Android nativo**, não uma página web. O CHIP-8 já está integrado: abre ROM local com o seletor do Android, roda em tela imersiva, oferece controles de toque e recebe controles Bluetooth/USB reconhecidos pelo Android. O remapeamento de botões é salvo no aparelho.

## Estado honesto do projeto

- CHIP-8: núcleo básico funcional, execução local e sem rede.
- SNES: **ainda não integrado**. Para emular SNES de verdade falta adicionar um núcleo compatível (por exemplo, Snes9x) e conectá-lo à interface nativa. Este projeto não finge executar ROMs SNES.
- Não acompanha ROMs ou BIOS.
- Não é um APK pronto: este ambiente não tinha Java, Gradle nem Android SDK para compilar e testar. Abra a pasta no Android Studio (JDK 17 + Android SDK API 35) e sincronize o Gradle para gerar um APK de depuração.

## Abrir e compilar

1. Instale Android Studio com JDK 17 e Android SDK Platform 35.
2. Abra a pasta `retrobox-android` no Android Studio e aguarde a sincronização do Gradle.
3. Conecte o telefone com depuração USB ativada (ou use um emulador Android).
4. Selecione **Run** para instalar a versão de depuração, ou use **Build > Build APK(s)**.
5. No app, abra uma ROM CHIP-8 local. Para usar controle Bluetooth, pareie-o nas configurações do Android e remapeie os botões no ícone de engrenagem.

## Limitações do CHIP-8

É um interpretador CHIP-8 clássico e compacto, com os opcodes comuns, temporizadores a 60 Hz e desenho 64×32. ROMs que dependem de variantes (SCHIP/XO-CHIP), áudio ou comportamento específico podem não ser compatíveis. A execução é otimizada para aparelhos comuns, mas desempenho e compatibilidade variam por dispositivo e ROM.

## Compilar pela nuvem com GitHub Actions (sem Android Studio no telefone)

O projeto inclui `.github/workflows/android-apk.yml`. Depois que o conteúdo do projeto estiver em um repositório GitHub, o fluxo compila o APK quando houver push em `main`/`master` ou quando for acionado manualmente em **Actions → Build Android APK → Run workflow**. O APK aparece em **Artifacts** como `retrobox-debug-apk` e fica disponível por 14 dias. É um APK de depuração, não assinado para publicação na Play Store.

Esta configuração automatiza o build, mas não conecta nem cria um repositório na conta do usuário. É necessário colocar os arquivos deste projeto em um repositório GitHub para o fluxo rodar. O APK que esse projeto produz atualmente contém o CHIP-8; o núcleo SNES ainda não foi implementado.
