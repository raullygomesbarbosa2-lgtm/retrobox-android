# Créditos e licenças

Nébula Retro adapta o frontend Lemuroid para habilitar somente PSP e PS1. O projeto derivado permanece sob GPLv3; veja `COPYING`.

- Lemuroid frontend: https://github.com/Swordfish90/Lemuroid
- LemuroidCores, distribuição dos binários Libretro e seus avisos de licença: https://github.com/Swordfish90/LemuroidCores/tree/fee2e824525daa22bcf318f96127fe43fa8a15ad
- PPSSPP (PSP): https://github.com/hrydgard/ppsspp
- PCSX-ReARMed (PS1): https://github.com/libretro/pcsx_rearmed

As licenças, avisos e fontes correspondentes estão publicados pelos projetos de origem; esta distribuição não remove seus avisos. Nenhum jogo comercial, BIOS ou firmware é incluído.
