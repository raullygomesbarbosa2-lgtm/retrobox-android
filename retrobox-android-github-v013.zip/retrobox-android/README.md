# Nébula Retro — PSP + PlayStation (PS1)

Este APK é uma personalização do frontend de código aberto [Lemuroid](https://github.com/Swordfish90/Lemuroid), com suporte somente aos sistemas PSP e PlayStation original (PS1). A tela de jogo é em paisagem e o app oferece controles táteis e suporte a gamepad.

## Jogos e sistemas

O app não inclui jogos, imagens de disco, BIOS ou firmware. Adicione apenas seus próprios jogos legalmente obtidos. Como `.iso` e `.pbp` podem ser usados pelos dois sistemas, mantenha os arquivos em pastas diferentes cuja rota completa contenha `psx` ou `psp` — por exemplo `Games/PSX/` e `Games/PSP/`. O scanner usa o caminho da pasta para atribuir os arquivos ambíguos ao sistema/core correspondente. PS1 reconhece ISO/PBP/CHD/CUE/M3U; PSP reconhece ISO/CSO/PBP.

PPSSPP usa HLE e não exige BIOS externa de PSP. PCSX-ReARMed pode recorrer a HLE sem BIOS de PS1, mas alguns jogos podem ter problemas de compatibilidade.

## Bibliotecas e ABI

O APK inclui os binários nativos PCSX-ReARMed e PPSSPP do [LemuroidCores](https://github.com/Swordfish90/LemuroidCores), fixados no commit `fee2e824525daa22bcf318f96127fe43fa8a15ad`, para `arm64-v8a`, `armeabi-v7a` e `x86`. Esse commit contém um placeholder PPSSPP de zero bytes para `x86_64`; por isso o app restringe explicitamente as ABIs a que têm ambos os núcleos funcionais. Não promete compatibilidade com telefones que não suportam uma dessas ABIs.

O frontend Lemuroid é GPL-3.0-or-later (ver `COPYING`). Os avisos e as licenças individuais dos núcleos devem ser consultados no repositório LemuroidCores e nas fontes de PCSX-ReARMed/PPSSPP; veja também `SOURCE_LICENSES.md`. Nenhum jogo ou BIOS acompanha o app.

## Desempenho

O desempenho depende do aparelho, do jogo, dos drivers gráficos e das configurações. Este APK não foi testado em todos os dispositivos; a jogabilidade deve ser verificada no aparelho de destino. Não há garantia de desempenho suave ou de taxa de quadros específica.
