# Créditos e licenças

Nébula Retro adapta o frontend Lemuroid para habilitar somente PSP e PS1. O projeto derivado permanece sob GPLv3 ou posterior; veja `COPYING`.

- Frontend Lemuroid: https://github.com/Swordfish90/Lemuroid
- Repositório de binários de núcleos Libretro do Lemuroid, commit `fee2e824525daa22bcf318f96127fe43fa8a15ad`: https://github.com/Swordfish90/LemuroidCores/tree/fee2e824525daa22bcf318f96127fe43fa8a15ad
- Núcleo PSP PPSSPP: https://github.com/hrydgard/ppsspp
- Núcleo PS1 PCSX-ReARMed: https://github.com/libretro/pcsx_rearmed ; documentação HLE/BIOS: https://docs.libretro.com/library/pcsx_rearmed/

O APK deste build inclui somente os binários nativos PCSX-ReARMed e PPSSPP para `arm64-v8a`, `armeabi-v7a` e `x86`; consulte os avisos e licenças por núcleo no repositório upstream LemuroidCores. Os avisos de terceiros do frontend permanecem na árvore de fontes. Nenhum jogo, BIOS ou firmware proprietário está incluído.
