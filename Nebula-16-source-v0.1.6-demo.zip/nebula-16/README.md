# Nébula 16 — demo autoral para Android (0.1.6-demo)

Interface Android própria, tema escuro com neon azul-bebê e núcleos implementados do zero neste projeto. Não inclui cores, código de interface, BIOS, firmware ou ROMs de terceiros/comerciais.

## O que realmente funciona

- **CHIP-8:** jogável; abre arquivos locais `.ch8`/binários e inclui uma demonstração original.
- **NES/Nintendo Entertainment System:** primeira fatia executável: ROMs **iNES 1.0, mapper 0/NROM**, PRG-ROM de 16 ou 32 KiB e CHR-ROM de 8 KiB ou CHR-RAM. Código 6502 parcial, RAM/ROM básica, escrita/leitura de registradores PPU selecionados, CHR-RAM, nametables com espelhamento vertical/horizontal, paletas e renderização da camada de fundo em 256×240; controlador padrão de 8 botões. Pode executar pequenos homebrews/test ROMs dentro desse subconjunto.
- **Super Nintendo:** permanece protótipo experimental e muito incompleto; não é compatível com jogos em geral.

O catálogo de 50 nomes é apenas um roadmap: somente CHIP-8 e o subconjunto de NES descrito acima são anunciados como executáveis. Todos os demais itens estão indisponíveis, exceto SNES, marcado explicitamente como experimental. Nenhum jogo é fornecido; abra arquivos próprios que você tenha direito de usar.

## Limitações conhecidas

A implementação NES é original e **não é um emulador NES completo nem ciclo-preciso**. Só lê iNES 1.0 mapper 0; rejeita NES 2.0, trainers e outros mappers. Não implementa sprites, scroll/nametable scrolling, NMI/vblank/timing preciso, DMA, áudio/APU, IRQ de mapper, interrupções de CPU completas, todos os opcodes 6502, decodificação de status/todos os modos de leitura da PPU, nem todos os registradores e efeitos de hardware. Jogos comerciais e homebrews podem travar, ficar sem imagem ou não ser compatíveis. O teste automatizado usa um ROM iNES de teste criado no próprio teste, sem ROM externa.

O núcleo SNES é igualmente incompleto: faltam instruções e temporização da CPU, vários modos/camadas da PPU, APU, DMA/HDMA, interrupções e mapeamento completo de cartuchos. A tela CHEATS é informativa; cheats não são aplicados em nenhum núcleo. Controles virtuais e mapeamento de teclas/gamepads Android estão disponíveis para sistemas jogáveis; compatibilidade varia conforme o controle e o modo de entrada que Android expõe.

## Testar e compilar

`gradle --no-daemon :chip8-core:test :nes-core:test :snes-core:test :app:assembleDebug`

O workflow GitHub Actions usa JDK 17, Android SDK API 35 e Gradle 8.10.2. A publicação é uma prévia para teste, não uma versão completa de 50 sistemas.
