package com.raully.nebula16.rom

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Safely imports raw user ROMs or one matching ROM entry from a ZIP archive. */
object RomImport {
    const val MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
    const val MAX_ROM_BYTES = 32 * 1024 * 1024
    private const val MAX_ZIP_ENTRIES = 1_000

    enum class System(val extensions: Set<String>, val rawLimit: Int) {
        CHIP8(setOf("ch8"), 3_584),
        NES(setOf("nes"), MAX_ROM_BYTES),
        SNES(setOf("sfc", "smc"), MAX_ROM_BYTES),
    }

    /** Reads a provider stream with a strict cap, including for unknown-length content URIs. */
    fun readArchive(input: InputStream): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            require(count > 0) { "Não foi possível ler o arquivo selecionado." }
            total += count
            require(total <= MAX_ARCHIVE_BYTES) { "Arquivo grande demais (limite de 64 MiB)." }
            output.write(buffer, 0, count)
        }
        require(total > 0) { "O arquivo selecionado está vazio." }
        return output.toByteArray()
    }

    /** Raw input is preserved; ZIP input must contain exactly one supported file for the chosen system. */
    fun load(bytes: ByteArray, system: System): ByteArray {
        require(bytes.isNotEmpty()) { "O arquivo selecionado está vazio." }
        require(bytes.size <= MAX_ARCHIVE_BYTES) { "Arquivo grande demais (limite de 64 MiB)." }
        if (!hasZipSignature(bytes)) {
            require(bytes.size <= system.rawLimit) { "ROM ${system.name} excede o limite de ${system.rawLimit} bytes." }
            return bytes.copyOf()
        }

        var matches = 0
        var selected: ByteArray? = null
        var entries = 0
        var totalInflated = 0
        try {
            ZipInputStream(bytes.inputStream()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entries++
                    require(entries <= MAX_ZIP_ENTRIES) { "ZIP contém itens demais (limite: $MAX_ZIP_ENTRIES)." }
                    if (!entry.isDirectory && entry.name.substringAfterLast('/').substringAfterLast('\\').substringAfterLast('.', "").lowercase() in system.extensions) {
                        matches++
                        require(matches == 1) { "ZIP contém mais de uma ROM compatível; deixe apenas uma ROM ${system.extensions.joinToString("/")} no arquivo." }
                        selected = readEntry(zip, system.rawLimit)
                        totalInflated += selected!!.size
                    } else {
                        // Drain non-ROM entries without retaining their contents; still cap total inflation.
                        totalInflated += drainEntry(zip, MAX_ARCHIVE_BYTES)
                    }
                    require(totalInflated <= MAX_ARCHIVE_BYTES) { "Conteúdo descompactado do ZIP excede o limite de segurança de 64 MiB." }
                    zip.closeEntry()
                }
            }
        } catch (e: IllegalArgumentException) {
            throw e
        } catch (e: Exception) {
            throw IllegalArgumentException("ZIP inválido ou não compatível: ${e.message ?: "erro ao descompactar"}.", e)
        }
        return selected ?: throw IllegalArgumentException(
            "ZIP sem ROM compatível para ${system.name}. Esperado: ${system.extensions.sorted().joinToString(", ")}.",
        )
    }

    private fun readEntry(input: InputStream, limit: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= limit) { "ROM dentro do ZIP excede o limite de $limit bytes." }
            output.write(buffer, 0, count)
        }
        require(total > 0) { "A ROM dentro do ZIP está vazia." }
        return output.toByteArray()
    }

    private fun drainEntry(input: InputStream, limit: Int): Int {
        val buffer = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= limit) { "Item não-ROM dentro do ZIP excede o limite de segurança." }
        }
        return total
    }

    private fun hasZipSignature(bytes: ByteArray): Boolean =
        bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte() &&
            (bytes[2] == 0x03.toByte() && bytes[3] == 0x04.toByte() ||
                bytes[2] == 0x05.toByte() && bytes[3] == 0x06.toByte() ||
                bytes[2] == 0x07.toByte() && bytes[3] == 0x08.toByte())
}
