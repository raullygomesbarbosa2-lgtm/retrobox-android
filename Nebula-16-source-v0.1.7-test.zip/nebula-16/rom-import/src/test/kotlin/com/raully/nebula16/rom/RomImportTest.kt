package com.raully.nebula16.rom

import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class RomImportTest {
    @Test fun returnsRawChip8NesAndSnesBytesUnchanged() {
        for ((system, data) in listOf(
            RomImport.System.CHIP8 to byteArrayOf(0x60, 0x00),
            RomImport.System.NES to byteArrayOf(0x4e, 0x45, 0x53),
            RomImport.System.SNES to byteArrayOf(0x12, 0x34),
        )) assertContentEquals(data, RomImport.load(data, system))
    }

    @Test fun extractsMatchingNestedRomFromZipAndIgnoresOtherFormats() {
        val rom = byteArrayOf(0x60, 0x00, 0x12, 0x00)
        val archive = zip("notes.txt" to "hello".encodeToByteArray(), "folder/Game.CH8" to rom)
        assertContentEquals(rom, RomImport.load(archive, RomImport.System.CHIP8))
    }

    @Test fun extractsNesAndBothCommonSnesExtensionsCaseInsensitively() {
        val nes = byteArrayOf(0x4e, 0x45, 0x53, 0x1a)
        val sfc = byteArrayOf(1, 2, 3)
        val smc = byteArrayOf(4, 5, 6)
        assertContentEquals(nes, RomImport.load(zip("test.nes" to nes), RomImport.System.NES))
        assertContentEquals(sfc, RomImport.load(zip("test.SFC" to sfc), RomImport.System.SNES))
        assertContentEquals(smc, RomImport.load(zip("nested/game.smc" to smc), RomImport.System.SNES))
    }

    @Test fun rejectsNoMatchAmbiguousRomAndEmptyZip() {
        val noMatch = assertFailsWith<IllegalArgumentException> {
            RomImport.load(zip("game.bin" to byteArrayOf(1)), RomImport.System.NES)
        }
        assertTrue(noMatch.message!!.contains("sem ROM compatível"))
        val ambiguous = assertFailsWith<IllegalArgumentException> {
            RomImport.load(zip("one.nes" to byteArrayOf(1), "two.nes" to byteArrayOf(2)), RomImport.System.NES)
        }
        assertTrue(ambiguous.message!!.contains("mais de uma"))
        assertFailsWith<IllegalArgumentException> { RomImport.load(zip(), RomImport.System.NES) }
    }

    @Test fun rejectsMalformedZipAndOversizedRawOrEmptyFiles() {
        assertFailsWith<IllegalArgumentException> { RomImport.load(byteArrayOf(0x50, 0x4b, 0x03, 0x04), RomImport.System.NES) }
        assertFailsWith<IllegalArgumentException> { RomImport.load(byteArrayOf(), RomImport.System.NES) }
        assertFailsWith<IllegalArgumentException> {
            RomImport.load(ByteArray(3_585), RomImport.System.CHIP8)
        }
        assertEquals(0, RomImport.readArchive(byteArrayOf(1).inputStream()).size - 1)
    }

    private fun zip(vararg files: Pair<String, ByteArray>): ByteArray {
        val output = ByteArrayOutputStream()
        ZipOutputStream(output).use { zip ->
            for ((name, content) in files) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(content)
                zip.closeEntry()
            }
        }
        return output.toByteArray()
    }
}
