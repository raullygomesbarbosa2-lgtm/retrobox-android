package com.raully.nebula16.snes

/** SNES serial controller protocol, button order A, B, X, Y, L, R, Select, Start, U, D, L, R. */
enum class SnesButton { A, B, X, Y, L, R, SELECT, START, UP, DOWN, LEFT, RIGHT }

class SnesController {
    private val buttons = BooleanArray(12)
    private var strobe = false
    private var serialPosition = 0

    @Synchronized fun setButton(button: SnesButton, pressed: Boolean) {
        buttons[button.ordinal] = pressed
    }

    @Synchronized fun writeStrobe(value: Int) {
        val next = (value and 1) != 0
        if (next || strobe) serialPosition = 0
        strobe = next
    }

    /** Read one bit from $4016; after the 12 buttons, an idle 1 is returned. */
    @Synchronized fun readPort(): Int {
        if (strobe) return if (buttons[SnesButton.A.ordinal]) 1 else 0
        if (serialPosition >= buttons.size) return 1
        return if (buttons[serialPosition++]) 1 else 0
    }
}
