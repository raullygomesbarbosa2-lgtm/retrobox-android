package com.raully.nebula16.snes

/** File extensions offered by the SNES-specific picker; no CHIP-8 files are treated as SNES. */
object SnesRomFileTypes {
    private val extensions = setOf("sfc", "smc", "fig")

    fun isSupportedName(name: String): Boolean {
        val extension = name.substringAfterLast('.', missingDelimiterValue = "").lowercase()
        return extension in extensions
    }
}
