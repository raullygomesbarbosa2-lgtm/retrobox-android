package com.raully.nebula16.snes

/**
 * Tiny original LoROM demo generated from hand-assembled 65C816 bytes at runtime.
 * Hold controller A to move the visible block right; hold B to move it left.
 * This is an integration/playability smoke demo, not a commercial game or compatibility test.
 */
object SnesHomebrewDemo {
    fun createRom(): ByteArray {
        val p = Program()
        fun lda(value: Int) { p.emit(0xa9, value) }
        fun ldaAbsolute(address: Int) { p.emit(0xad, address and 0xff, address ushr 8) }
        fun sta(address: Int) { p.emit(0x8d, address and 0xff, address ushr 8) }
        fun setRegister(address: Int, value: Int) { lda(value); sta(address) }

        // Display BG1 in Mode 0. Tile 1 is a solid red 8x8 block; tile 0 stays blank.
        setRegister(0x2100, 0x0f)
        setRegister(0x2107, 0x04) // BG1 map at word $0200
        setRegister(0x212c, 0x01) // BG1 main screen
        setRegister(0x2115, 0x80)
        setRegister(0x2116, 0x08)
        setRegister(0x2117, 0x00)
        repeat(8) {
            setRegister(0x2118, 0xff)
            setRegister(0x2119, 0x00)
        }
        setRegister(0x2121, 0x01)
        setRegister(0x2122, 0x1f); setRegister(0x2122, 0x00)
        setRegister(0x2116, 0x04)
        setRegister(0x2117, 0x03) // map row 8, column 4 (x=32, y=64)
        setRegister(0x2118, 0x01); setRegister(0x2119, 0x00)

        p.label("poll")
        setRegister(0x4016, 0x01)
        setRegister(0x4016, 0x00)
        ldaAbsolute(0x4016)
        p.emit(0x29, 0x01) // AND #$01 — A button
        p.branch(0xd0, "right")
        ldaAbsolute(0x4016)
        p.emit(0x29, 0x01) // next serial bit — B button
        p.branch(0xd0, "left")
        lda(0)
        p.branch(0x80, "applyScroll")
        p.label("right")
        lda(248) // scroll left by 8, moving the visible block right
        p.branch(0x80, "applyScroll")
        p.label("left")
        lda(8) // scroll right by 8, moving the visible block left
        p.label("applyScroll")
        sta(0x210d)
        p.branch(0x80, "poll")

        val rom = ByteArray(0x8000)
        p.finish().copyInto(rom)
        val title = "NEBULA HOME DEMO".toByteArray(Charsets.US_ASCII)
        title.copyInto(rom, 0x7fc0, endIndex = minOf(title.size, 21))
        rom[0x7ffc] = 0x00
        rom[0x7ffd] = 0x80.toByte()
        return rom
    }

    private class Program {
        private val code = mutableListOf<Int>()
        private val labels = mutableMapOf<String, Int>()
        private val branches = mutableListOf<Pair<Int, String>>()

        fun emit(vararg bytes: Int) { bytes.forEach { code += it and 0xff } }
        fun label(name: String) { check(labels.put(name, code.size) == null) { "Duplicate label: $name" } }
        fun branch(opcode: Int, label: String) {
            emit(opcode)
            branches += code.size to label
            emit(0)
        }
        fun finish(): ByteArray {
            for ((operandIndex, label) in branches) {
                val target = labels[label] ?: error("Unknown label: $label")
                val displacement = target - (operandIndex + 1)
                require(displacement in -128..127) { "Branch out of range to $label" }
                code[operandIndex] = displacement and 0xff
            }
            return ByteArray(code.size) { code[it].toByte() }
        }
    }
}
