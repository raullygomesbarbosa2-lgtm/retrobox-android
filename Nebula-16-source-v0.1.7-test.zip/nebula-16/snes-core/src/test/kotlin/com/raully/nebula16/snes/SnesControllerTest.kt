package com.raully.nebula16.snes

import kotlin.test.Test
import kotlin.test.assertEquals

class SnesControllerTest {
    @Test fun serialPortReturnsButtonsInConsoleOrder() {
        val pad = SnesController()
        pad.setButton(SnesButton.A, true)
        pad.setButton(SnesButton.LEFT, true)
        pad.writeStrobe(1)
        assertEquals(1, pad.readPort()) // held A is visible while strobe is high
        pad.writeStrobe(0)
        assertEquals(1, pad.readPort()) // A
        repeat(8) { assertEquals(0, pad.readPort()) } // B,X,Y,L,R,Select,Start,Up
        assertEquals(0, pad.readPort()) // Down
        assertEquals(1, pad.readPort()) // Left
        assertEquals(0, pad.readPort()) // Right
        assertEquals(1, pad.readPort()) // open serial line after twelve buttons
    }
}
