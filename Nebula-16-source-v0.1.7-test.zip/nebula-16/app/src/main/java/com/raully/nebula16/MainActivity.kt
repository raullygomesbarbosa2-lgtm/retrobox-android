package com.raully.nebula16

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.raully.nebula16.chip8.Chip8
import com.raully.nebula16.nes.NesButton
import com.raully.nebula16.nes.NesMachine
import com.raully.nebula16.nes.NesPpu
import com.raully.nebula16.rom.RomImport
import com.raully.nebula16.snes.SnesButton
import com.raully.nebula16.snes.SnesMachine
import com.raully.nebula16.snes.SnesPpu
import kotlin.math.min

/** Nébula 16 development build: original CHIP-8 play mode plus honest SNES core prototype. */
class MainActivity : Activity() {
    private val classicCatalog = listOf(
        "Atari 2600",
        "Atari 5200",
        "Atari 7800",
        "Atari Lynx",
        "Atari Jaguar",
        "Nintendo Entertainment System (NES)",
        "Famicom Disk System",
        "Super Nintendo",
        "Game Boy",
        "Game Boy Color",
        "Game Boy Advance",
        "Virtual Boy",
        "Nintendo 64",
        "Nintendo GameCube",
        "Nintendo DS",
        "Sega SG-1000",
        "Sega Master System",
        "Sega Mega Drive / Genesis",
        "Sega CD / Mega-CD",
        "Sega 32X",
        "Game Gear",
        "Sega Saturn",
        "Dreamcast",
        "PlayStation",
        "PlayStation 2",
        "PlayStation Portable (PSP)",
        "PlayStation Vita",
        "PC Engine / TurboGrafx-16",
        "PC Engine SuperGrafx",
        "PC-FX",
        "Neo Geo AES",
        "Neo Geo MVS",
        "Neo Geo CD",
        "Neo Geo Pocket",
        "Neo Geo Pocket Color",
        "WonderSwan",
        "WonderSwan Color",
        "ColecoVision",
        "Intellivision",
        "Magnavox Odyssey²",
        "Vectrex",
        "Fairchild Channel F",
        "Bally Astrocade",
        "3DO Interactive Multiplayer",
        "Philips CD-i",
        "Amiga CD32",
        "Atari Jaguar CD",
        "Casio Loopy",
        "Bandai Playdia",
        "Sega Pico",
    )

    private val handler = Handler(Looper.getMainLooper())
    private val vm = Chip8()
    private var gameView: PixelView? = null
    private var running = false
    private var lastTick = 0L
    private var timerCredit = 0L
    private var snesMachine: SnesMachine? = null
    private var snesImage: ImageView? = null
    private var snesBitmap: Bitmap? = null
    private var snesRunning = false
    private var nesMachine: NesMachine? = null
    private var nesImage: ImageView? = null
    private var nesBitmap: Bitmap? = null
    private var nesRunning = false
    private lateinit var body: LinearLayout
    private var activeSystem: String? = null
    private var pendingControlAction: String? = null
    private val snesFrame = object : Runnable {
        override fun run() {
            if (!snesRunning) return
            val machine = snesMachine ?: return
            val bitmap = snesBitmap ?: return
            try {
                val pixels = machine.runFrame()
                bitmap.setPixels(pixels, 0, SnesPpu.WIDTH, 0, 0, SnesPpu.WIDTH, SnesPpu.HEIGHT)
                snesImage?.invalidate()
            } catch (e: Exception) {
                stopSnes()
                Toast.makeText(this@MainActivity, e.message ?: "A ROM parou durante a execução.", Toast.LENGTH_LONG).show()
                return
            }
            handler.postDelayed(this, 16)
        }
    }
    private val nesFrame = object : Runnable {
        override fun run() {
            if (!nesRunning) return
            val machine = nesMachine ?: return
            val bitmap = nesBitmap ?: return
            try {
                val pixels = machine.runFrame()
                bitmap.setPixels(pixels, 0, NesPpu.WIDTH, 0, 0, NesPpu.WIDTH, NesPpu.HEIGHT)
                nesImage?.invalidate()
            } catch (e: Exception) {
                stopNes()
                Toast.makeText(this@MainActivity, e.message ?: "A ROM NES parou durante a execução.", Toast.LENGTH_LONG).show()
                return
            }
            handler.postDelayed(this, 16)
        }
    }
    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            repeat(10) { try { vm.cycle() } catch (e: Exception) { stopGame(); Toast.makeText(this@MainActivity, e.message ?: "Erro na ROM", Toast.LENGTH_LONG).show(); return } }
            val now = System.nanoTime()
            if (lastTick == 0L) lastTick = now
            timerCredit += now - lastTick
            lastTick = now
            while (timerCredit >= 16_666_667L) { vm.tickTimers(); timerCredit -= 16_666_667L }
            gameView?.invalidate()
            handler.postDelayed(this, 16)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); showHome() }

    private fun showHome(note: String? = null) {
        running = false; handler.removeCallbacks(frame); gameView = null; activeSystem = null; pendingControlAction = null
        stopSnes(); stopNes()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.statusBarColor = Color.rgb(9, 13, 25); window.navigationBarColor = Color.rgb(9, 13, 25)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(9, 13, 25)) }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(32), dp(22), dp(28)); gravity = Gravity.CENTER_HORIZONTAL }
        scroll.addView(body); setContentView(scroll)
        body.addView(label("NÉBULA 16", 30f, Color.WHITE, true))
        body.addView(label("DEMO • neon azul-bebê • núcleos autorais", 15f, 0xFFBAC6DF.toInt()).apply { setPadding(0, dp(8), 0, dp(16)) })
        body.addView(section("O QUE FUNCIONA NESTA DEMO", 0xFF8EEBFF.toInt()))
        body.addView(label("CHIP-8 · JOGÁVEL\nNES · SUPORTE INICIAL: iNES mapper 0, NROM\nSuper Nintendo · EXPERIMENTAL, compatibilidade muito limitada\nOs outros sistemas ainda não estão disponíveis.", 14f, 0xFFD6E8F5.toInt()).apply { setPadding(dp(8), dp(4), dp(8), dp(12)) })
        button("JOGAR DEMO CHIP-8", 0xFF8EEBFF.toInt()) { startChip8(Chip8.demo) }
        button("ABRIR ROM CHIP-8 · .ch8 / ZIP", 0xFF233451.toInt()) { pick(1) }
        button("ABRIR ROM NES · .nes / ZIP NROM", 0xFF233451.toInt()) { pick(3) }
        button("ABRIR ROM SNES · .sfc/.smc / ZIP · EXPERIMENTAL", 0xFF233451.toInt()) { pick(2) }
        body.addView(section("CATÁLOGO CLÁSSICO · 50 SISTEMAS", 0xFF8EEBFF.toInt()))
        body.addView(label(classicCatalog.joinToString("\n") { "• $it  —  PLANEJADO / INDISPONÍVEL" }.replace("• Nintendo Entertainment System (NES)  —  PLANEJADO / INDISPONÍVEL", "• Nintendo Entertainment System (NES)  —  SUPORTE INICIAL / NROM").replace("• Super Nintendo  —  PLANEJADO / INDISPONÍVEL", "• Super Nintendo  —  EXPERIMENTAL / NÃO GARANTIDO"), 12f, 0xFFD6E8F5.toInt()).apply { setPadding(dp(8), dp(4), dp(8), dp(16)) })
        val status = label(note ?: "O catálogo não significa que esses 50 sistemas já rodam. CHIP-8 é jogável; NES aceita ROMs NROM, mas ainda tem compatibilidade restrita; SNES segue experimental.", 14f, 0xFFE2C98A.toInt())
        status.setPadding(dp(13), dp(18), dp(13), dp(6)); body.addView(status)
        body.addView(label("Feito sem núcleos de emulação de terceiros. Não acompanha jogos, ROMs comerciais, BIOS ou firmware.", 12f, 0xFF9BA9C1.toInt()).apply { setPadding(dp(12), dp(12), dp(12), 0) })
    }

    private fun pick(kind: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivityForResult(intent, kind) } catch (_: Exception) { Toast.makeText(this, "Não consegui abrir o seletor de arquivos.", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Legacy result API supports the project's no-dependency Android UI")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        try {
            val bytes = contentResolver.openInputStream(data.data!!)?.use { RomImport.readArchive(it) } ?: error("Não consegui ler o arquivo selecionado.")
            when (requestCode) {
                1 -> startChip8(RomImport.load(bytes, RomImport.System.CHIP8))
                2 -> startSnes(RomImport.load(bytes, RomImport.System.SNES))
                3 -> startNes(RomImport.load(bytes, RomImport.System.NES))
                else -> error("Sistema selecionado desconhecido.")
            }
        } catch (e: Exception) { Toast.makeText(this, e.message ?: "Arquivo inválido.", Toast.LENGTH_LONG).show() }
    }

    private fun startSnes(bytes: ByteArray) {
        val machine = try { SnesMachine(bytes) } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "ROM SNES inválida.", Toast.LENGTH_LONG).show(); return
        }
        stopSnes()
        activeSystem = "SNES"
        running = false; handler.removeCallbacks(frame)
        snesMachine = machine
        snesBitmap = Bitmap.createBitmap(SnesPpu.WIDTH, SnesPpu.HEIGHT, Bitmap.Config.ARGB_8888)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        root.addView(gameToolbar("SNES"), LinearLayout.LayoutParams(-1, dp(48)))

        snesImage = ImageView(this).apply {
            setBackgroundColor(Color.BLACK)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageBitmap(snesBitmap)
            contentDescription = "Imagem do jogo SNES experimental"
        }
        root.addView(snesImage, LinearLayout.LayoutParams(-1, 0, 1f))
        val padRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(2), dp(8), dp(8)) }
        padRow.addView(snesDpad(), LinearLayout.LayoutParams(0, dp(122), 1.1f))
        val faceGroup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val faceTop = LinearLayout(this).apply { gravity = Gravity.CENTER }
        faceTop.addView(snesKeyButton("X", SnesButton.X)); faceTop.addView(snesKeyButton("Y", SnesButton.Y))
        val faceBottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        faceBottom.addView(snesKeyButton("B", SnesButton.B)); faceBottom.addView(snesKeyButton("A", SnesButton.A))
        faceGroup.addView(faceTop); faceGroup.addView(faceBottom)
        padRow.addView(faceGroup, LinearLayout.LayoutParams(0, dp(122), 1.2f))
        val utility = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val utilityTop = LinearLayout(this).apply { gravity = Gravity.CENTER }
        utilityTop.addView(snesKeyButton("L", SnesButton.L)); utilityTop.addView(snesKeyButton("R", SnesButton.R))
        val utilityBottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        utilityBottom.addView(snesKeyButton("SEL", SnesButton.SELECT)); utilityBottom.addView(snesKeyButton("START", SnesButton.START))
        utility.addView(utilityTop); utility.addView(utilityBottom)
        padRow.addView(utility, LinearLayout.LayoutParams(0, dp(122), 1.2f))
        root.addView(padRow, LinearLayout.LayoutParams(-1, dp(130)))
        setContentView(root)
        snesRunning = true
        handler.post(snesFrame)
    }

    private fun stopSnes() {
        snesRunning = false
        handler.removeCallbacks(snesFrame)
        snesMachine = null; snesImage = null; snesBitmap = null
    }

    private fun snesDpad(): View {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        grid.addView(snesKeyButton("▲", SnesButton.UP))
        val middle = LinearLayout(this).apply { gravity = Gravity.CENTER }
        middle.addView(snesKeyButton("◀", SnesButton.LEFT))
        middle.addView(snesKeyButton("▼", SnesButton.DOWN))
        middle.addView(snesKeyButton("▶", SnesButton.RIGHT))
        grid.addView(middle)
        return grid
    }

    private fun snesKeyButton(text: String, key: SnesButton): Button = Button(this).apply {
        this.text = text; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(0xFF263550.toInt())
        setOnTouchListener { _, event ->
            val down = event.actionMasked == MotionEvent.ACTION_DOWN || event.actionMasked == MotionEvent.ACTION_POINTER_DOWN
            val up = event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_POINTER_UP || event.actionMasked == MotionEvent.ACTION_CANCEL
            if (down || up) snesMachine?.setButton(key, down)
            true
        }
    }

    private fun startNes(rom: ByteArray) {
        val machine = try { NesMachine(rom) } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "ROM NES inválida ou não suportada.", Toast.LENGTH_LONG).show(); return
        }
        stopSnes(); stopNes(); stopGame()
        activeSystem = "NES"
        nesMachine = machine
        nesBitmap = Bitmap.createBitmap(NesPpu.WIDTH, NesPpu.HEIGHT, Bitmap.Config.ARGB_8888)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        root.addView(gameToolbar("NES"), LinearLayout.LayoutParams(-1, dp(48)))
        nesImage = ImageView(this).apply {
            setBackgroundColor(Color.BLACK); scaleType = ImageView.ScaleType.FIT_CENTER
            setImageBitmap(nesBitmap); contentDescription = "Imagem do jogo NES"
        }
        root.addView(nesImage, LinearLayout.LayoutParams(-1, 0, 1f))
        val padRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(2), dp(8), dp(8)) }
        val dpad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        dpad.addView(nesKeyButton("▲", NesButton.UP))
        val mid = LinearLayout(this).apply { gravity = Gravity.CENTER }
        mid.addView(nesKeyButton("◀", NesButton.LEFT)); mid.addView(nesKeyButton("▼", NesButton.DOWN)); mid.addView(nesKeyButton("▶", NesButton.RIGHT))
        dpad.addView(mid)
        padRow.addView(dpad, LinearLayout.LayoutParams(0, dp(122), 1.1f))
        val face = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val faceTop = LinearLayout(this).apply { gravity = Gravity.CENTER }
        faceTop.addView(nesKeyButton("SELECT", NesButton.SELECT)); faceTop.addView(nesKeyButton("START", NesButton.START))
        val faceBottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        faceBottom.addView(nesKeyButton("B", NesButton.B)); faceBottom.addView(nesKeyButton("A", NesButton.A))
        face.addView(faceTop); face.addView(faceBottom)
        padRow.addView(face, LinearLayout.LayoutParams(0, dp(122), 1.2f))
        root.addView(padRow, LinearLayout.LayoutParams(-1, dp(130)))
        setContentView(root); nesRunning = true; handler.post(nesFrame)
    }

    private fun stopNes() {
        nesRunning = false; handler.removeCallbacks(nesFrame)
        nesMachine = null; nesImage = null; nesBitmap = null
    }

    private fun nesKeyButton(text: String, key: NesButton): Button = Button(this).apply {
        this.text = text; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(0xFF263550.toInt())
        setOnTouchListener { _, event ->
            val down = event.actionMasked == MotionEvent.ACTION_DOWN || event.actionMasked == MotionEvent.ACTION_POINTER_DOWN
            val up = event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_POINTER_UP || event.actionMasked == MotionEvent.ACTION_CANCEL
            if (down || up) nesMachine?.setButton(key, down)
            true
        }
    }

    private fun startChip8(rom: ByteArray) {
        try { vm.load(rom) } catch (e: Exception) { Toast.makeText(this, e.message ?: "ROM CHIP-8 inválida.", Toast.LENGTH_LONG).show(); return }
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        activeSystem = "CHIP8"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK) }
        root.addView(gameToolbar("CHIP8"), LinearLayout.LayoutParams(-1, dp(48)))
        gameView = PixelView().also { root.addView(it, LinearLayout.LayoutParams(-1, 0, 1f)) }
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(6), dp(4), dp(6), dp(8)) }
        controls.addView(directionPad(), LinearLayout.LayoutParams(0, dp(130), 1.3f))
        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(keyButton("A", 5)); row.addView(keyButton("B", 13))
        actions.addView(row)
        controls.addView(actions, LinearLayout.LayoutParams(0, dp(130), 1f))
        root.addView(controls, LinearLayout.LayoutParams(-1, dp(145)))
        setContentView(root); running = true; lastTick = 0; timerCredit = 0; handler.post(frame)
    }

    private fun directionPad(): View {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        grid.addView(keyButton("▲", 2))
        val middle = LinearLayout(this).apply { gravity = Gravity.CENTER }
        middle.addView(keyButton("◀", 4)); middle.addView(keyButton("▼", 8)); middle.addView(keyButton("▶", 6))
        grid.addView(middle); return grid
    }

    private fun keyButton(text: String, key: Int): Button = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); setBackgroundColor(0xFF263550.toInt()); isAllCaps = false
        setOnTouchListener { _, event -> when (event.actionMasked) { MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> vm.setKey(key, true); MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_UP -> vm.setKey(key, false) }; true }
    }

    private fun stopGame() { running = false; handler.removeCallbacks(frame) }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (event?.repeatCount == 0 && pendingControlAction != null) {
            val action = pendingControlAction!!
            getSharedPreferences("controller", MODE_PRIVATE).edit().putInt("${activeSystem}_$action", keyCode).apply()
            pendingControlAction = null
            Toast.makeText(this, "Botão mapeado!", Toast.LENGTH_SHORT).show()
            return true
        }
        if (activeSystem == "NES") {
            val action = actionForKey("NES", keyCode)
            val button = action?.let { runCatching { NesButton.valueOf(it) }.getOrNull() }
            if (button != null) { nesMachine?.setButton(button, true); return true }
        }
        if (activeSystem == "SNES") {
            val action = actionForKey("SNES", keyCode)
            val button = action?.let { runCatching { SnesButton.valueOf(it) }.getOrNull() }
            if (button != null) { snesMachine?.setButton(button, true); return true }
        }
        if (activeSystem == "CHIP8") {
            val action = actionForKey("CHIP8", keyCode)
            val key = chip8KeyForAction(action)
            if (key != null) { vm.setKey(key, true); return true }
        }
        return super.onKeyDown(keyCode, event)
    }
    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (activeSystem == "NES") {
            val action = actionForKey("NES", keyCode)
            val button = action?.let { runCatching { NesButton.valueOf(it) }.getOrNull() }
            if (button != null) { nesMachine?.setButton(button, false); return true }
        }
        if (activeSystem == "SNES") {
            val action = actionForKey("SNES", keyCode)
            val button = action?.let { runCatching { SnesButton.valueOf(it) }.getOrNull() }
            if (button != null) { snesMachine?.setButton(button, false); return true }
        }
        if (activeSystem == "CHIP8") {
            val action = actionForKey("CHIP8", keyCode)
            val key = chip8KeyForAction(action)
            if (key != null) { vm.setKey(key, false); return true }
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (activeSystem == null || event.action != MotionEvent.ACTION_MOVE ||
            (event.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) return super.onGenericMotionEvent(event)
        val x = event.getAxisValue(MotionEvent.AXIS_X).takeIf { kotlin.math.abs(it) > 0.15f }
            ?: event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val y = event.getAxisValue(MotionEvent.AXIS_Y).takeIf { kotlin.math.abs(it) > 0.15f }
            ?: event.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val system = activeSystem!!
        setActionPressed(system, "LEFT", x < -0.5f)
        setActionPressed(system, "RIGHT", x > 0.5f)
        setActionPressed(system, "UP", y < -0.5f)
        setActionPressed(system, "DOWN", y > 0.5f)
        return true
    }

    private fun setActionPressed(system: String, action: String, pressed: Boolean) {
        if (system == "NES") runCatching { NesButton.valueOf(action) }.getOrNull()?.let { nesMachine?.setButton(it, pressed) }
        else if (system == "SNES") runCatching { SnesButton.valueOf(action) }.getOrNull()?.let { snesMachine?.setButton(it, pressed) }
        else chip8KeyForAction(action)?.let { vm.setKey(it, pressed) }
    }

    private fun actionForKey(system: String, code: Int): String? {
        val actions = when (system) { "SNES" -> listOf("UP", "DOWN", "LEFT", "RIGHT", "A", "B", "X", "Y", "L", "R", "START", "SELECT"); "NES" -> listOf("UP", "DOWN", "LEFT", "RIGHT", "A", "B", "START", "SELECT"); else -> listOf("UP", "DOWN", "LEFT", "RIGHT", "A", "B") }
        val prefs = getSharedPreferences("controller", MODE_PRIVATE)
        actions.firstOrNull { prefs.getInt("${system}_$it", defaultKey(system, it)) == code }?.let { return it }
        return null
    }

    private fun defaultKey(system: String, action: String): Int = if (system == "NES") when (action) {
        "UP" -> KeyEvent.KEYCODE_DPAD_UP; "DOWN" -> KeyEvent.KEYCODE_DPAD_DOWN
        "LEFT" -> KeyEvent.KEYCODE_DPAD_LEFT; "RIGHT" -> KeyEvent.KEYCODE_DPAD_RIGHT
        "A" -> KeyEvent.KEYCODE_BUTTON_A; "B" -> KeyEvent.KEYCODE_BUTTON_B
        "START" -> KeyEvent.KEYCODE_BUTTON_START; "SELECT" -> KeyEvent.KEYCODE_BUTTON_SELECT
        else -> -1
    } else if (system == "SNES") when (action) {
        "UP" -> KeyEvent.KEYCODE_DPAD_UP; "DOWN" -> KeyEvent.KEYCODE_DPAD_DOWN
        "LEFT" -> KeyEvent.KEYCODE_DPAD_LEFT; "RIGHT" -> KeyEvent.KEYCODE_DPAD_RIGHT
        "A" -> KeyEvent.KEYCODE_BUTTON_B; "B" -> KeyEvent.KEYCODE_BUTTON_A
        "X" -> KeyEvent.KEYCODE_BUTTON_Y; "Y" -> KeyEvent.KEYCODE_BUTTON_X
        "L" -> KeyEvent.KEYCODE_BUTTON_L1; "R" -> KeyEvent.KEYCODE_BUTTON_R1
        "START" -> KeyEvent.KEYCODE_BUTTON_START; "SELECT" -> KeyEvent.KEYCODE_BUTTON_SELECT
        else -> -1
    } else when (action) {
        "UP" -> KeyEvent.KEYCODE_DPAD_UP; "DOWN" -> KeyEvent.KEYCODE_DPAD_DOWN
        "LEFT" -> KeyEvent.KEYCODE_DPAD_LEFT; "RIGHT" -> KeyEvent.KEYCODE_DPAD_RIGHT
        "A" -> KeyEvent.KEYCODE_BUTTON_A; "B" -> KeyEvent.KEYCODE_BUTTON_B
        else -> -1
    }

    private fun chip8KeyForAction(action: String?): Int? = when (action) {
        "UP" -> 2; "DOWN" -> 8; "LEFT" -> 4; "RIGHT" -> 6; "A" -> 5; "B" -> 13; else -> null
    }

    private fun gameToolbar(system: String): View {
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(3), dp(2), dp(3), dp(2)); setBackgroundColor(0xFF080F1D.toInt()) }
        listOf("VOLTAR", "ROM", "CHEATS", "CONTROLE").forEach { title ->
            val b = Button(this).apply {
                text = title; textSize = 9f; isAllCaps = false; setTextColor(0xFFB8F3FF.toInt()); setBackgroundColor(0xFF172A40.toInt())
                setOnClickListener {
                    when (title) {
                        "VOLTAR" -> showHome()
                        "ROM" -> pick(when (system) { "SNES" -> 2; "NES" -> 3; else -> 1 })
                        "CHEATS" -> showCheats(system)
                        "CONTROLE" -> showControlSettings(system)
                    }
                }
            }
            bar.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(2); marginEnd = dp(2) })
        }
        return bar
    }

    private fun showCheats(system: String) {
        val message = when (system) {
            "SNES" -> "O botão está pronto, mas códigos de cheat ainda não são aplicados pelo núcleo SNES experimental."
            "NES" -> "O núcleo NES inicial ainda não aplica códigos de cheat."
            else -> "O núcleo CHIP-8 desta demo ainda não tem suporte para códigos de cheat. O menu fica aqui para a próxima etapa."
        }
        AlertDialog.Builder(this).setTitle("CHEATS · $system")
            .setMessage(message).setPositiveButton("OK", null).show()
    }

    private fun showControlSettings(system: String) {
        val actions = when (system) { "SNES" -> listOf("UP", "DOWN", "LEFT", "RIGHT", "A", "B", "X", "Y", "L", "R", "START", "SELECT"); "NES" -> listOf("UP", "DOWN", "LEFT", "RIGHT", "A", "B", "START", "SELECT"); else -> listOf("UP", "DOWN", "LEFT", "RIGHT", "A", "B") }
        val names = mapOf("UP" to "Cima", "DOWN" to "Baixo", "LEFT" to "Esquerda", "RIGHT" to "Direita", "A" to "A", "B" to "B", "X" to "X", "Y" to "Y", "L" to "L", "R" to "R", "START" to "Start", "SELECT" to "Select")
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        val dialog = AlertDialog.Builder(this).setTitle("CONTROLE BLUETOOTH · $system")
            .setMessage("Toque em uma ação e aperte o botão correspondente no controle pareado. Compatível com controles que o Android reconhece como gamepad.")
            .setView(content).setNegativeButton("FECHAR", null).create()
        actions.forEach { action ->
            val prefs = getSharedPreferences("controller", MODE_PRIVATE)
            val saved = prefs.getInt("${system}_$action", defaultKey(system, action))
            val button = Button(this).apply {
                text = "${names[action]} · ${keyLabel(saved)}"; isAllCaps = false
                setOnClickListener {
                    pendingControlAction = action
                    Toast.makeText(this@MainActivity, "Aperte ${names[action]} no controle Bluetooth", Toast.LENGTH_LONG).show()
                    dialog.dismiss()
                }
            }
            content.addView(button, LinearLayout.LayoutParams(-1, dp(46)))
        }
        dialog.show()
    }

    private fun keyLabel(code: Int): String = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> "↑"; KeyEvent.KEYCODE_DPAD_DOWN -> "↓"
        KeyEvent.KEYCODE_DPAD_LEFT -> "←"; KeyEvent.KEYCODE_DPAD_RIGHT -> "→"
        KeyEvent.KEYCODE_BUTTON_A -> "A do controle"; KeyEvent.KEYCODE_BUTTON_B -> "B do controle"
        KeyEvent.KEYCODE_BUTTON_X -> "X do controle"; KeyEvent.KEYCODE_BUTTON_Y -> "Y do controle"
        KeyEvent.KEYCODE_BUTTON_L1 -> "L1"; KeyEvent.KEYCODE_BUTTON_R1 -> "R1"
        KeyEvent.KEYCODE_BUTTON_START -> "Start"; KeyEvent.KEYCODE_BUTTON_SELECT -> "Select"
        else -> if (code < 0) "não configurado" else "tecla $code"
    }

    private fun section(text: String, color: Int) = label(text, 13f, color, true).apply { setPadding(0, dp(2), 0, dp(4)) }

    private inner class PixelView : View(this@MainActivity) {
        private val paint = Paint().apply { color = 0xFF8EEBFF.toInt(); style = Paint.Style.FILL }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); canvas.drawColor(Color.BLACK)
            val scale = min(width.toFloat() / 64, height.toFloat() / 32); val left = (width - 64 * scale) / 2; val top = (height - 32 * scale) / 2
            val px = vm.screen()
            for (y in 0 until 32) for (x in 0 until 64) if (px[y * 64 + x]) canvas.drawRect(left + x * scale, top + y * scale, left + (x + 1) * scale + .5f, top + (y + 1) * scale + .5f, paint)
        }
    }

    private fun button(text: String, color: Int, action: () -> Unit) { body.addView(Button(this).apply { this.text = text; setTextColor(if (color == 0xFF8EEBFF.toInt()) Color.BLACK else Color.WHITE); setBackgroundColor(color); setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(9) }) }
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER; if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
