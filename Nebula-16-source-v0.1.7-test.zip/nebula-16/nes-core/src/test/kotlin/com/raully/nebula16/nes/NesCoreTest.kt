package com.raully.nebula16.nes

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotEquals

class NesCoreTest {
    @Test fun mapperZeroChrRamRomExecutesAndProducesFramePixels() {
        val program = mutableListOf<Int>()
        fun lda(v: Int) { program += listOf(0xa9, v) }
        fun sta(address: Int) { program += listOf(0x8d, address and 0xff, address ushr 8) }
        fun ppuWrite(address: Int, value: Int) {
            lda(address ushr 8); sta(0x2006)
            lda(address and 0xff); sta(0x2006)
            lda(value); sta(0x2007)
        }
        // Enable background; set backdrop and first background color.
        lda(0); sta(0x2000)
        lda(0x0a); sta(0x2001)
        ppuWrite(0x3f00, 0x0f)
        ppuWrite(0x3f01, 0x21)
        // CHR-RAM tile zero: low bitplane fully set, high plane clear.
        for (row in 0 until 8) ppuWrite(row, 0x80)
        for (row in 8 until 16) ppuWrite(row, 0)
        // Stop in an intentional loop after the writes.
        val loop = 0x8000 + program.size
        program += listOf(0x4c, loop and 0xff, loop ushr 8)
        val rom = ByteArray(16 + 16_384 + 8_192)
        rom[0] = 0x4e; rom[1] = 0x45; rom[2] = 0x53; rom[3] = 0x1a
        rom[4] = 1; rom[5] = 0
        program.forEachIndexed { index, value -> rom[16 + index] = value.toByte() }
        val vector = 16 + 0x3ffc
        rom[vector] = 0x00; rom[vector + 1] = 0x80.toByte()
        val machine = NesMachine(rom)
        val frame = machine.runFrame()
        assertEquals(256 * 240, frame.size)
        assertNotEquals(frame[0], frame[1], "executed CHR-RAM/PPU writes should render the bitplane pattern")
        assertNotEquals(frame[8 * 256 + 8], frame[8 * 256 + 9], "background pixels should be rendered from tile data")
    }

    @Test fun rejectsUnsupportedMapperAndTruncatedRom() {
        val badMapper = ByteArray(16 + 16_384).apply {
            this[0] = 0x4e; this[1] = 0x45; this[2] = 0x53; this[3] = 0x1a
            this[4] = 1; this[6] = 0x10
        }
        assertFailsWith<IllegalArgumentException> { NesCartridge.parse(badMapper) }
        assertFailsWith<IllegalArgumentException> { NesCartridge.parse(byteArrayOf(0x4e, 0x45)) }
    }
}
