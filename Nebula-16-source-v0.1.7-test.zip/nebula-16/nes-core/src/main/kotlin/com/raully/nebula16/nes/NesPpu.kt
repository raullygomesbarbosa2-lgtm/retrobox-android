package com.raully.nebula16.nes

/** Background-only 2C02 renderer for NROM test/homebrew programs. */
class NesPpu(private val cart: NesCartridge) {
    companion object { const val WIDTH = 256; const val HEIGHT = 240 }
    private val nametables = ByteArray(4096)
    private val paletteRam = ByteArray(32)
    private var address = 0
    private var addressHighNext = true
    private var readBuffer = 0
    private var control = 0
    private var mask = 0
    private val universalPalette = intArrayOf(
        0xff666666.toInt(),0xff002a88.toInt(),0xff1412a7.toInt(),0xff3b00a4.toInt(),0xff5c007e.toInt(),0xff6e0040.toInt(),0xff6c0600.toInt(),0xff561d00.toInt(),
        0xff333500.toInt(),0xff0b4800.toInt(),0xff005200.toInt(),0xff004f08.toInt(),0xff00404d.toInt(),0xff000000.toInt(),0xff000000.toInt(),0xff000000.toInt(),
        0xffadadad.toInt(),0xff155fd9.toInt(),0xff4240ff.toInt(),0xff7527fe.toInt(),0xffa01acc.toInt(),0xffb71e7b.toInt(),0xffb53120.toInt(),0xff994e00.toInt(),
        0xff6b6d00.toInt(),0xff388700.toInt(),0xff0c9300.toInt(),0xff008f32.toInt(),0xff007c8d.toInt(),0xff000000.toInt(),0xff000000.toInt(),0xff000000.toInt(),
        0xfffffeff.toInt(),0xff64b0ff.toInt(),0xff9290ff.toInt(),0xffc676ff.toInt(),0xfff36aff.toInt(),0xfffe6ecc.toInt(),0xffff8170.toInt(),0xffe7a52e.toInt(),
        0xffc3ca00.toInt(),0xff87df00.toInt(),0xff48f14a.toInt(),0xff38e69b.toInt(),0xff3ecedb.toInt(),0xff4e4e4e.toInt(),0xff000000.toInt(),0xff000000.toInt(),
        0xfffffeff.toInt(),0xffc0dfff.toInt(),0xffd3d2ff.toInt(),0xffe8c8ff.toInt(),0xfffac2ff.toInt(),0xfffec4ea.toInt(),0xfffeccc5.toInt(),0xfff7d8a5.toInt(),
        0xffe4e594.toInt(),0xffcfef96.toInt(),0xffbdf4ab.toInt(),0xffb3f3cc.toInt(),0xffb5ebf2.toInt(),0xffb8b8b8.toInt(),0xff000000.toInt(),0xff000000.toInt()
    )
    fun cpuReadRegister(register: Int): Int = when (register and 7) {
        2 -> 0 // Status flags are intentionally not modeled in this first slice.
        7 -> { val v = readBuffer; readBuffer = ppuRead(address); incrementAddress(); v }
        else -> 0
    }
    fun cpuWriteRegister(register: Int, value: Int) {
        val v = value and 0xff
        when (register and 7) {
            0 -> control = v
            1 -> mask = v
            5 -> addressHighNext = !addressHighNext
            6 -> { address = if (addressHighNext) ((v and 0x3f) shl 8) or (address and 0xff) else (address and 0xff00) or v; addressHighNext = !addressHighNext }
            7 -> { ppuWrite(address, v); incrementAddress() }
        }
    }
    private fun incrementAddress() { address = (address + if (control and 4 != 0) 32 else 1) and 0x3fff }
    private fun ppuRead(raw: Int): Int {
        val a = raw and 0x3fff
        return when {
            a < 0x2000 -> cart.chr[a] .toInt() and 0xff
            a < 0x3f00 -> nametables[nametableIndex(a)].toInt() and 0xff
            else -> paletteRam[paletteIndex(a)].toInt() and 0x3f
        }
    }
    private fun ppuWrite(raw: Int, value: Int) {
        val a = raw and 0x3fff
        when {
            a < 0x2000 -> if (cart.chrIsRam) cart.chr[a] = value.toByte()
            a < 0x3f00 -> nametables[nametableIndex(a)] = value.toByte()
            else -> paletteRam[paletteIndex(a)] = (value and 0x3f).toByte()
        }
    }
    private fun nametableIndex(a: Int): Int {
        val offset = (a - 0x2000) and 0x0fff
        val table = offset / 0x400
        val within = offset and 0x3ff
        val physical = if (cart.verticalMirroring) table and 1 else table ushr 1
        return physical * 0x400 + within
    }
    private fun paletteIndex(a: Int): Int {
        var p = (a - 0x3f00) and 0x1f
        if (p == 0x10 || p == 0x14 || p == 0x18 || p == 0x1c) p -= 0x10
        return p
    }
    fun renderFrame(): IntArray {
        val pixels = IntArray(WIDTH * HEIGHT)
        val bgTable = if (control and 0x10 != 0) 0x1000 else 0
        val backdrop = universalPalette[paletteRam[0].toInt() and 0x3f]
        for (y in 0 until HEIGHT) for (x in 0 until WIDTH) {
            var color = backdrop
            if (mask and 0x08 != 0 && (x >= 8 || mask and 0x02 != 0)) {
                val tileX = x ushr 3; val tileY = y ushr 3
                val nt = (control and 3) * 0x400
                val tile = nametables[nametableIndex(0x2000 + nt + tileY * 32 + tileX)].toInt() and 0xff
                val row = y and 7; val bit = 7 - (x and 7)
                val lo = cart.chr[bgTable + tile * 16 + row].toInt() and 0xff
                val hi = cart.chr[bgTable + tile * 16 + row + 8].toInt() and 0xff
                val pixel = ((lo ushr bit) and 1) or (((hi ushr bit) and 1) shl 1)
                if (pixel != 0) {
                    val attr = nametables[nametableIndex(0x23c0 + nt + (tileY ushr 2) * 8 + (tileX ushr 2))].toInt() and 0xff
                    val shift = ((tileY and 2) shl 1) or (tileX and 2)
                    val palette = (attr ushr shift) and 3
                    val pal = paletteRam[palette * 4 + pixel].toInt() and 0x3f
                    color = universalPalette[pal]
                }
            }
            pixels[y * WIDTH + x] = color
        }
        return pixels
    }
}
