package com.raully.nebula16.nes

/** iNES 1.0 cartridge reader for the original Nébula mapper-0 core. */
class NesCartridge private constructor(
    val prgRom: ByteArray,
    val chr: ByteArray,
    val chrIsRam: Boolean,
    val verticalMirroring: Boolean,
) {
    companion object {
        fun parse(bytes: ByteArray): NesCartridge {
            require(bytes.size >= 16 && bytes[0] == 0x4e.toByte() && bytes[1] == 0x45.toByte() && bytes[2] == 0x53.toByte() && bytes[3] == 0x1a.toByte()) { "Arquivo não é uma ROM iNES válida." }
            val flags6 = bytes[6].toInt() and 0xff
            val flags7 = bytes[7].toInt() and 0xff
            require(flags7 and 0x0c != 0x08) { "Formato NES 2.0 ainda não é compatível." }
            require(flags6 and 0x04 == 0) { "ROM com trainer não é compatível nesta versão." }
            val mapper = (flags6 ushr 4) or (flags7 and 0xf0)
            require(mapper == 0) { "Só há suporte ao mapper 0 (NROM) nesta versão." }
            val prgLength = (bytes[4].toInt() and 0xff) * 16_384
            val chrLength = (bytes[5].toInt() and 0xff) * 8_192
            require(prgLength == 16_384 || prgLength == 32_768) { "Mapper 0 exige 16 ou 32 KiB de PRG-ROM." }
            require(bytes.size >= 16 + prgLength + chrLength) { "Arquivo iNES truncado." }
            require(chrLength == 0 || chrLength == 8_192) { "Mapper 0 exige 8 KiB de CHR-ROM ou CHR-RAM." }
            val prg = bytes.copyOfRange(16, 16 + prgLength)
            val chrRam = chrLength == 0
            val chr = if (chrRam) ByteArray(8_192) else bytes.copyOfRange(16 + prgLength, 16 + prgLength + chrLength)
            return NesCartridge(prg, chr, chrRam, flags6 and 1 != 0)
        }
    }
}
