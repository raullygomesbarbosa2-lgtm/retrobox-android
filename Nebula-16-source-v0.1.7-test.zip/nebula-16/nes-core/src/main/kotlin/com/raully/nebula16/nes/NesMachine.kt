package com.raully.nebula16.nes

enum class NesButton { A, B, SELECT, START, UP, DOWN, LEFT, RIGHT }

/** Original, deliberately small NROM/NES execution slice. This is not a cycle-accurate NES. */
class NesMachine(rom: ByteArray) {
    private val cart = NesCartridge.parse(rom)
    val ppu = NesPpu(cart)
    private val cpu = Cpu6502(::read, ::write)
    private val ram = ByteArray(2048)
    private val buttons = BooleanArray(8)
    private var strobe = false
    private var controllerIndex = 0
    init { cpu.reset() }
    fun setButton(button: NesButton, pressed: Boolean) { buttons[button.ordinal] = pressed }
    fun runFrame(): IntArray {
        var cycles = 0
        while (cycles < 29_780) cycles += cpu.step()
        return ppu.renderFrame()
    }
    private fun read(raw: Int): Int {
        val a = raw and 0xffff
        return when {
            a < 0x2000 -> ram[a and 0x7ff].toInt() and 0xff
            a < 0x4000 -> ppu.cpuReadRegister(a and 7)
            a == 0x4016 -> {
                val bit = if (strobe) buttons[0] else if (controllerIndex < 8) buttons[controllerIndex] else false
                if (!strobe && controllerIndex < 8) controllerIndex++
                (bit.compareTo(false) or 0x40)
            }
            a >= 0x8000 -> cart.prgRom[(a - 0x8000) % cart.prgRom.size].toInt() and 0xff
            else -> 0
        }
    }
    private fun write(raw: Int, value: Int) {
        val a = raw and 0xffff; val v = value and 0xff
        when {
            a < 0x2000 -> ram[a and 0x7ff] = v.toByte()
            a < 0x4000 -> ppu.cpuWriteRegister(a and 7, v)
            a == 0x4016 -> { val next = v and 1 != 0; if (strobe && !next) controllerIndex = 0; strobe = next }
        }
    }
}

private class Cpu6502(private val read: (Int) -> Int, private val write: (Int, Int) -> Unit) {
    private var a = 0; private var x = 0; private var y = 0; private var sp = 0xfd; private var pc = 0
    private var c = false; private var z = false; private var i = true; private var d = false; private var v = false; private var n = false
    fun reset() { a = 0; x = 0; y = 0; sp = 0xfd; c = false; z = false; i = true; d = false; v = false; n = false; pc = word(0xfffc) }
    private fun fetch(): Int { val q = read(pc); pc = (pc + 1) and 0xffff; return q }
    private fun word(at: Int): Int = read(at and 0xffff) or (read((at + 1) and 0xffff) shl 8)
    private fun push(q: Int) { write(0x100 + sp, q); sp = (sp - 1) and 0xff }
    private fun pop(): Int { sp = (sp + 1) and 0xff; return read(0x100 + sp) }
    private fun nz(q: Int) { val r = q and 0xff; z = r == 0; n = r and 0x80 != 0 }
    private fun zp(): Int = fetch()
    private fun zpx(): Int = (fetch() + x) and 0xff
    private fun zpy(): Int = (fetch() + y) and 0xff
    private fun abs(): Int { val lo = fetch(); return lo or (fetch() shl 8) }
    private fun absx(): Int = (abs() + x) and 0xffff
    private fun absy(): Int = (abs() + y) and 0xffff
    private fun indx(): Int { val p = (fetch() + x) and 0xff; return read(p) or (read((p + 1) and 0xff) shl 8) }
    private fun indy(): Int { val p = fetch(); return ((read(p) or (read((p + 1) and 0xff) shl 8)) + y) and 0xffff }
    private fun rmw(addr: Int, f: (Int) -> Int) { val q = f(read(addr)); write(addr, q); nz(q) }
    private fun adc(q0: Int) { val q = q0 and 0xff; val sum = a + q + if (c) 1 else 0; val result = sum and 0xff; v = ((a xor result) and (q xor result) and 0x80) != 0; c = sum > 0xff; a = result; nz(a) }
    private fun compare(reg: Int, q: Int) { val d = reg - (q and 0xff); c = d >= 0; nz(d) }
    private fun branch(condition: Boolean): Int { val offset = fetch().let { if (it and 0x80 != 0) it - 256 else it }; if (!condition) return 2; val old = pc; pc = (pc + offset) and 0xffff; return if (old ushr 8 == pc ushr 8) 3 else 4 }
    fun step(): Int {
        val op = fetch()
        when (op) {
            0x00 -> { pc = (pc + 1) and 0xffff; push(pc ushr 8); push(pc and 0xff); push(status() or 0x10); i = true; pc = word(0xfffe); return 7 }
            0x20 -> { val dst = abs(); val ret = (pc - 1) and 0xffff; push(ret ushr 8); push(ret and 0xff); pc = dst; return 6 }
            0x40 -> { setStatus(pop()); val lo = pop(); pc = lo or (pop() shl 8); return 6 }
            0x60 -> { val lo = pop(); pc = ((lo or (pop() shl 8)) + 1) and 0xffff; return 6 }
            0x4c -> { pc = abs(); return 3 }
            0x6c -> { val p = abs(); val hiAt = (p and 0xff00) or ((p + 1) and 0xff); pc = read(p) or (read(hiAt) shl 8); return 5 }
            0x08 -> { push(status() or 0x10); return 3 }; 0x28 -> { setStatus(pop()); return 4 }
            0x48 -> { push(a); return 3 }; 0x68 -> { a = pop(); nz(a); return 4 }
            0x18 -> { c = false; return 2 }; 0x38 -> { c = true; return 2 }
            0x58 -> { i = false; return 2 }; 0x78 -> { i = true; return 2 }
            0xb8 -> { v = false; return 2 }; 0xd8 -> { d = false; return 2 }; 0xf8 -> { d = true; return 2 }
            0xaa -> { x = a; nz(x); return 2 }; 0x8a -> { a = x; nz(a); return 2 }
            0xa8 -> { y = a; nz(y); return 2 }; 0x98 -> { a = y; nz(a); return 2 }
            0xba -> { x = sp; nz(x); return 2 }; 0x9a -> { sp = x; return 2 }
            0xe8 -> { x = (x + 1) and 0xff; nz(x); return 2 }; 0xca -> { x = (x - 1) and 0xff; nz(x); return 2 }
            0xc8 -> { y = (y + 1) and 0xff; nz(y); return 2 }; 0x88 -> { y = (y - 1) and 0xff; nz(y); return 2 }
            0xea -> return 2
            0x10 -> return branch(!n); 0x30 -> return branch(n); 0x50 -> return branch(!v); 0x70 -> return branch(v)
            0x90 -> return branch(!c); 0xb0 -> return branch(c); 0xd0 -> return branch(!z); 0xf0 -> return branch(z)
        }
        val low = op and 0x1f
        val family = op and 0xe0
        if (low in intArrayOf(0x01,0x05,0x09,0x0d,0x11,0x15,0x19,0x1d) && family in intArrayOf(0x00,0x20,0x40,0x60,0x80,0xa0,0xc0,0xe0)) {
            val addr = when (low) { 0x01 -> indx(); 0x05 -> zp(); 0x09 -> -1; 0x0d -> abs(); 0x11 -> indy(); 0x15 -> zpx(); 0x19 -> absy(); else -> absx() }
            val q = if (addr < 0) fetch() else read(addr)
            when (family) {
                0x00 -> { a = a or q; nz(a) }; 0x20 -> { a = a and q; nz(a) }; 0x40 -> { a = a xor q; nz(a) }
                0x60 -> adc(q); 0x80 -> { if (addr < 0) illegal(op); write(addr, a); return if (low == 0x01 || low == 0x11) 6 else if (low == 0x0d) 4 else 3 }
                0xa0 -> { a = q; nz(a) }; 0xc0 -> compare(a, q); 0xe0 -> adc(q xor 0xff)
            }
            return when (low) { 0x01 -> 6; 0x05 -> 3; 0x09 -> 2; 0x0d -> 4; 0x11,0x19,0x1d -> 4; else -> 4 }
        }
        when (op) {
            0xa2 -> { x = fetch(); nz(x); return 2 }; 0xa6 -> { x = read(zp()); nz(x); return 3 }; 0xb6 -> { x = read(zpy()); nz(x); return 4 }; 0xae -> { x = read(abs()); nz(x); return 4 }; 0xbe -> { x = read(absy()); nz(x); return 4 }
            0xa0 -> { y = fetch(); nz(y); return 2 }; 0xa4 -> { y = read(zp()); nz(y); return 3 }; 0xb4 -> { y = read(zpx()); nz(y); return 4 }; 0xac -> { y = read(abs()); nz(y); return 4 }; 0xbc -> { y = read(absx()); nz(y); return 4 }
            0x86 -> { write(zp(),x); return 3 }; 0x96 -> { write(zpy(),x); return 4 }; 0x8e -> { write(abs(),x); return 4 }
            0x84 -> { write(zp(),y); return 3 }; 0x94 -> { write(zpx(),y); return 4 }; 0x8c -> { write(abs(),y); return 4 }
            0xc0 -> { compare(y,fetch()); return 2 }; 0xc4 -> { compare(y,read(zp())); return 3 }; 0xcc -> { compare(y,read(abs())); return 4 }
            0xe0 -> { compare(x,fetch()); return 2 }; 0xe4 -> { compare(x,read(zp())); return 3 }; 0xec -> { compare(x,read(abs())); return 4 }
            0xe6 -> { rmw(zp()) { (it+1) and 0xff }; return 5 }; 0xf6 -> { rmw(zpx()) { (it+1) and 0xff }; return 6 }; 0xee -> { rmw(abs()) { (it+1) and 0xff }; return 6 }; 0xfe -> { rmw(absx()) { (it+1) and 0xff }; return 7 }
            0xc6 -> { rmw(zp()) { (it-1) and 0xff }; return 5 }; 0xd6 -> { rmw(zpx()) { (it-1) and 0xff }; return 6 }; 0xce -> { rmw(abs()) { (it-1) and 0xff }; return 6 }; 0xde -> { rmw(absx()) { (it-1) and 0xff }; return 7 }
            0x0a -> { c = a and 0x80 != 0; a = (a shl 1) and 0xff; nz(a); return 2 }; 0x4a -> { c = a and 1 != 0; a = a ushr 1; nz(a); return 2 }
            0x2a -> { val old = if(c) 1 else 0; c = a and 0x80 != 0; a = ((a shl 1) or old) and 0xff; nz(a); return 2 }; 0x6a -> { val old=if(c)0x80 else 0; c=a and 1 != 0; a=(a ushr 1) or old; nz(a); return 2 }
            0x06 -> { rmw(zp()) { c=it and 0x80 != 0; (it shl 1) and 0xff }; return 5 }; 0x16 -> { rmw(zpx()) { c=it and 0x80 != 0; (it shl 1) and 0xff }; return 6 }; 0x0e -> { rmw(abs()) { c=it and 0x80 != 0; (it shl 1) and 0xff }; return 6 }; 0x1e -> { rmw(absx()) { c=it and 0x80 != 0; (it shl 1) and 0xff }; return 7 }
            0x46 -> { rmw(zp()) { c=it and 1 != 0; it ushr 1 }; return 5 }; 0x56 -> { rmw(zpx()) { c=it and 1 != 0; it ushr 1 }; return 6 }; 0x4e -> { rmw(abs()) { c=it and 1 != 0; it ushr 1 }; return 6 }; 0x5e -> { rmw(absx()) { c=it and 1 != 0; it ushr 1 }; return 7 }
            0x26 -> { rmw(zp()) { val old=if(c)1 else 0; c=it and 0x80 != 0; ((it shl 1) or old) and 0xff }; return 5 }; 0x2e -> { rmw(abs()) { val old=if(c)1 else 0; c=it and 0x80 != 0; ((it shl 1) or old) and 0xff }; return 6 }
            0x66 -> { rmw(zp()) { val old=if(c)0x80 else 0; c=it and 1 != 0; (it ushr 1) or old }; return 5 }; 0x6e -> { rmw(abs()) { val old=if(c)0x80 else 0; c=it and 1 != 0; (it ushr 1) or old }; return 6 }
        }
        illegal(op)
    }
    private fun status(): Int = (if(n)0x80 else 0) or (if(v)0x40 else 0) or 0x20 or (if(d)8 else 0) or (if(i)4 else 0) or (if(z)2 else 0) or (if(c)1 else 0)
    private fun setStatus(q: Int) { n=q and 0x80 != 0; v=q and 0x40 != 0; d=q and 8 != 0; i=q and 4 != 0; z=q and 2 != 0; c=q and 1 != 0 }
    private fun illegal(op: Int): Nothing = throw IllegalArgumentException("Opcode 0x${op.toString(16)} não implementado no núcleo NES Nébula.")
}
