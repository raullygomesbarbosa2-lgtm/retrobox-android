package com.raully.nebula16.snes

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SnesCoreTest {
    @Test fun parsesLoRomResetVectorAndRunsOriginalSubset() {
        val rom = ByteArray(0x8000)
        rom[0x7ffc] = 0x00; rom[0x7ffd] = 0x80.toByte()
        rom[0] = 0xA9.toByte(); rom[1] = 0x2A
        rom[2] = 0x8D.toByte(); rom[3] = 0x00; rom[4] = 0x10
        rom[5] = 0xDB.toByte()
        val machine = SnesPrototype(rom)
        assertEquals(0x8000, machine.cpu.pc)
        machine.testInstructions(3)
        assertEquals(0x2a, machine.cpu.readWram(0x1000))
        assertTrue(machine.cpu.stopped)
    }

    @Test fun stripsCopierHeader() {
        val rom = ByteArray(512 + 0x8000)
        val cart = Cartridge.parse(rom)
        assertTrue(cart.hasCopierHeader)
        assertEquals(0x8000, cart.rom.size)
    }
}
