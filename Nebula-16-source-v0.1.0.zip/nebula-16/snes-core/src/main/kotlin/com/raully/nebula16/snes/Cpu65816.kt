package com.raully.nebula16.snes

/** Original 65C816/65816 educational core; currently implements a small documented opcode subset. */
class Cpu65816(private val cartridge: Cartridge) {
    var pc: Int = cartridge.resetVector(); private set
    var a: Int = 0; private set
    var x: Int = 0; private set
    var y: Int = 0; private set
    var status: Int = 0x34; private set
    var stopped: Boolean = false; private set
    private val wram = ByteArray(128 * 1024)
    var instructionsExecuted: Long = 0; private set

    private fun fetch(): Int { val v = cartridge.readRom(pc) ?: 0; pc = (pc + 1) and 0xffff; return v }
    private fun nz(value: Int) { status = (status and 0x7d) or (if ((value and 0xff) == 0) 2 else 0) or (value and 0x80) }
    private fun setWram(address: Int, value: Int) { wram[address and 0x1ffff] = value.toByte() }
    fun readWram(address: Int): Int = wram[address and 0x1ffff].toInt() and 0xff

    /** Executes one instruction. Unsupported opcodes stop execution rather than pretending compatibility. */
    fun step(): String {
        if (stopped) return "STP"
        val opcodeAddress = pc
        val op = fetch()
        val name = when (op) {
            0xEA -> "NOP"
            0xA9 -> { a = fetch(); nz(a); "LDA #imm" }
            0xA2 -> { x = fetch(); nz(x); "LDX #imm" }
            0xA0 -> { y = fetch(); nz(y); "LDY #imm" }
            0x8D -> { val lo = fetch(); val hi = fetch(); setWram(lo or (hi shl 8), a); "STA abs (WRAM test map)" }
            0x4C -> { val lo = fetch(); pc = lo or (fetch() shl 8); "JMP abs" }
            0x80 -> { val d = fetch().toByte().toInt(); pc = (pc + d) and 0xffff; "BRA rel" }
            0xD0, 0xF0 -> { val d = fetch().toByte().toInt(); val zero = status and 2 != 0; if ((op == 0xD0 && !zero) || (op == 0xF0 && zero)) pc = (pc + d) and 0xffff; if (op == 0xD0) "BNE rel" else "BEQ rel" }
            0xDB -> { stopped = true; "STP" }
            else -> { stopped = true; "Unsupported opcode %02X at %04X".format(op, opcodeAddress) }
        }
        instructionsExecuted++
        return name
    }
}

/** ROM inspection and tiny CPU smoke test. It is not a full SNES machine. */
class SnesPrototype(bytes: ByteArray) {
    val cartridge = Cartridge.parse(bytes)
    val cpu = Cpu65816(cartridge)
    fun testInstructions(count: Int = 16): List<String> = buildList {
        repeat(count) { if (!cpu.stopped) add(cpu.step()) }
    }
}
