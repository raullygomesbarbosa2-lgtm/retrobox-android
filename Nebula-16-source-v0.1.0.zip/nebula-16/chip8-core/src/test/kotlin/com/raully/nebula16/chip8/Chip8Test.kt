package com.raully.nebula16.chip8

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class Chip8Test {
    @Test fun executesLoadAddAndDrawSprite() {
        val vm = Chip8 { 0xA5 }
        vm.load(byteArrayOf(0x60, 0xFE.toByte(), 0x70, 0x05, 0x61, 0x08, 0xA2.toByte(), 0x0C, 0xD0.toByte(), 0x11, 0x12, 0x08, 0x80.toByte()))
        repeat(7) { vm.cycle() }
        assertEquals(3, vm.register(0))
        assertEquals(1, vm.register(15)) // drawing the same row twice sets collision flag VF
        assertTrue(vm.screen().any { it })
    }

    @Test fun originalDemoProgramLoadsAndDraws() {
        val vm = Chip8(); vm.load(Chip8.demo)
        repeat(5) { vm.cycle() }
        assertTrue(vm.screen().any { it })
    }
}
