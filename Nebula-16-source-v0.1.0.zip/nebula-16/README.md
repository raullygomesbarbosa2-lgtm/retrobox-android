# Nébula 16 — projeto autoral Android

Aplicativo Android em desenvolvimento, com uma interface própria e dois sistemas selecionáveis: um interpretador CHIP-8 jogável e um núcleo SNES experimental, escrito do zero em Kotlin. Não embute interfaces ou núcleos de outros emuladores.

## Situação real desta prévia

- **CHIP-8:** roda o demo original incluído no código e aceita ROMs `.ch8`/arquivos binários locais. Inclui controles de toque e suporte básico a controles físicos reconhecidos pelo Android.
- **Super Nintendo:** lê um cartucho LoROM simples, identifica o cabeçalho e exercita um pequeno subconjunto da CPU 65C816 (LDA/LDX/LDY imediato, STA absoluto para memória de teste, JMP, BRA, BNE, BEQ, NOP e STP). O app exibe o relatório da análise.
- **Ainda não é um emulador SNES jogável.** Faltam a PPU (vídeo), APU (áudio), DMA, interrupções, temporização e a maior parte do conjunto de instruções da CPU. A opção SNES é uma bancada de desenvolvimento, não promete abrir jogos.
- Nenhuma ROM comercial, BIOS, firmware ou jogo de terceiros é incluído.

O projeto é original, mas isso não significa que ninguém jamais tenha feito um emulador de SNES: o que é novo aqui é este código e esta identidade de projeto. Compatibilidade não é garantida.

## Compilar pelo GitHub Actions

Envie o conteúdo desta pasta para um repositório GitHub e rode o workflow **Build Nébula 16** em Actions (ou faça push na branch `main`). O workflow testa os núcleos e produz `app-debug.apk` como artefato para baixar. Requer Android SDK API 35, JDK 17 e Gradle 8.10.2; o workflow configura isso automaticamente.

## Estrutura

- `app/` — app nativo, interface e controles.
- `chip8-core/` — interpretador CHIP-8 autoral e testes.
- `snes-core/` — carregador LoROM, mapeamento inicial e CPU 65C816 parcial, com testes.
