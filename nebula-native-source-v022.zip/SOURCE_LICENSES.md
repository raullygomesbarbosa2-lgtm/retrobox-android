# Credits and third-party licenses

The Nébula Retro Android frontend in this folder is an original Kotlin application. It integrates existing open-source emulation engines; it does not claim to implement the PSP or PS1 hardware emulation itself.

- LibretroDroid Android frontend library: https://github.com/Swordfish90/LibretroDroid (GPL-3.0-or-later)
- PSP core: PPSSPP, https://github.com/hrydgard/ppsspp (GPL-2.0-or-later)
- PS1 core: PCSX-ReARMed, https://github.com/libretro/pcsx_rearmed (GPL-2.0-or-later)
- Android core binaries in the build: LemuroidCores, https://github.com/Swordfish90/LemuroidCores, pinned to `fee2e824525daa22bcf318f96127fe43fa8a15ad`.

The build packages only the PCSX-ReARMed and PPSSPP native libraries. Preserve and consult the upstream notices and license files for those cores and libraries. This project does not include games, BIOS, or proprietary firmware. The app can import a BIOS file supplied by the user; it never distributes one. See `COPYING` for the GPLv3 license text for this frontend project.
