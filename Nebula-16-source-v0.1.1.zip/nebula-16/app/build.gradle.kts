plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.raully.nebula16"
    compileSdk = 35
    defaultConfig { applicationId = "com.raully.nebula16"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "0.1.1-preview" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(project(":snes-core"))
    implementation(project(":chip8-core"))
}
