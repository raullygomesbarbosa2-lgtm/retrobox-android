# Nébula Zero — motor PS1 autoral (em desenvolvimento)

Esta é uma implementação própria, sem importar código ou motores de PPSSPP, PCSX, Libretro/Lemuroid ou de outros emuladores. O código do motor foi escrito para este projeto. As instruções da CPU são implementadas a partir do comportamento documentado do hardware.

## Estado desta etapa

- CPU MIPS R3000A: subconjunto de instruções MIPS I, operações aritméticas/lógicas, desvios e delay slots, multiplicação/divisão, loads/stores básicos.
- COP0 inicial: MFC0, MTC0 e RFE; exceções para overflow, syscall, breakpoint, instrução reservada, coprocessador ausente, acesso desalinhado e falhas do barramento; EPC, Cause, BadVAddr, modo de delay slot e vetores de exceção.
- Memória: 2 MiB de RAM com espelhamento até 8 MiB, 1 KiB de scratchpad e área de 512 KiB para ler firmware fornecido pelo próprio usuário. Nenhum firmware acompanha o projeto.
- Leitura inicial de ISO-9660 de setor de dados de 2048 bytes: localização de SYSTEM.CNF e do caminho BOOT; loader de PS-X EXE para RAM e início direto sem executar o firmware.
- GPU própria em software: buffer de VRAM 1024×512, preenchimento de retângulos, polígonos planos e texturizados (amostragem 4/8/15 bpp), recorte básico, cópia/upload de pixels e snapshot ARGB. Transparência, temporização, comandos restantes, ligação ao barramento e exibição Android ainda faltam.
- Testes unitários foram escritos para essas partes, mas ainda não foram executados neste ambiente.

## Ainda não funciona como emulador de jogos

Ainda faltam muitas instruções e exceções, HLE de serviços de BIOS usados pelos jogos, GPU e renderização, CD-ROM e leitura de trilhas CUE/BIN, DMA, timers, SPU/áudio, controles, interface Android e integração desses módulos. O leitor ISO atual apenas localiza SYSTEM.CNF e extrai o PS-X EXE; o loader coloca um EXE direto na RAM, mas não emula o CD-ROM nem os serviços do BIOS. Portanto, isto **ainda não roda jogos comerciais de uma ISO e não gera um APK jogável**. A compatibilidade com jogos não foi testada.

Depois de concluir e validar os sistemas essenciais de PS1, o PSP será um motor separado, também de autoria própria. Nenhum código ou núcleo de outro emulador deve ser incorporado.
